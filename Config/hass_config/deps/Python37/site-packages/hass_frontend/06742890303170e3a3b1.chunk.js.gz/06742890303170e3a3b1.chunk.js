(window.webpackJsonp=window.webpackJsonp||[]).push([[93],{108:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return PaperItemBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(50),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(32);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperItemBehaviorImpl={hostAttributes:{role:"option",tabindex:"0"}},PaperItemBehavior=[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a,PaperItemBehaviorImpl]},112:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(2),iron_form_element_behavior=__webpack_require__(53),iron_validatable_behavior=__webpack_require__(54);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronCheckedElementBehaviorImpl={properties:{checked:{type:Boolean,value:!1,reflectToAttribute:!0,notify:!0,observer:"_checkedChanged"},toggles:{type:Boolean,value:!0,reflectToAttribute:!0},value:{type:String,value:"on",observer:"_valueChanged"}},observers:["_requiredChanged(required)"],created:function(){this._hasIronCheckedElementBehavior=!0},_getValidity:function(_value){return this.disabled||!this.required||this.checked},_requiredChanged:function(){if(this.required){this.setAttribute("aria-required","true")}else{this.removeAttribute("aria-required")}},_checkedChanged:function(){this.active=this.checked;this.fire("iron-change")},_valueChanged:function(){if(this.value===void 0||null===this.value){this.value="on"}}},IronCheckedElementBehavior=[iron_form_element_behavior.a,iron_validatable_behavior.a,IronCheckedElementBehaviorImpl];var paper_inky_focus_behavior=__webpack_require__(52),paper_ripple_behavior=__webpack_require__(61);__webpack_require__.d(__webpack_exports__,"a",function(){return PaperCheckedElementBehavior});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperCheckedElementBehaviorImpl={_checkedChanged:function(){IronCheckedElementBehaviorImpl._checkedChanged.call(this);if(this.hasRipple()){if(this.checked){this._ripple.setAttribute("checked","")}else{this._ripple.removeAttribute("checked")}}},_buttonStateChanged:function(){paper_ripple_behavior.a._buttonStateChanged.call(this);if(this.disabled){return}if(this.isAttached){this.checked=this.active}}},PaperCheckedElementBehavior=[paper_inky_focus_behavior.a,IronCheckedElementBehavior,PaperCheckedElementBehaviorImpl]},127:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(40),_paper_item_shared_styles_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(128),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(3),_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(108);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style include="paper-item-shared-styles">
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
      }
    </style>
    <slot></slot>
`,is:"paper-item",behaviors:[_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a]})},128:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(40),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(60),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(41),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(51);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-item-shared-styles">
  <template>
    <style>
      :host, .paper-item {
        display: block;
        position: relative;
        min-height: var(--paper-item-min-height, 48px);
        padding: 0px 16px;
      }

      .paper-item {
        @apply --paper-font-subhead;
        border:none;
        outline: none;
        background: white;
        width: 100%;
        text-align: left;
      }

      :host([hidden]), .paper-item[hidden] {
        display: none !important;
      }

      :host(.iron-selected), .paper-item.iron-selected {
        font-weight: var(--paper-item-selected-weight, bold);

        @apply --paper-item-selected;
      }

      :host([disabled]), .paper-item[disabled] {
        color: var(--paper-item-disabled-color, var(--disabled-text-color));

        @apply --paper-item-disabled;
      }

      :host(:focus), .paper-item:focus {
        position: relative;
        outline: 0;

        @apply --paper-item-focused;
      }

      :host(:focus):before, .paper-item:focus:before {
        @apply --layout-fit;

        background: currentColor;
        content: '';
        opacity: var(--dark-divider-opacity);
        pointer-events: none;

        @apply --paper-item-focused-before;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},130:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(30),_polymer_iron_icon_iron_icon_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(97),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(80),_polymer_paper_menu_button_paper_menu_button_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(133),_polymer_paper_ripple_paper_ripple_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(100),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(41),_paper_dropdown_menu_icons_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(131),_paper_dropdown_menu_shared_styles_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(132),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(50),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(32),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__=__webpack_require__(53),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__=__webpack_require__(54),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__=__webpack_require__(0),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__=__webpack_require__(33),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__.a`
    <style include="paper-dropdown-menu-shared-styles"></style>

    <!-- this div fulfills an a11y requirement for combobox, do not remove -->
    <span role="button"></span>
    <paper-menu-button id="menuButton" vertical-align="[[verticalAlign]]" horizontal-align="[[horizontalAlign]]" dynamic-align="[[dynamicAlign]]" vertical-offset="[[_computeMenuVerticalOffset(noLabelFloat, verticalOffset)]]" disabled="[[disabled]]" no-animations="[[noAnimations]]" on-iron-select="_onIronSelect" on-iron-deselect="_onIronDeselect" opened="{{opened}}" close-on-activate allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]">
      <!-- support hybrid mode: user might be using paper-menu-button 1.x which distributes via <content> -->
      <div class="dropdown-trigger" slot="dropdown-trigger">
        <paper-ripple></paper-ripple>
        <!-- paper-input has type="text" for a11y, do not remove -->
        <paper-input type="text" invalid="[[invalid]]" readonly disabled="[[disabled]]" value="[[value]]" placeholder="[[placeholder]]" error-message="[[errorMessage]]" always-float-label="[[alwaysFloatLabel]]" no-label-float="[[noLabelFloat]]" label="[[label]]">
          <!-- support hybrid mode: user might be using paper-input 1.x which distributes via <content> -->
          <iron-icon icon="paper-dropdown-menu:arrow-drop-down" suffix slot="suffix"></iron-icon>
        </paper-input>
      </div>
      <slot id="content" name="dropdown-content" slot="dropdown-content"></slot>
    </paper-menu-button>
`,is:"paper-dropdown-menu",behaviors:[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__.a,_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__.a],properties:{selectedItemLabel:{type:String,notify:!0,readOnly:!0},selectedItem:{type:Object,notify:!0,readOnly:!0},value:{type:String,notify:!0},label:{type:String},placeholder:{type:String},errorMessage:{type:String},opened:{type:Boolean,notify:!0,value:!1,observer:"_openedChanged"},allowOutsideScroll:{type:Boolean,value:!1},noLabelFloat:{type:Boolean,value:!1,reflectToAttribute:!0},alwaysFloatLabel:{type:Boolean,value:!1},noAnimations:{type:Boolean,value:!1},horizontalAlign:{type:String,value:"right"},verticalAlign:{type:String,value:"top"},verticalOffset:Number,dynamicAlign:{type:Boolean},restoreFocusOnClose:{type:Boolean,value:!0}},listeners:{tap:"_onTap"},keyBindings:{"up down":"open",esc:"close"},hostAttributes:{role:"combobox","aria-autocomplete":"none","aria-haspopup":"true"},observers:["_selectedItemChanged(selectedItem)"],attached:function(){var contentElement=this.contentElement;if(contentElement&&contentElement.selectedItem){this._setSelectedItem(contentElement.selectedItem)}},get contentElement(){for(var nodes=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},open:function(){this.$.menuButton.open()},close:function(){this.$.menuButton.close()},_onIronSelect:function(event){this._setSelectedItem(event.detail.item)},_onIronDeselect:function(event){this._setSelectedItem(null)},_onTap:function(event){if(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__.c(event)===this){this.open()}},_selectedItemChanged:function(selectedItem){var value="";if(!selectedItem){value=""}else{value=selectedItem.label||selectedItem.getAttribute("label")||selectedItem.textContent.trim()}this.value=value;this._setSelectedItemLabel(value)},_computeMenuVerticalOffset:function(noLabelFloat,opt_verticalOffset){if(opt_verticalOffset){return opt_verticalOffset}return noLabelFloat?-4:8},_getValidity:function(_value){return this.disabled||!this.required||this.required&&!!this.value},_openedChanged:function(){var openState=this.opened?"true":"false",e=this.contentElement;if(e){e.setAttribute("aria-expanded",openState)}}})},131:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_iconset_svg_iron_iconset_svg_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(75);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<iron-iconset-svg name="paper-dropdown-menu" size="24">
<svg><defs>
<g id="arrow-drop-down"><path d="M7 10l5 5 5-5z"></path></g>
</defs></svg>
</iron-iconset-svg>`;document.head.appendChild($_documentContainer.content)},132:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(41);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-dropdown-menu-shared-styles">
  <template>
    <style>
      :host {
        display: inline-block;
        position: relative;
        text-align: left;

        /* NOTE(cdata): Both values are needed, since some phones require the
         * value to be \`transparent\`.
         */
        -webkit-tap-highlight-color: rgba(0,0,0,0);
        -webkit-tap-highlight-color: transparent;

        --paper-input-container-input: {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          max-width: 100%;
          box-sizing: border-box;
          cursor: pointer;
        };

        @apply --paper-dropdown-menu;
      }

      :host([disabled]) {
        @apply --paper-dropdown-menu-disabled;
      }

      :host([noink]) paper-ripple {
        display: none;
      }

      :host([no-label-float]) paper-ripple {
        top: 8px;
      }

      paper-ripple {
        top: 12px;
        left: 0px;
        bottom: 8px;
        right: 0px;

        @apply --paper-dropdown-menu-ripple;
      }

      paper-menu-button {
        display: block;
        padding: 0;

        @apply --paper-dropdown-menu-button;
      }

      paper-input {
        @apply --paper-dropdown-menu-input;
      }

      iron-icon {
        color: var(--disabled-text-color);

        @apply --paper-dropdown-menu-icon;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},140:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(40),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(60),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(99),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: block;
        width: 200px;
        position: relative;
        overflow: hidden;
      }

      :host([hidden]), [hidden] {
        display: none !important;
      }

      #progressContainer {
        @apply --paper-progress-container;
        position: relative;
      }

      #progressContainer,
      /* the stripe for the indeterminate animation*/
      .indeterminate::after {
        height: var(--paper-progress-height, 4px);
      }

      #primaryProgress,
      #secondaryProgress,
      .indeterminate::after {
        @apply --layout-fit;
      }

      #progressContainer,
      .indeterminate::after {
        background: var(--paper-progress-container-color, var(--google-grey-300));
      }

      :host(.transiting) #primaryProgress,
      :host(.transiting) #secondaryProgress {
        -webkit-transition-property: -webkit-transform;
        transition-property: transform;

        /* Duration */
        -webkit-transition-duration: var(--paper-progress-transition-duration, 0.08s);
        transition-duration: var(--paper-progress-transition-duration, 0.08s);

        /* Timing function */
        -webkit-transition-timing-function: var(--paper-progress-transition-timing-function, ease);
        transition-timing-function: var(--paper-progress-transition-timing-function, ease);

        /* Delay */
        -webkit-transition-delay: var(--paper-progress-transition-delay, 0s);
        transition-delay: var(--paper-progress-transition-delay, 0s);
      }

      #primaryProgress,
      #secondaryProgress {
        @apply --layout-fit;
        -webkit-transform-origin: left center;
        transform-origin: left center;
        -webkit-transform: scaleX(0);
        transform: scaleX(0);
        will-change: transform;
      }

      #primaryProgress {
        background: var(--paper-progress-active-color, var(--google-green-500));
      }

      #secondaryProgress {
        background: var(--paper-progress-secondary-color, var(--google-green-100));
      }

      :host([disabled]) #primaryProgress {
        background: var(--paper-progress-disabled-active-color, var(--google-grey-500));
      }

      :host([disabled]) #secondaryProgress {
        background: var(--paper-progress-disabled-secondary-color, var(--google-grey-300));
      }

      :host(:not([disabled])) #primaryProgress.indeterminate {
        -webkit-transform-origin: right center;
        transform-origin: right center;
        -webkit-animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      :host(:not([disabled])) #primaryProgress.indeterminate::after {
        content: "";
        -webkit-transform-origin: center center;
        transform-origin: center center;

        -webkit-animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      @-webkit-keyframes indeterminate-bar {
        0% {
          -webkit-transform: scaleX(1) translateX(-100%);
        }
        50% {
          -webkit-transform: scaleX(1) translateX(0%);
        }
        75% {
          -webkit-transform: scaleX(1) translateX(0%);
          -webkit-animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          -webkit-transform: scaleX(0) translateX(0%);
        }
      }

      @-webkit-keyframes indeterminate-splitter {
        0% {
          -webkit-transform: scaleX(.75) translateX(-125%);
        }
        30% {
          -webkit-transform: scaleX(.75) translateX(-125%);
          -webkit-animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
        100% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
      }

      @keyframes indeterminate-bar {
        0% {
          transform: scaleX(1) translateX(-100%);
        }
        50% {
          transform: scaleX(1) translateX(0%);
        }
        75% {
          transform: scaleX(1) translateX(0%);
          animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          transform: scaleX(0) translateX(0%);
        }
      }

      @keyframes indeterminate-splitter {
        0% {
          transform: scaleX(.75) translateX(-125%);
        }
        30% {
          transform: scaleX(.75) translateX(-125%);
          animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          transform: scaleX(.75) translateX(125%);
        }
        100% {
          transform: scaleX(.75) translateX(125%);
        }
      }
    </style>

    <div id="progressContainer">
      <div id="secondaryProgress" hidden\$="[[_hideSecondaryProgress(secondaryRatio)]]"></div>
      <div id="primaryProgress"></div>
    </div>
`,is:"paper-progress",behaviors:[_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__.a],properties:{secondaryProgress:{type:Number,value:0},secondaryRatio:{type:Number,value:0,readOnly:!0},indeterminate:{type:Boolean,value:!1,observer:"_toggleIndeterminate"},disabled:{type:Boolean,value:!1,reflectToAttribute:!0,observer:"_disabledChanged"}},observers:["_progressChanged(secondaryProgress, value, min, max, indeterminate)"],hostAttributes:{role:"progressbar"},_toggleIndeterminate:function(indeterminate){this.toggleClass("indeterminate",indeterminate,this.$.primaryProgress)},_transformProgress:function(progress,ratio){var transform="scaleX("+ratio/100+")";progress.style.transform=progress.style.webkitTransform=transform},_mainRatioChanged:function(ratio){this._transformProgress(this.$.primaryProgress,ratio)},_progressChanged:function(secondaryProgress,value,min,max,indeterminate){secondaryProgress=this._clampValue(secondaryProgress);value=this._clampValue(value);var secondaryRatio=100*this._calcRatio(secondaryProgress),mainRatio=100*this._calcRatio(value);this._setSecondaryRatio(secondaryRatio);this._transformProgress(this.$.secondaryProgress,secondaryRatio);this._transformProgress(this.$.primaryProgress,mainRatio);this.secondaryProgress=secondaryProgress;if(indeterminate){this.removeAttribute("aria-valuenow")}else{this.setAttribute("aria-valuenow",value)}this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max)},_disabledChanged:function(disabled){this.setAttribute("aria-disabled",disabled?"true":"false")},_hideSecondaryProgress:function(secondaryRatio){return 0===secondaryRatio}})},141:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(40),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(80),_polymer_paper_progress_paper_progress_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(140),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(60),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(30),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(53),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(99),_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(52),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(33),_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(2);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__.c`
  <style>
    :host {
      @apply --layout;
      @apply --layout-justified;
      @apply --layout-center;
      width: 200px;
      cursor: default;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      --paper-progress-active-color: var(--paper-slider-active-color, var(--google-blue-700));
      --paper-progress-secondary-color: var(--paper-slider-secondary-color, var(--google-blue-300));
      --paper-progress-disabled-active-color: var(--paper-slider-disabled-active-color, var(--paper-grey-400));
      --paper-progress-disabled-secondary-color: var(--paper-slider-disabled-secondary-color, var(--paper-grey-400));
      --calculated-paper-slider-height: var(--paper-slider-height, 2px);
    }

    /* focus shows the ripple */
    :host(:focus) {
      outline: none;
    }

    /**
      * NOTE(keanulee): Though :host-context is not universally supported, some pages
      * still rely on paper-slider being flipped when dir="rtl" is set on body. For full
      * compatibility, dir="rtl" must be explicitly set on paper-slider.
      */
    :dir(rtl) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): This is separate from the rule above because :host-context may
      * not be recognized.
      */
    :host([dir="rtl"]) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): Needed to override the :host-context rule (where supported)
      * to support LTR sliders in RTL pages.
      */
    :host([dir="ltr"]) #sliderContainer {
      -webkit-transform: scaleX(1);
      transform: scaleX(1);
    }

    #sliderContainer {
      position: relative;
      width: 100%;
      height: calc(30px + var(--calculated-paper-slider-height));
      margin-left: calc(15px + var(--calculated-paper-slider-height)/2);
      margin-right: calc(15px + var(--calculated-paper-slider-height)/2);
    }

    #sliderContainer:focus {
      outline: 0;
    }

    #sliderContainer.editable {
      margin-top: 12px;
      margin-bottom: 12px;
    }

    .bar-container {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      overflow: hidden;
    }

    .ring > .bar-container {
      left: calc(5px + var(--calculated-paper-slider-height)/2);
      transition: left 0.18s ease;
    }

    .ring.expand.dragging > .bar-container {
      transition: none;
    }

    .ring.expand:not(.pin) > .bar-container {
      left: calc(8px + var(--calculated-paper-slider-height)/2);
    }

    #sliderBar {
      padding: 15px 0;
      width: 100%;
      background-color: var(--paper-slider-bar-color, transparent);
      --paper-progress-container-color: var(--paper-slider-container-color, var(--paper-grey-400));
      --paper-progress-height: var(--calculated-paper-slider-height);
    }

    .slider-markers {
      position: absolute;
      /* slider-knob is 30px + the slider-height so that the markers should start at a offset of 15px*/
      top: 15px;
      height: var(--calculated-paper-slider-height);
      left: 0;
      right: -1px;
      box-sizing: border-box;
      pointer-events: none;
      @apply --layout-horizontal;
    }

    .slider-marker {
      @apply --layout-flex;
    }
    .slider-markers::after,
    .slider-marker::after {
      content: "";
      display: block;
      margin-left: -1px;
      width: 2px;
      height: var(--calculated-paper-slider-height);
      border-radius: 50%;
      background-color: var(--paper-slider-markers-color, #000);
    }

    .slider-knob {
      position: absolute;
      left: 0;
      top: 0;
      margin-left: calc(-15px - var(--calculated-paper-slider-height)/2);
      width: calc(30px + var(--calculated-paper-slider-height));
      height: calc(30px + var(--calculated-paper-slider-height));
    }

    .transiting > .slider-knob {
      transition: left 0.08s ease;
    }

    .slider-knob:focus {
      outline: none;
    }

    .slider-knob.dragging {
      transition: none;
    }

    .snaps > .slider-knob.dragging {
      transition: -webkit-transform 0.08s ease;
      transition: transform 0.08s ease;
    }

    .slider-knob-inner {
      margin: 10px;
      width: calc(100% - 20px);
      height: calc(100% - 20px);
      background-color: var(--paper-slider-knob-color, var(--google-blue-700));
      border: 2px solid var(--paper-slider-knob-color, var(--google-blue-700));
      border-radius: 50%;

      -moz-box-sizing: border-box;
      box-sizing: border-box;

      transition-property: -webkit-transform, background-color, border;
      transition-property: transform, background-color, border;
      transition-duration: 0.18s;
      transition-timing-function: ease;
    }

    .expand:not(.pin) > .slider-knob > .slider-knob-inner {
      -webkit-transform: scale(1.5);
      transform: scale(1.5);
    }

    .ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-color, var(--google-blue-700));
    }

    .pin > .slider-knob > .slider-knob-inner::before {
      content: "";
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -13px;
      width: 26px;
      height: 26px;
      border-radius: 50% 50% 50% 0;

      -webkit-transform: rotate(-45deg) scale(0) translate(0);
      transform: rotate(-45deg) scale(0) translate(0);
    }

    .slider-knob-inner::before,
    .slider-knob-inner::after {
      transition: -webkit-transform .18s ease, background-color .18s ease;
      transition: transform .18s ease, background-color .18s ease;
    }

    .pin.ring > .slider-knob > .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-start-color, var(--paper-grey-400));
    }

    .pin.expand > .slider-knob > .slider-knob-inner::before {
      -webkit-transform: rotate(-45deg) scale(1) translate(17px, -17px);
      transform: rotate(-45deg) scale(1) translate(17px, -17px);
    }

    .pin > .slider-knob > .slider-knob-inner::after {
      content: attr(value);
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -16px;
      width: 32px;
      height: 26px;
      text-align: center;
      color: var(--paper-slider-font-color, #fff);
      font-size: 10px;

      -webkit-transform: scale(0) translate(0);
      transform: scale(0) translate(0);
    }

    .pin.expand > .slider-knob > .slider-knob-inner::after {
      -webkit-transform: scale(1) translate(0, -17px);
      transform: scale(1) translate(0, -17px);
    }

    /* paper-input */
    .slider-input {
      width: 50px;
      overflow: hidden;
      --paper-input-container-input: {
        text-align: center;
        @apply --paper-slider-input-container-input;
      };
      @apply --paper-slider-input;
    }

    /* disabled state */
    #sliderContainer.disabled {
      pointer-events: none;
    }

    .disabled > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      border: 2px solid var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      -webkit-transform: scale3d(0.75, 0.75, 1);
      transform: scale3d(0.75, 0.75, 1);
    }

    .disabled.ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    paper-ripple {
      color: var(--paper-slider-knob-color, var(--google-blue-700));
    }
  </style>

  <div id="sliderContainer" class\$="[[_getClassNames(disabled, pin, snaps, immediateValue, min, expand, dragging, transiting, editable)]]">
    <div class="bar-container">
      <paper-progress disabled\$="[[disabled]]" id="sliderBar" aria-hidden="true" min="[[min]]" max="[[max]]" step="[[step]]" value="[[immediateValue]]" secondary-progress="[[secondaryProgress]]" on-down="_bardown" on-up="_resetKnob" on-track="_bartrack" on-tap="_barclick">
      </paper-progress>
    </div>

    <template is="dom-if" if="[[snaps]]">
      <div class="slider-markers">
        <template is="dom-repeat" items="[[markers]]">
          <div class="slider-marker"></div>
        </template>
      </div>
    </template>

    <div id="sliderKnob" class="slider-knob" on-down="_knobdown" on-up="_resetKnob" on-track="_onTrack" on-transitionend="_knobTransitionEnd">
        <div class="slider-knob-inner" value\$="[[immediateValue]]"></div>
    </div>
  </div>

  <template is="dom-if" if="[[editable]]">
    <paper-input id="input" type="number" step="[[step]]" min="[[min]]" max="[[max]]" class="slider-input" disabled\$="[[disabled]]" value="[[immediateValue]]" on-change="_changeValue" on-keydown="_inputKeyDown" no-label-float>
    </paper-input>
  </template>
`;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__.a)({_template:template,is:"paper-slider",behaviors:[_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a,_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.a,_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__.a],properties:{value:{type:Number,value:0},snaps:{type:Boolean,value:!1,notify:!0},pin:{type:Boolean,value:!1,notify:!0},secondaryProgress:{type:Number,value:0,notify:!0,observer:"_secondaryProgressChanged"},editable:{type:Boolean,value:!1},immediateValue:{type:Number,value:0,readOnly:!0,notify:!0},maxMarkers:{type:Number,value:0,notify:!0},expand:{type:Boolean,value:!1,readOnly:!0},ignoreBarTouch:{type:Boolean,value:!1},dragging:{type:Boolean,value:!1,readOnly:!0,notify:!0},transiting:{type:Boolean,value:!1,readOnly:!0},markers:{type:Array,readOnly:!0,value:function(){return[]}}},observers:["_updateKnob(value, min, max, snaps, step)","_valueChanged(value)","_immediateValueChanged(immediateValue)","_updateMarkers(maxMarkers, min, max, snaps)"],hostAttributes:{role:"slider",tabindex:0},keyBindings:{left:"_leftKey",right:"_rightKey","down pagedown home":"_decrementKey","up pageup end":"_incrementKey"},ready:function(){if(this.ignoreBarTouch){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__.f)(this.$.sliderBar,"auto")}},increment:function(){this.value=this._clampValue(this.value+this.step)},decrement:function(){this.value=this._clampValue(this.value-this.step)},_updateKnob:function(value,min,max,snaps,step){this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max);this.setAttribute("aria-valuenow",value);this._positionKnob(100*this._calcRatio(value))},_valueChanged:function(){this.fire("value-change",{composed:!0})},_immediateValueChanged:function(){if(this.dragging){this.fire("immediate-value-change",{composed:!0})}else{this.value=this.immediateValue}},_secondaryProgressChanged:function(){this.secondaryProgress=this._clampValue(this.secondaryProgress)},_expandKnob:function(){this._setExpand(!0)},_resetKnob:function(){this.cancelDebouncer("expandKnob");this._setExpand(!1)},_positionKnob:function(ratio){this._setImmediateValue(this._calcStep(this._calcKnobPosition(ratio)));this._setRatio(100*this._calcRatio(this.immediateValue));this.$.sliderKnob.style.left=this.ratio+"%";if(this.dragging){this._knobstartx=this.ratio*this._w/100;this.translate3d(0,0,0,this.$.sliderKnob)}},_calcKnobPosition:function(ratio){return(this.max-this.min)*ratio/100+this.min},_onTrack:function(event){event.stopPropagation();switch(event.detail.state){case"start":this._trackStart(event);break;case"track":this._trackX(event);break;case"end":this._trackEnd();break;}},_trackStart:function(event){this._setTransiting(!1);this._w=this.$.sliderBar.offsetWidth;this._x=this.ratio*this._w/100;this._startx=this._x;this._knobstartx=this._startx;this._minx=-this._startx;this._maxx=this._w-this._startx;this.$.sliderKnob.classList.add("dragging");this._setDragging(!0)},_trackX:function(event){if(!this.dragging){this._trackStart(event)}var direction=this._isRTL?-1:1,dx=Math.min(this._maxx,Math.max(this._minx,event.detail.dx*direction));this._x=this._startx+dx;var immediateValue=this._calcStep(this._calcKnobPosition(100*(this._x/this._w)));this._setImmediateValue(immediateValue);var translateX=this._calcRatio(this.immediateValue)*this._w-this._knobstartx;this.translate3d(translateX+"px",0,0,this.$.sliderKnob)},_trackEnd:function(){var s=this.$.sliderKnob.style;this.$.sliderKnob.classList.remove("dragging");this._setDragging(!1);this._resetKnob();this.value=this.immediateValue;s.transform=s.webkitTransform="";this.fire("change",{composed:!0})},_knobdown:function(event){this._expandKnob();event.preventDefault();this.focus()},_bartrack:function(event){if(this._allowBarEvent(event)){this._onTrack(event)}},_barclick:function(event){this._w=this.$.sliderBar.offsetWidth;var rect=this.$.sliderBar.getBoundingClientRect(),ratio=100*((event.detail.x-rect.left)/this._w);if(this._isRTL){ratio=100-ratio}var prevRatio=this.ratio;this._setTransiting(!0);this._positionKnob(ratio);if(prevRatio===this.ratio){this._setTransiting(!1)}this.async(function(){this.fire("change",{composed:!0})});event.preventDefault();this.focus()},_bardown:function(event){if(this._allowBarEvent(event)){this.debounce("expandKnob",this._expandKnob,60);this._barclick(event)}},_knobTransitionEnd:function(event){if(event.target===this.$.sliderKnob){this._setTransiting(!1)}},_updateMarkers:function(maxMarkers,min,max,snaps){if(!snaps){this._setMarkers([])}var steps=Math.round((max-min)/this.step);if(steps>maxMarkers){steps=maxMarkers}if(0>steps||!isFinite(steps)){steps=0}this._setMarkers(Array(steps))},_mergeClasses:function(classes){return Object.keys(classes).filter(function(className){return classes[className]}).join(" ")},_getClassNames:function(){return this._mergeClasses({disabled:this.disabled,pin:this.pin,snaps:this.snaps,ring:this.immediateValue<=this.min,expand:this.expand,dragging:this.dragging,transiting:this.transiting,editable:this.editable})},_allowBarEvent:function(event){return!this.ignoreBarTouch||event.detail.sourceEvent instanceof MouseEvent},get _isRTL(){if(this.__isRTL===void 0){this.__isRTL="rtl"===window.getComputedStyle(this).direction}return this.__isRTL},_leftKey:function(event){if(this._isRTL)this._incrementKey(event);else this._decrementKey(event)},_rightKey:function(event){if(this._isRTL)this._decrementKey(event);else this._incrementKey(event)},_incrementKey:function(event){if(!this.disabled){if("end"===event.detail.key){this.value=this.max}else{this.increment()}this.fire("change");event.preventDefault()}},_decrementKey:function(event){if(!this.disabled){if("home"===event.detail.key){this.value=this.min}else{this.decrement()}this.fire("change");event.preventDefault()}},_changeValue:function(event){this.value=event.target.value;this.fire("change",{composed:!0})},_inputKeyDown:function(event){event.stopPropagation()},_createRipple:function(){this._rippleContainer=this.$.sliderKnob;return _polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.b._createRipple.call(this)},_focusedChanged:function(receivedFocusFromKeyboard){if(receivedFocusFromKeyboard){this.ensureRipple()}if(this.hasRipple()){if(receivedFocusFromKeyboard){this._ripple.style.display=""}else{this._ripple.style.display="none"}this._ripple.holdDown=receivedFocusFromKeyboard}}})},159:function(module,__webpack_exports__,__webpack_require__){"use strict";var _compute_object_id__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(177);__webpack_exports__.a=stateObj=>stateObj.attributes.friendly_name===void 0?Object(_compute_object_id__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj.entity_id).replace(/_/g," "):stateObj.attributes.friendly_name||""},160:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(40),_polymer_iron_image_iron_image_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(171),_polymer_paper_styles_element_styles_paper_material_styles_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(168),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(41),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_6__.a`
    <style include="paper-material-styles">
      :host {
        display: inline-block;
        position: relative;
        box-sizing: border-box;
        background-color: var(--paper-card-background-color, var(--primary-background-color));
        border-radius: 2px;

        @apply --paper-font-common-base;
        @apply --paper-card;
      }

      /* IE 10 support for HTML5 hidden attr */
      :host([hidden]), [hidden] {
        display: none !important;
      }

      .header {
        position: relative;
        border-top-left-radius: inherit;
        border-top-right-radius: inherit;
        overflow: hidden;

        @apply --paper-card-header;
      }

      .header iron-image {
        display: block;
        width: 100%;
        --iron-image-width: 100%;
        pointer-events: none;

        @apply --paper-card-header-image;
      }

      .header .title-text {
        padding: 16px;
        font-size: 24px;
        font-weight: 400;
        color: var(--paper-card-header-color, #000);

        @apply --paper-card-header-text;
      }

      .header .title-text.over-image {
        position: absolute;
        bottom: 0px;

        @apply --paper-card-header-image-text;
      }

      :host ::slotted(.card-content) {
        padding: 16px;
        position:relative;

        @apply --paper-card-content;
      }

      :host ::slotted(.card-actions) {
        border-top: 1px solid #e8e8e8;
        padding: 5px 16px;
        position:relative;

        @apply --paper-card-actions;
      }

      :host([elevation="1"]) {
        @apply --paper-material-elevation-1;
      }

      :host([elevation="2"]) {
        @apply --paper-material-elevation-2;
      }

      :host([elevation="3"]) {
        @apply --paper-material-elevation-3;
      }

      :host([elevation="4"]) {
        @apply --paper-material-elevation-4;
      }

      :host([elevation="5"]) {
        @apply --paper-material-elevation-5;
      }
    </style>

    <div class="header">
      <iron-image hidden\$="[[!image]]" aria-hidden\$="[[_isHidden(image)]]" src="[[image]]" alt="[[alt]]" placeholder="[[placeholderImage]]" preload="[[preloadImage]]" fade="[[fadeImage]]"></iron-image>
      <div hidden\$="[[!heading]]" class\$="title-text [[_computeHeadingClass(image)]]">[[heading]]</div>
    </div>

    <slot></slot>
`,is:"paper-card",properties:{heading:{type:String,value:"",observer:"_headingChanged"},image:{type:String,value:""},alt:{type:String},preloadImage:{type:Boolean,value:!1},fadeImage:{type:Boolean,value:!1},placeholderImage:{type:String,value:null},elevation:{type:Number,value:1,reflectToAttribute:!0},animatedShadow:{type:Boolean,value:!1},animated:{type:Boolean,reflectToAttribute:!0,readOnly:!0,computed:"_computeAnimated(animatedShadow)"}},_isHidden:function(image){return image?"false":"true"},_headingChanged:function(heading){var currentHeading=this.getAttribute("heading"),currentLabel=this.getAttribute("aria-label");if("string"!==typeof currentLabel||currentLabel===currentHeading){this.setAttribute("aria-label",heading)}},_computeHeadingClass:function(image){return image?" over-image":""},_computeAnimated:function(animatedShadow){return animatedShadow}})},161:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__.a`
/* Most common used flex styles*/
<dom-module id="iron-flex">
  <template>
    <style>
      .layout.horizontal,
      .layout.vertical {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.inline {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      }

      .layout.horizontal {
        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      }

      .layout.vertical {
        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      }

      .layout.wrap {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      }

      .layout.no-wrap {
        -ms-flex-wrap: nowrap;
        -webkit-flex-wrap: nowrap;
        flex-wrap: nowrap;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .flex {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-auto {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      }

      .flex-none {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      }
    </style>
  </template>
</dom-module>
/* Basic flexbox reverse styles */
<dom-module id="iron-flex-reverse">
  <template>
    <style>
      .layout.horizontal-reverse,
      .layout.vertical-reverse {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      }

      .layout.horizontal-reverse {
        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      }

      .layout.vertical-reverse {
        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      }

      .layout.wrap-reverse {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      }
    </style>
  </template>
</dom-module>
/* Flexbox alignment */
<dom-module id="iron-flex-alignment">
  <template>
    <style>
      /**
       * Alignment in cross axis.
       */
      .layout.start {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      }

      .layout.center,
      .layout.center-center {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .layout.end {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      }

      .layout.baseline {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      }

      /**
       * Alignment in main axis.
       */
      .layout.start-justified {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      }

      .layout.center-justified,
      .layout.center-center {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      }

      .layout.end-justified {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      }

      .layout.around-justified {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      }

      .layout.justified {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      }

      /**
       * Self alignment.
       */
      .self-start {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      }

      .self-center {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      }

      .self-end {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      }

      .self-stretch {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      }

      .self-baseline {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      }

      /**
       * multi-line alignment in main axis.
       */
      .layout.start-aligned {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      }

      .layout.end-aligned {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      }

      .layout.center-aligned {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      }

      .layout.between-aligned {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      }

      .layout.around-aligned {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      }
    </style>
  </template>
</dom-module>
/* Non-flexbox positioning helper styles */
<dom-module id="iron-flex-factors">
  <template>
    <style>
      .flex,
      .flex-1 {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      }

      .flex-2 {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      }

      .flex-3 {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      }

      .flex-4 {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      }

      .flex-5 {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      }

      .flex-6 {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      }

      .flex-7 {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      }

      .flex-8 {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      }

      .flex-9 {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      }

      .flex-10 {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      }

      .flex-11 {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      }

      .flex-12 {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      }
    </style>
  </template>
</dom-module>
<dom-module id="iron-positioning">
  <template>
    <style>
      .block {
        display: block;
      }

      [hidden] {
        display: none !important;
      }

      .invisible {
        visibility: hidden !important;
      }

      .relative {
        position: relative;
      }

      .fit {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      }

      body.fullbleed {
        margin: 0;
        height: 100vh;
      }

      .scroll {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      }

      /* fixed position */
      .fixed-bottom,
      .fixed-left,
      .fixed-right,
      .fixed-top {
        position: fixed;
      }

      .fixed-top {
        top: 0;
        left: 0;
        right: 0;
      }

      .fixed-right {
        top: 0;
        right: 0;
        bottom: 0;
      }

      .fixed-bottom {
        right: 0;
        bottom: 0;
        left: 0;
      }

      .fixed-left {
        top: 0;
        bottom: 0;
        left: 0;
      }
    </style>
  </template>
</dom-module>
`;template.setAttribute("style","display: none;");document.head.appendChild(template.content)},162:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeStateDomain});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(166);function computeStateDomain(stateObj){return Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj.entity_id)}},163:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return domainIcon});var _const__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(109);const fixedIcons={alert:"hass:alert",automation:"hass:playlist-play",calendar:"hass:calendar",camera:"hass:video",climate:"hass:thermostat",configurator:"hass:settings",conversation:"hass:text-to-speech",device_tracker:"hass:account",fan:"hass:fan",group:"hass:google-circles-communities",history_graph:"hass:chart-line",homeassistant:"hass:home-assistant",homekit:"hass:home-automation",image_processing:"hass:image-filter-frames",input_boolean:"hass:drawing",input_datetime:"hass:calendar-clock",input_number:"hass:ray-vertex",input_select:"hass:format-list-bulleted",input_text:"hass:textbox",light:"hass:lightbulb",mailbox:"hass:mailbox",notify:"hass:comment-alert",person:"hass:account",plant:"hass:flower",proximity:"hass:apple-safari",remote:"hass:remote",scene:"hass:google-pages",script:"hass:file-document",sensor:"hass:eye",simple_alarm:"hass:bell",sun:"hass:white-balance-sunny",switch:"hass:flash",timer:"hass:timer",updater:"hass:cloud-upload",vacuum:"hass:robot-vacuum",water_heater:"hass:thermometer",weblink:"hass:open-in-new"};function domainIcon(domain,state){if(domain in fixedIcons){return fixedIcons[domain]}switch(domain){case"alarm_control_panel":switch(state){case"armed_home":return"hass:bell-plus";case"armed_night":return"hass:bell-sleep";case"disarmed":return"hass:bell-outline";case"triggered":return"hass:bell-ring";default:return"hass:bell";}case"binary_sensor":return state&&"off"===state?"hass:radiobox-blank":"hass:checkbox-marked-circle";case"cover":return"closed"===state?"hass:window-closed":"hass:window-open";case"lock":return state&&"unlocked"===state?"hass:lock-open":"hass:lock";case"media_player":return state&&"off"!==state&&"idle"!==state?"hass:cast-connected":"hass:cast";case"zwave":switch(state){case"dead":return"hass:emoticon-dead";case"sleeping":return"hass:sleep";case"initializing":return"hass:timer-sand";default:return"hass:z-wave";}default:console.warn("Unable to find icon for domain "+domain+" ("+state+")");return _const__WEBPACK_IMPORTED_MODULE_0__.a;}}},164:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return HaIcon});var _polymer_iron_icon_iron_icon__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(97);const ironIconClass=customElements.get("iron-icon");let loaded=!1;class HaIcon extends ironIconClass{constructor(...args){super(...args);this._iconsetName=void 0}listen(node,eventName,methodName){super.listen(node,eventName,methodName);if(!loaded&&"mdi"===this._iconsetName){loaded=!0;__webpack_require__.e(58).then(__webpack_require__.bind(null,205))}}}customElements.define("ha-icon",HaIcon)},166:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeDomain});function computeDomain(entityId){return entityId.substr(0,entityId.indexOf("."))}},168:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_shadow_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(98),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(3);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
<dom-module id="paper-material-styles">
  <template>
    <style>
      html {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      .paper-material {
        @apply --paper-material;
      }
      .paper-material[elevation="1"] {
        @apply --paper-material-elevation-1;
      }
      .paper-material[elevation="2"] {
        @apply --paper-material-elevation-2;
      }
      .paper-material[elevation="3"] {
        @apply --paper-material-elevation-3;
      }
      .paper-material[elevation="4"] {
        @apply --paper-material-elevation-4;
      }
      .paper-material[elevation="5"] {
        @apply --paper-material-elevation-5;
      }

      /* Duplicate the styles because of https://github.com/webcomponents/shadycss/issues/193 */
      :host {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      :host(.paper-material) {
        @apply --paper-material;
      }
      :host(.paper-material[elevation="1"]) {
        @apply --paper-material-elevation-1;
      }
      :host(.paper-material[elevation="2"]) {
        @apply --paper-material-elevation-2;
      }
      :host(.paper-material[elevation="3"]) {
        @apply --paper-material-elevation-3;
      }
      :host(.paper-material[elevation="4"]) {
        @apply --paper-material-elevation-4;
      }
      :host(.paper-material[elevation="5"]) {
        @apply --paper-material-elevation-5;
      }
    </style>
  </template>
</dom-module>`;template.setAttribute("style","display: none;");document.head.appendChild(template.content)},170:function(module,__webpack_exports__,__webpack_require__){"use strict";var lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5),_ha_icon__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(164),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(162),_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(178);function _decorate(decorators,factory,superClass,mixins){var api=_getDecoratorsApi();if(mixins){for(var i=0;i<mixins.length;i++){api=mixins[i](api)}}var r=factory(function initialize(O){api.initializeInstanceElements(O,decorated.elements)},superClass),decorated=api.decorateClass(_coalesceClassElements(r.d.map(_createElementDescriptor)),decorators);api.initializeClassElements(r.F,decorated.elements);return api.runClassFinishers(r.F,decorated.finishers)}function _getDecoratorsApi(){_getDecoratorsApi=function(){return api};var api={elementsDefinitionOrder:[["method"],["field"]],initializeInstanceElements:function(O,elements){["method","field"].forEach(function(kind){elements.forEach(function(element){if(element.kind===kind&&"own"===element.placement){this.defineClassElement(O,element)}},this)},this)},initializeClassElements:function(F,elements){var proto=F.prototype;["method","field"].forEach(function(kind){elements.forEach(function(element){var placement=element.placement;if(element.kind===kind&&("static"===placement||"prototype"===placement)){var receiver="static"===placement?F:proto;this.defineClassElement(receiver,element)}},this)},this)},defineClassElement:function(receiver,element){var descriptor=element.descriptor;if("field"===element.kind){var initializer=element.initializer;descriptor={enumerable:descriptor.enumerable,writable:descriptor.writable,configurable:descriptor.configurable,value:void 0===initializer?void 0:initializer.call(receiver)}}Object.defineProperty(receiver,element.key,descriptor)},decorateClass:function(elements,decorators){var newElements=[],finishers=[],placements={static:[],prototype:[],own:[]};elements.forEach(function(element){this.addElementPlacement(element,placements)},this);elements.forEach(function(element){if(!_hasDecorators(element))return newElements.push(element);var elementFinishersExtras=this.decorateElement(element,placements);newElements.push(elementFinishersExtras.element);newElements.push.apply(newElements,elementFinishersExtras.extras);finishers.push.apply(finishers,elementFinishersExtras.finishers)},this);if(!decorators){return{elements:newElements,finishers:finishers}}var result=this.decorateConstructor(newElements,decorators);finishers.push.apply(finishers,result.finishers);result.finishers=finishers;return result},addElementPlacement:function(element,placements,silent){var keys=placements[element.placement];if(!silent&&-1!==keys.indexOf(element.key)){throw new TypeError("Duplicated element ("+element.key+")")}keys.push(element.key)},decorateElement:function(element,placements){for(var extras=[],finishers=[],decorators=element.decorators,i=decorators.length-1,keys;0<=i;i--){keys=placements[element.placement];keys.splice(keys.indexOf(element.key),1);var elementObject=this.fromElementDescriptor(element),elementFinisherExtras=this.toElementFinisherExtras((0,decorators[i])(elementObject)||elementObject);element=elementFinisherExtras.element;this.addElementPlacement(element,placements);if(elementFinisherExtras.finisher){finishers.push(elementFinisherExtras.finisher)}var newExtras=elementFinisherExtras.extras;if(newExtras){for(var j=0;j<newExtras.length;j++){this.addElementPlacement(newExtras[j],placements)}extras.push.apply(extras,newExtras)}}return{element:element,finishers:finishers,extras:extras}},decorateConstructor:function(elements,decorators){for(var finishers=[],i=decorators.length-1;0<=i;i--){var obj=this.fromClassDescriptor(elements),elementsAndFinisher=this.toClassDescriptor((0,decorators[i])(obj)||obj);if(elementsAndFinisher.finisher!==void 0){finishers.push(elementsAndFinisher.finisher)}if(elementsAndFinisher.elements!==void 0){elements=elementsAndFinisher.elements;for(var j=0;j<elements.length-1;j++){for(var k=j+1;k<elements.length;k++){if(elements[j].key===elements[k].key&&elements[j].placement===elements[k].placement){throw new TypeError("Duplicated element ("+elements[j].key+")")}}}}}return{elements:elements,finishers:finishers}},fromElementDescriptor:function(element){var obj={kind:element.kind,key:element.key,placement:element.placement,descriptor:element.descriptor},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);if("field"===element.kind)obj.initializer=element.initializer;return obj},toElementDescriptors:function(elementObjects){if(elementObjects===void 0)return;return _toArray(elementObjects).map(function(elementObject){var element=this.toElementDescriptor(elementObject);this.disallowProperty(elementObject,"finisher","An element descriptor");this.disallowProperty(elementObject,"extras","An element descriptor");return element},this)},toElementDescriptor:function(elementObject){var kind=elementObject.kind+"";if("method"!==kind&&"field"!==kind){throw new TypeError("An element descriptor's .kind property must be either \"method\" or"+" \"field\", but a decorator created an element descriptor with"+" .kind \""+kind+"\"")}var key=_toPropertyKey(elementObject.key),placement=elementObject.placement+"";if("static"!==placement&&"prototype"!==placement&&"own"!==placement){throw new TypeError("An element descriptor's .placement property must be one of \"static\","+" \"prototype\" or \"own\", but a decorator created an element descriptor"+" with .placement \""+placement+"\"")}var descriptor=elementObject.descriptor;this.disallowProperty(elementObject,"elements","An element descriptor");var element={kind:kind,key:key,placement:placement,descriptor:Object.assign({},descriptor)};if("field"!==kind){this.disallowProperty(elementObject,"initializer","A method descriptor")}else{this.disallowProperty(descriptor,"get","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"set","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"value","The property descriptor of a field descriptor");element.initializer=elementObject.initializer}return element},toElementFinisherExtras:function(elementObject){var element=this.toElementDescriptor(elementObject),finisher=_optionalCallableProperty(elementObject,"finisher"),extras=this.toElementDescriptors(elementObject.extras);return{element:element,finisher:finisher,extras:extras}},fromClassDescriptor:function(elements){var obj={kind:"class",elements:elements.map(this.fromElementDescriptor,this)},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);return obj},toClassDescriptor:function(obj){var kind=obj.kind+"";if("class"!==kind){throw new TypeError("A class descriptor's .kind property must be \"class\", but a decorator"+" created a class descriptor with .kind \""+kind+"\"")}this.disallowProperty(obj,"key","A class descriptor");this.disallowProperty(obj,"placement","A class descriptor");this.disallowProperty(obj,"descriptor","A class descriptor");this.disallowProperty(obj,"initializer","A class descriptor");this.disallowProperty(obj,"extras","A class descriptor");var finisher=_optionalCallableProperty(obj,"finisher"),elements=this.toElementDescriptors(obj.elements);return{elements:elements,finisher:finisher}},runClassFinishers:function(constructor,finishers){for(var i=0,newConstructor;i<finishers.length;i++){newConstructor=(0,finishers[i])(constructor);if(newConstructor!==void 0){if("function"!==typeof newConstructor){throw new TypeError("Finishers must return a constructor.")}constructor=newConstructor}}return constructor},disallowProperty:function(obj,name,objectType){if(obj[name]!==void 0){throw new TypeError(objectType+" can't have a ."+name+" property.")}}};return api}function _createElementDescriptor(def){var key=_toPropertyKey(def.key),descriptor;if("method"===def.kind){descriptor={value:def.value,writable:!0,configurable:!0,enumerable:!1}}else if("get"===def.kind){descriptor={get:def.value,configurable:!0,enumerable:!1}}else if("set"===def.kind){descriptor={set:def.value,configurable:!0,enumerable:!1}}else if("field"===def.kind){descriptor={configurable:!0,writable:!0,enumerable:!0}}var element={kind:"field"===def.kind?"field":"method",key:key,placement:def.static?"static":"field"===def.kind?"own":"prototype",descriptor:descriptor};if(def.decorators)element.decorators=def.decorators;if("field"===def.kind)element.initializer=def.value;return element}function _coalesceGetterSetter(element,other){if(element.descriptor.get!==void 0){other.descriptor.get=element.descriptor.get}else{other.descriptor.set=element.descriptor.set}}function _coalesceClassElements(elements){for(var newElements=[],isSameElement=function(other){return"method"===other.kind&&other.key===element.key&&other.placement===element.placement},i=0;i<elements.length;i++){var element=elements[i],other;if("method"===element.kind&&(other=newElements.find(isSameElement))){if(_isDataDescriptor(element.descriptor)||_isDataDescriptor(other.descriptor)){if(_hasDecorators(element)||_hasDecorators(other)){throw new ReferenceError("Duplicated methods ("+element.key+") can't be decorated.")}other.descriptor=element.descriptor}else{if(_hasDecorators(element)){if(_hasDecorators(other)){throw new ReferenceError("Decorators can't be placed on different accessors with for "+"the same property ("+element.key+").")}other.decorators=element.decorators}_coalesceGetterSetter(element,other)}}else{newElements.push(element)}}return newElements}function _hasDecorators(element){return element.decorators&&element.decorators.length}function _isDataDescriptor(desc){return desc!==void 0&&!(desc.value===void 0&&desc.writable===void 0)}function _optionalCallableProperty(obj,name){var value=obj[name];if(value!==void 0&&"function"!==typeof value){throw new TypeError("Expected '"+name+"' to be a function")}return value}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return"symbol"===typeof key?key:key+""}function _toPrimitive(input,hint){if("object"!==typeof input||null===input)return input;var prim=input[Symbol.toPrimitive];if(prim!==void 0){var res=prim.call(input,hint||"default");if("object"!==typeof res)return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===hint?String:Number)(input)}function _toArray(arr){return _arrayWithHoles(arr)||_iterableToArray(arr)||_nonIterableRest()}function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance")}function _iterableToArray(iter){if(Symbol.iterator in Object(iter)||"[object Arguments]"===Object.prototype.toString.call(iter))return Array.from(iter)}function _arrayWithHoles(arr){if(Array.isArray(arr))return arr}let StateBadge=_decorate(null,function(_initialize,_LitElement){class StateBadge extends _LitElement{constructor(...args){super(...args);_initialize(this)}}return{F:StateBadge,d:[{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_0__.f)()],key:"stateObj",value:void 0},{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_0__.f)()],key:"overrideIcon",value:void 0},{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_0__.g)("ha-icon")],key:"_icon",value:void 0},{kind:"method",key:"render",value:function render(){const stateObj=this.stateObj;if(!stateObj){return lit_element__WEBPACK_IMPORTED_MODULE_0__.e``}return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
      <ha-icon
        id="icon"
        data-domain=${Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__.a)(stateObj)}
        data-state=${stateObj.state}
        .icon=${this.overrideIcon||Object(_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_3__.a)(stateObj)}
      ></ha-icon>
    `}},{kind:"method",key:"updated",value:function updated(changedProps){if(!changedProps.has("stateObj")){return}const stateObj=this.stateObj,iconStyle={color:"",filter:""},hostStyle={backgroundImage:""};if(stateObj){if(stateObj.attributes.entity_picture){hostStyle.backgroundImage="url("+stateObj.attributes.entity_picture+")";iconStyle.display="none"}else{if(stateObj.attributes.hs_color){const hue=stateObj.attributes.hs_color[0],sat=stateObj.attributes.hs_color[1];if(10<sat){iconStyle.color=`hsl(${hue}, 100%, ${100-sat/2}%)`}}if(stateObj.attributes.brightness){const brightness=stateObj.attributes.brightness;if("number"!==typeof brightness){const errorMessage=`Type error: state-badge expected number, but type of ${stateObj.entity_id}.attributes.brightness is ${typeof brightness} (${brightness})`;console.warn(errorMessage)}iconStyle.filter=`brightness(${(brightness+245)/5}%)`}}}Object.assign(this._icon.style,iconStyle);Object.assign(this.style,hostStyle)}},{kind:"get",static:!0,key:"styles",value:function styles(){return lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      :host {
        position: relative;
        display: inline-block;
        width: 40px;
        color: var(--paper-item-icon-color, #44739e);
        border-radius: 50%;
        height: 40px;
        text-align: center;
        background-size: cover;
        line-height: 40px;
      }

      ha-icon {
        transition: color 0.3s ease-in-out, filter 0.3s ease-in-out;
      }

      /* Color the icon if light or sun is on */
      ha-icon[data-domain="light"][data-state="on"],
      ha-icon[data-domain="switch"][data-state="on"],
      ha-icon[data-domain="binary_sensor"][data-state="on"],
      ha-icon[data-domain="fan"][data-state="on"],
      ha-icon[data-domain="sun"][data-state="above_horizon"] {
        color: var(--paper-item-icon-active-color, #fdd835);
      }

      /* Color the icon if unavailable */
      ha-icon[data-state="unavailable"] {
        color: var(--state-icon-unavailable-color);
      }
    `}}]}},lit_element__WEBPACK_IMPORTED_MODULE_0__.a);customElements.define("state-badge",StateBadge)},171:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(3),_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(16);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        overflow: hidden;
        position: relative;
      }

      #baseURIAnchor {
        display: none;
      }

      #sizedImgDiv {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        display: none;
      }

      #img {
        display: block;
        width: var(--iron-image-width, auto);
        height: var(--iron-image-height, auto);
      }

      :host([sizing]) #sizedImgDiv {
        display: block;
      }

      :host([sizing]) #img {
        display: none;
      }

      #placeholder {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        background-color: inherit;
        opacity: 1;

        @apply --iron-image-placeholder;
      }

      #placeholder.faded-out {
        transition: opacity 0.5s linear;
        opacity: 0;
      }
    </style>

    <a id="baseURIAnchor" href="#"></a>
    <div id="sizedImgDiv" role="img" hidden\$="[[_computeImgDivHidden(sizing)]]" aria-hidden\$="[[_computeImgDivARIAHidden(alt)]]" aria-label\$="[[_computeImgDivARIALabel(alt, src)]]"></div>
    <img id="img" alt\$="[[alt]]" hidden\$="[[_computeImgHidden(sizing)]]" crossorigin\$="[[crossorigin]]" on-load="_imgOnLoad" on-error="_imgOnError">
    <div id="placeholder" hidden\$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]" class\$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>
`,is:"iron-image",properties:{src:{type:String,value:""},alt:{type:String,value:null},crossorigin:{type:String,value:null},preventLoad:{type:Boolean,value:!1},sizing:{type:String,value:null,reflectToAttribute:!0},position:{type:String,value:"center"},preload:{type:Boolean,value:!1},placeholder:{type:String,value:null,observer:"_placeholderChanged"},fade:{type:Boolean,value:!1},loaded:{notify:!0,readOnly:!0,type:Boolean,value:!1},loading:{notify:!0,readOnly:!0,type:Boolean,value:!1},error:{notify:!0,readOnly:!0,type:Boolean,value:!1},width:{observer:"_widthChanged",type:Number,value:null},height:{observer:"_heightChanged",type:Number,value:null}},observers:["_transformChanged(sizing, position)","_loadStateObserver(src, preventLoad)"],created:function(){this._resolvedSrc=""},_imgOnLoad:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this._setLoading(!1);this._setLoaded(!0);this._setError(!1)},_imgOnError:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";this._setLoading(!1);this._setLoaded(!1);this._setError(!0)},_computePlaceholderHidden:function(){return!this.preload||!this.fade&&!this.loading&&this.loaded},_computePlaceholderClassName:function(){return this.preload&&this.fade&&!this.loading&&this.loaded?"faded-out":""},_computeImgDivHidden:function(){return!this.sizing},_computeImgDivARIAHidden:function(){return""===this.alt?"true":void 0},_computeImgDivARIALabel:function(){if(null!==this.alt){return this.alt}if(""===this.src){return""}var resolved=this._resolveSrc(this.src);return resolved.replace(/[?|#].*/g,"").split("/").pop()},_computeImgHidden:function(){return!!this.sizing},_widthChanged:function(){this.style.width=isNaN(this.width)?this.width:this.width+"px"},_heightChanged:function(){this.style.height=isNaN(this.height)?this.height:this.height+"px"},_loadStateObserver:function(src,preventLoad){var newResolvedSrc=this._resolveSrc(src);if(newResolvedSrc===this._resolvedSrc){return}this._resolvedSrc="";this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";if(""===src||preventLoad){this._setLoading(!1);this._setLoaded(!1);this._setError(!1)}else{this._resolvedSrc=newResolvedSrc;this.$.img.src=this._resolvedSrc;this.$.sizedImgDiv.style.backgroundImage="url(\""+this._resolvedSrc+"\")";this._setLoading(!0);this._setLoaded(!1);this._setError(!1)}},_placeholderChanged:function(){this.$.placeholder.style.backgroundImage=this.placeholder?"url(\""+this.placeholder+"\")":""},_transformChanged:function(){var sizedImgDivStyle=this.$.sizedImgDiv.style,placeholderStyle=this.$.placeholder.style;sizedImgDivStyle.backgroundSize=placeholderStyle.backgroundSize=this.sizing;sizedImgDivStyle.backgroundPosition=placeholderStyle.backgroundPosition=this.sizing?this.position:"";sizedImgDivStyle.backgroundRepeat=placeholderStyle.backgroundRepeat=this.sizing?"no-repeat":""},_resolveSrc:function(testSrc){var resolved=Object(_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__.c)(testSrc,this.$.baseURIAnchor.href);if("/"===resolved[0]){resolved=(location.origin||location.protocol+"//"+location.host)+resolved}return resolved}})},173:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(60),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__),_paper_spinner_styles_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(137),_paper_spinner_styles_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_paper_spinner_styles_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(3),_paper_spinner_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(114);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
  <style include="paper-spinner-styles"></style>

  <div id="spinnerContainer" class-name="[[__computeContainerClasses(active, __coolingDown)]]" on-animationend="__reset" on-webkit-animation-end="__reset">
    <div class="spinner-layer layer-1">
      <div class="circle-clipper left"></div>
      <div class="circle-clipper right"></div>
    </div>

    <div class="spinner-layer layer-2">
      <div class="circle-clipper left"></div>
      <div class="circle-clipper right"></div>
    </div>

    <div class="spinner-layer layer-3">
      <div class="circle-clipper left"></div>
      <div class="circle-clipper right"></div>
    </div>

    <div class="spinner-layer layer-4">
      <div class="circle-clipper left"></div>
      <div class="circle-clipper right"></div>
    </div>
  </div>
`;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:template,is:"paper-spinner",behaviors:[_paper_spinner_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a]})},177:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeObjectId});function computeObjectId(entityId){return entityId.substr(entityId.indexOf(".")+1)}},178:function(module,__webpack_exports__,__webpack_require__){"use strict";var common_const=__webpack_require__(109),compute_domain=__webpack_require__(166),domain_icon=__webpack_require__(163);function binarySensorIcon(state){const activated=state.state&&"off"===state.state;switch(state.attributes.device_class){case"battery":return activated?"hass:battery":"hass:battery-outline";case"cold":return activated?"hass:thermometer":"hass:snowflake";case"connectivity":return activated?"hass:server-network-off":"hass:server-network";case"door":return activated?"hass:door-closed":"hass:door-open";case"garage_door":return activated?"hass:garage":"hass:garage-open";case"gas":case"power":case"problem":case"safety":case"smoke":return activated?"hass:shield-check":"hass:alert";case"heat":return activated?"hass:thermometer":"hass:fire";case"light":return activated?"hass:brightness-5":"hass:brightness-7";case"lock":return activated?"hass:lock":"hass:lock-open";case"moisture":return activated?"hass:water-off":"hass:water";case"motion":return activated?"hass:walk":"hass:run";case"occupancy":return activated?"hass:home-outline":"hass:home";case"opening":return activated?"hass:square":"hass:square-outline";case"plug":return activated?"hass:power-plug-off":"hass:power-plug";case"presence":return activated?"hass:home-outline":"hass:home";case"sound":return activated?"hass:music-note-off":"hass:music-note";case"vibration":return activated?"hass:crop-portrait":"hass:vibrate";case"window":return activated?"hass:window-closed":"hass:window-open";default:return activated?"hass:radiobox-blank":"hass:checkbox-marked-circle";}}function coverIcon(state){const open="closed"!==state.state;switch(state.attributes.device_class){case"garage":return open?"hass:garage-open":"hass:garage";default:return Object(domain_icon.a)("cover",state.state);}}const fixedDeviceClassIcons={humidity:"hass:water-percent",illuminance:"hass:brightness-5",temperature:"hass:thermometer",pressure:"hass:gauge"};function sensorIcon(state){const dclass=state.attributes.device_class;if(dclass&&dclass in fixedDeviceClassIcons){return fixedDeviceClassIcons[dclass]}if("battery"===dclass){const battery=+state.state;if(isNaN(battery)){return"hass:battery-unknown"}const batteryRound=10*Math.round(battery/10);if(100<=batteryRound){return"hass:battery"}if(0>=batteryRound){return"hass:battery-alert"}return`${"hass"}:battery-${batteryRound}`}const unit=state.attributes.unit_of_measurement;if(unit===common_const.j||unit===common_const.k){return"hass:thermometer"}return Object(domain_icon.a)("sensor")}function inputDateTimeIcon(state){if(!state.attributes.has_date){return"hass:clock"}if(!state.attributes.has_time){return"hass:calendar"}return Object(domain_icon.a)("input_datetime")}__webpack_require__.d(__webpack_exports__,"a",function(){return stateIcon});const domainIcons={binary_sensor:binarySensorIcon,cover:coverIcon,sensor:sensorIcon,input_datetime:inputDateTimeIcon};function stateIcon(state){if(!state){return common_const.a}if(state.attributes.icon){return state.attributes.icon}const domain=Object(compute_domain.a)(state.entity_id);if(domain in domainIcons){return domainIcons[domain](state)}return Object(domain_icon.a)(domain,state.state)}},180:function(module,__webpack_exports__,__webpack_require__){"use strict";var lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5);function _decorate(decorators,factory,superClass,mixins){var api=_getDecoratorsApi();if(mixins){for(var i=0;i<mixins.length;i++){api=mixins[i](api)}}var r=factory(function initialize(O){api.initializeInstanceElements(O,decorated.elements)},superClass),decorated=api.decorateClass(_coalesceClassElements(r.d.map(_createElementDescriptor)),decorators);api.initializeClassElements(r.F,decorated.elements);return api.runClassFinishers(r.F,decorated.finishers)}function _getDecoratorsApi(){_getDecoratorsApi=function(){return api};var api={elementsDefinitionOrder:[["method"],["field"]],initializeInstanceElements:function(O,elements){["method","field"].forEach(function(kind){elements.forEach(function(element){if(element.kind===kind&&"own"===element.placement){this.defineClassElement(O,element)}},this)},this)},initializeClassElements:function(F,elements){var proto=F.prototype;["method","field"].forEach(function(kind){elements.forEach(function(element){var placement=element.placement;if(element.kind===kind&&("static"===placement||"prototype"===placement)){var receiver="static"===placement?F:proto;this.defineClassElement(receiver,element)}},this)},this)},defineClassElement:function(receiver,element){var descriptor=element.descriptor;if("field"===element.kind){var initializer=element.initializer;descriptor={enumerable:descriptor.enumerable,writable:descriptor.writable,configurable:descriptor.configurable,value:void 0===initializer?void 0:initializer.call(receiver)}}Object.defineProperty(receiver,element.key,descriptor)},decorateClass:function(elements,decorators){var newElements=[],finishers=[],placements={static:[],prototype:[],own:[]};elements.forEach(function(element){this.addElementPlacement(element,placements)},this);elements.forEach(function(element){if(!_hasDecorators(element))return newElements.push(element);var elementFinishersExtras=this.decorateElement(element,placements);newElements.push(elementFinishersExtras.element);newElements.push.apply(newElements,elementFinishersExtras.extras);finishers.push.apply(finishers,elementFinishersExtras.finishers)},this);if(!decorators){return{elements:newElements,finishers:finishers}}var result=this.decorateConstructor(newElements,decorators);finishers.push.apply(finishers,result.finishers);result.finishers=finishers;return result},addElementPlacement:function(element,placements,silent){var keys=placements[element.placement];if(!silent&&-1!==keys.indexOf(element.key)){throw new TypeError("Duplicated element ("+element.key+")")}keys.push(element.key)},decorateElement:function(element,placements){for(var extras=[],finishers=[],decorators=element.decorators,i=decorators.length-1,keys;0<=i;i--){keys=placements[element.placement];keys.splice(keys.indexOf(element.key),1);var elementObject=this.fromElementDescriptor(element),elementFinisherExtras=this.toElementFinisherExtras((0,decorators[i])(elementObject)||elementObject);element=elementFinisherExtras.element;this.addElementPlacement(element,placements);if(elementFinisherExtras.finisher){finishers.push(elementFinisherExtras.finisher)}var newExtras=elementFinisherExtras.extras;if(newExtras){for(var j=0;j<newExtras.length;j++){this.addElementPlacement(newExtras[j],placements)}extras.push.apply(extras,newExtras)}}return{element:element,finishers:finishers,extras:extras}},decorateConstructor:function(elements,decorators){for(var finishers=[],i=decorators.length-1;0<=i;i--){var obj=this.fromClassDescriptor(elements),elementsAndFinisher=this.toClassDescriptor((0,decorators[i])(obj)||obj);if(elementsAndFinisher.finisher!==void 0){finishers.push(elementsAndFinisher.finisher)}if(elementsAndFinisher.elements!==void 0){elements=elementsAndFinisher.elements;for(var j=0;j<elements.length-1;j++){for(var k=j+1;k<elements.length;k++){if(elements[j].key===elements[k].key&&elements[j].placement===elements[k].placement){throw new TypeError("Duplicated element ("+elements[j].key+")")}}}}}return{elements:elements,finishers:finishers}},fromElementDescriptor:function(element){var obj={kind:element.kind,key:element.key,placement:element.placement,descriptor:element.descriptor},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);if("field"===element.kind)obj.initializer=element.initializer;return obj},toElementDescriptors:function(elementObjects){if(elementObjects===void 0)return;return _toArray(elementObjects).map(function(elementObject){var element=this.toElementDescriptor(elementObject);this.disallowProperty(elementObject,"finisher","An element descriptor");this.disallowProperty(elementObject,"extras","An element descriptor");return element},this)},toElementDescriptor:function(elementObject){var kind=elementObject.kind+"";if("method"!==kind&&"field"!==kind){throw new TypeError("An element descriptor's .kind property must be either \"method\" or"+" \"field\", but a decorator created an element descriptor with"+" .kind \""+kind+"\"")}var key=_toPropertyKey(elementObject.key),placement=elementObject.placement+"";if("static"!==placement&&"prototype"!==placement&&"own"!==placement){throw new TypeError("An element descriptor's .placement property must be one of \"static\","+" \"prototype\" or \"own\", but a decorator created an element descriptor"+" with .placement \""+placement+"\"")}var descriptor=elementObject.descriptor;this.disallowProperty(elementObject,"elements","An element descriptor");var element={kind:kind,key:key,placement:placement,descriptor:Object.assign({},descriptor)};if("field"!==kind){this.disallowProperty(elementObject,"initializer","A method descriptor")}else{this.disallowProperty(descriptor,"get","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"set","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"value","The property descriptor of a field descriptor");element.initializer=elementObject.initializer}return element},toElementFinisherExtras:function(elementObject){var element=this.toElementDescriptor(elementObject),finisher=_optionalCallableProperty(elementObject,"finisher"),extras=this.toElementDescriptors(elementObject.extras);return{element:element,finisher:finisher,extras:extras}},fromClassDescriptor:function(elements){var obj={kind:"class",elements:elements.map(this.fromElementDescriptor,this)},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);return obj},toClassDescriptor:function(obj){var kind=obj.kind+"";if("class"!==kind){throw new TypeError("A class descriptor's .kind property must be \"class\", but a decorator"+" created a class descriptor with .kind \""+kind+"\"")}this.disallowProperty(obj,"key","A class descriptor");this.disallowProperty(obj,"placement","A class descriptor");this.disallowProperty(obj,"descriptor","A class descriptor");this.disallowProperty(obj,"initializer","A class descriptor");this.disallowProperty(obj,"extras","A class descriptor");var finisher=_optionalCallableProperty(obj,"finisher"),elements=this.toElementDescriptors(obj.elements);return{elements:elements,finisher:finisher}},runClassFinishers:function(constructor,finishers){for(var i=0,newConstructor;i<finishers.length;i++){newConstructor=(0,finishers[i])(constructor);if(newConstructor!==void 0){if("function"!==typeof newConstructor){throw new TypeError("Finishers must return a constructor.")}constructor=newConstructor}}return constructor},disallowProperty:function(obj,name,objectType){if(obj[name]!==void 0){throw new TypeError(objectType+" can't have a ."+name+" property.")}}};return api}function _createElementDescriptor(def){var key=_toPropertyKey(def.key),descriptor;if("method"===def.kind){descriptor={value:def.value,writable:!0,configurable:!0,enumerable:!1}}else if("get"===def.kind){descriptor={get:def.value,configurable:!0,enumerable:!1}}else if("set"===def.kind){descriptor={set:def.value,configurable:!0,enumerable:!1}}else if("field"===def.kind){descriptor={configurable:!0,writable:!0,enumerable:!0}}var element={kind:"field"===def.kind?"field":"method",key:key,placement:def.static?"static":"field"===def.kind?"own":"prototype",descriptor:descriptor};if(def.decorators)element.decorators=def.decorators;if("field"===def.kind)element.initializer=def.value;return element}function _coalesceGetterSetter(element,other){if(element.descriptor.get!==void 0){other.descriptor.get=element.descriptor.get}else{other.descriptor.set=element.descriptor.set}}function _coalesceClassElements(elements){for(var newElements=[],isSameElement=function(other){return"method"===other.kind&&other.key===element.key&&other.placement===element.placement},i=0;i<elements.length;i++){var element=elements[i],other;if("method"===element.kind&&(other=newElements.find(isSameElement))){if(_isDataDescriptor(element.descriptor)||_isDataDescriptor(other.descriptor)){if(_hasDecorators(element)||_hasDecorators(other)){throw new ReferenceError("Duplicated methods ("+element.key+") can't be decorated.")}other.descriptor=element.descriptor}else{if(_hasDecorators(element)){if(_hasDecorators(other)){throw new ReferenceError("Decorators can't be placed on different accessors with for "+"the same property ("+element.key+").")}other.decorators=element.decorators}_coalesceGetterSetter(element,other)}}else{newElements.push(element)}}return newElements}function _hasDecorators(element){return element.decorators&&element.decorators.length}function _isDataDescriptor(desc){return desc!==void 0&&!(desc.value===void 0&&desc.writable===void 0)}function _optionalCallableProperty(obj,name){var value=obj[name];if(value!==void 0&&"function"!==typeof value){throw new TypeError("Expected '"+name+"' to be a function")}return value}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return"symbol"===typeof key?key:key+""}function _toPrimitive(input,hint){if("object"!==typeof input||null===input)return input;var prim=input[Symbol.toPrimitive];if(prim!==void 0){var res=prim.call(input,hint||"default");if("object"!==typeof res)return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===hint?String:Number)(input)}function _toArray(arr){return _arrayWithHoles(arr)||_iterableToArray(arr)||_nonIterableRest()}function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance")}function _iterableToArray(iter){if(Symbol.iterator in Object(iter)||"[object Arguments]"===Object.prototype.toString.call(iter))return Array.from(iter)}function _arrayWithHoles(arr){if(Array.isArray(arr))return arr}let HaCard=_decorate(null,function(_initialize,_LitElement){class HaCard extends _LitElement{constructor(...args){super(...args);_initialize(this)}}return{F:HaCard,d:[{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_0__.f)()],key:"header",value:void 0},{kind:"get",static:!0,key:"styles",value:function styles(){return lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      :host {
        background: var(
          --ha-card-background,
          var(--paper-card-background-color, white)
        );
        border-radius: var(--ha-card-border-radius, 2px);
        box-shadow: var(
          --ha-card-box-shadow,
          0 2px 2px 0 rgba(0, 0, 0, 0.14),
          0 1px 5px 0 rgba(0, 0, 0, 0.12),
          0 3px 1px -2px rgba(0, 0, 0, 0.2)
        );
        color: var(--primary-text-color);
        display: block;
        transition: all 0.3s ease-out;
      }
      .header:not(:empty) {
        font-size: 24px;
        letter-spacing: -0.012em;
        line-height: 32px;
        opacity: 0.87;
        padding: 24px 16px 16px;
      }
    `}},{kind:"method",key:"render",value:function render(){return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
      <div class="header">${this.header}</div>
      <slot></slot>
    `}}]}},lit_element__WEBPACK_IMPORTED_MODULE_0__.a);customElements.define("ha-card",HaCard)},182:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathabs=Math.abs,_Mathround=Math.round,fecha={},token=/d{1,4}|M{1,4}|YY(?:YY)?|S{1,3}|Do|ZZ|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g,twoDigits="\\d\\d?",threeDigits="\\d{3}",fourDigits="\\d{4}",word="[^\\s]+",literal=/\[([^]*?)\]/gm,noop=function(){};function regexEscape(str){return str.replace(/[|\\{()[^$+*?.-]/g,"\\$&")}function shorten(arr,sLen){for(var newArr=[],i=0,len=arr.length;i<len;i++){newArr.push(arr[i].substr(0,sLen))}return newArr}function monthUpdate(arrName){return function(d,v,i18n){var index=i18n[arrName].indexOf(v.charAt(0).toUpperCase()+v.substr(1).toLowerCase());if(~index){d.month=index}}}function pad(val,len){val=val+"";len=len||2;while(val.length<len){val="0"+val}return val}var dayNames=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],monthNames=["January","February","March","April","May","June","July","August","September","October","November","December"],monthNamesShort=shorten(monthNames,3),dayNamesShort=shorten(dayNames,3);fecha.i18n={dayNamesShort:dayNamesShort,dayNames:dayNames,monthNamesShort:monthNamesShort,monthNames:monthNames,amPm:["am","pm"],DoFn:function DoFn(D){return D+["th","st","nd","rd"][3<D%10?0:(10!==D-D%10)*D%10]}};var formatFlags={D:function(dateObj){return dateObj.getDate()},DD:function(dateObj){return pad(dateObj.getDate())},Do:function(dateObj,i18n){return i18n.DoFn(dateObj.getDate())},d:function(dateObj){return dateObj.getDay()},dd:function(dateObj){return pad(dateObj.getDay())},ddd:function(dateObj,i18n){return i18n.dayNamesShort[dateObj.getDay()]},dddd:function(dateObj,i18n){return i18n.dayNames[dateObj.getDay()]},M:function(dateObj){return dateObj.getMonth()+1},MM:function(dateObj){return pad(dateObj.getMonth()+1)},MMM:function(dateObj,i18n){return i18n.monthNamesShort[dateObj.getMonth()]},MMMM:function(dateObj,i18n){return i18n.monthNames[dateObj.getMonth()]},YY:function(dateObj){return pad(dateObj.getFullYear()+"",4).substr(2)},YYYY:function(dateObj){return pad(dateObj.getFullYear(),4)},h:function(dateObj){return dateObj.getHours()%12||12},hh:function(dateObj){return pad(dateObj.getHours()%12||12)},H:function(dateObj){return dateObj.getHours()},HH:function(dateObj){return pad(dateObj.getHours())},m:function(dateObj){return dateObj.getMinutes()},mm:function(dateObj){return pad(dateObj.getMinutes())},s:function(dateObj){return dateObj.getSeconds()},ss:function(dateObj){return pad(dateObj.getSeconds())},S:function(dateObj){return _Mathround(dateObj.getMilliseconds()/100)},SS:function(dateObj){return pad(_Mathround(dateObj.getMilliseconds()/10),2)},SSS:function(dateObj){return pad(dateObj.getMilliseconds(),3)},a:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0]:i18n.amPm[1]},A:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0].toUpperCase():i18n.amPm[1].toUpperCase()},ZZ:function(dateObj){var o=dateObj.getTimezoneOffset();return(0<o?"-":"+")+pad(100*Math.floor(_Mathabs(o)/60)+_Mathabs(o)%60,4)}},parseFlags={D:[twoDigits,function(d,v){d.day=v}],Do:[twoDigits+word,function(d,v){d.day=parseInt(v,10)}],M:[twoDigits,function(d,v){d.month=v-1}],YY:[twoDigits,function(d,v){var da=new Date,cent=+(""+da.getFullYear()).substr(0,2);d.year=""+(68<v?cent-1:cent)+v}],h:[twoDigits,function(d,v){d.hour=v}],m:[twoDigits,function(d,v){d.minute=v}],s:[twoDigits,function(d,v){d.second=v}],YYYY:[fourDigits,function(d,v){d.year=v}],S:["\\d",function(d,v){d.millisecond=100*v}],SS:["\\d{2}",function(d,v){d.millisecond=10*v}],SSS:[threeDigits,function(d,v){d.millisecond=v}],d:[twoDigits,noop],ddd:[word,noop],MMM:[word,monthUpdate("monthNamesShort")],MMMM:[word,monthUpdate("monthNames")],a:[word,function(d,v,i18n){var val=v.toLowerCase();if(val===i18n.amPm[0]){d.isPm=!1}else if(val===i18n.amPm[1]){d.isPm=!0}}],ZZ:["[^\\s]*?[\\+\\-]\\d\\d:?\\d\\d|[^\\s]*?Z",function(d,v){var parts=(v+"").match(/([+-]|\d\d)/gi),minutes;if(parts){minutes=+(60*parts[1])+parseInt(parts[2],10);d.timezoneOffset="+"===parts[0]?minutes:-minutes}}]};parseFlags.dd=parseFlags.d;parseFlags.dddd=parseFlags.ddd;parseFlags.DD=parseFlags.D;parseFlags.mm=parseFlags.m;parseFlags.hh=parseFlags.H=parseFlags.HH=parseFlags.h;parseFlags.MM=parseFlags.M;parseFlags.ss=parseFlags.s;parseFlags.A=parseFlags.a;fecha.masks={default:"ddd MMM DD YYYY HH:mm:ss",shortDate:"M/D/YY",mediumDate:"MMM D, YYYY",longDate:"MMMM D, YYYY",fullDate:"dddd, MMMM D, YYYY",shortTime:"HH:mm",mediumTime:"HH:mm:ss",longTime:"HH:mm:ss.SSS"};fecha.format=function(dateObj,mask,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("number"===typeof dateObj){dateObj=new Date(dateObj)}if("[object Date]"!==Object.prototype.toString.call(dateObj)||isNaN(dateObj.getTime())){throw new Error("Invalid Date in fecha.format")}mask=fecha.masks[mask]||mask||fecha.masks["default"];var literals=[];mask=mask.replace(literal,function($0,$1){literals.push($1);return"??"});mask=mask.replace(token,function($0){return $0 in formatFlags?formatFlags[$0](dateObj,i18n):$0.slice(1,$0.length-1)});return mask.replace(/\?\?/g,function(){return literals.shift()})};fecha.parse=function(dateStr,format,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("string"!==typeof format){throw new Error("Invalid format in fecha.parse")}format=fecha.masks[format]||format;if(1e3<dateStr.length){return null}var dateInfo={},parseInfo=[],newFormat=regexEscape(format).replace(token,function($0){if(parseFlags[$0]){var info=parseFlags[$0];parseInfo.push(info[1]);return"("+info[0]+")"}return $0}),matches=dateStr.match(new RegExp(newFormat,"i"));if(!matches){return null}for(var i=1;i<matches.length;i++){parseInfo[i-1](dateInfo,matches[i],i18n)}var today=new Date;if(!0===dateInfo.isPm&&null!=dateInfo.hour&&12!==+dateInfo.hour){dateInfo.hour=+dateInfo.hour+12}else if(!1===dateInfo.isPm&&12===+dateInfo.hour){dateInfo.hour=0}var date;if(null!=dateInfo.timezoneOffset){dateInfo.minute=+(dateInfo.minute||0)-+dateInfo.timezoneOffset;date=new Date(Date.UTC(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0))}else{date=new Date(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0)}return date};__webpack_exports__.a=fecha},189:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(182);function toLocaleStringSupportsOptions(){try{new Date().toLocaleString("i")}catch(e){return"RangeError"===e.name}return!1}__webpack_exports__.a=toLocaleStringSupportsOptions()?(dateObj,locales)=>dateObj.toLocaleString(locales,{year:"numeric",month:"long",day:"numeric",hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"haDateTime")},195:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(182);function toLocaleTimeStringSupportsOptions(){try{new Date().toLocaleTimeString("i")}catch(e){return"RangeError"===e.name}return!1}__webpack_exports__.a=toLocaleTimeStringSupportsOptions()?(dateObj,locales)=>dateObj.toLocaleTimeString(locales,{hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"shortTime")},197:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(40),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(60),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(41),_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(112),_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(61),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(33),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(3),_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(55);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`

    <style>
      :host {
        display: inline-block;
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-common-base;
      }

      :host([disabled]) {
        pointer-events: none;
      }

      :host(:focus) {
        outline:none;
      }

      .toggle-bar {
        position: absolute;
        height: 100%;
        width: 100%;
        border-radius: 8px;
        pointer-events: none;
        opacity: 0.4;
        transition: background-color linear .08s;
        background-color: var(--paper-toggle-button-unchecked-bar-color, #000000);

        @apply --paper-toggle-button-unchecked-bar;
      }

      .toggle-button {
        position: absolute;
        top: -3px;
        left: 0;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.6);
        transition: -webkit-transform linear .08s, background-color linear .08s;
        transition: transform linear .08s, background-color linear .08s;
        will-change: transform;
        background-color: var(--paper-toggle-button-unchecked-button-color, var(--paper-grey-50));

        @apply --paper-toggle-button-unchecked-button;
      }

      .toggle-button.dragging {
        -webkit-transition: none;
        transition: none;
      }

      :host([checked]:not([disabled])) .toggle-bar {
        opacity: 0.5;
        background-color: var(--paper-toggle-button-checked-bar-color, var(--primary-color));

        @apply --paper-toggle-button-checked-bar;
      }

      :host([disabled]) .toggle-bar {
        background-color: #000;
        opacity: 0.12;
      }

      :host([checked]) .toggle-button {
        -webkit-transform: translate(16px, 0);
        transform: translate(16px, 0);
      }

      :host([checked]:not([disabled])) .toggle-button {
        background-color: var(--paper-toggle-button-checked-button-color, var(--primary-color));

        @apply --paper-toggle-button-checked-button;
      }

      :host([disabled]) .toggle-button {
        background-color: #bdbdbd;
        opacity: 1;
      }

      .toggle-ink {
        position: absolute;
        top: -14px;
        left: -14px;
        right: auto;
        bottom: auto;
        width: 48px;
        height: 48px;
        opacity: 0.5;
        pointer-events: none;
        color: var(--paper-toggle-button-unchecked-ink-color, var(--primary-text-color));

        @apply --paper-toggle-button-unchecked-ink;
      }

      :host([checked]) .toggle-ink {
        color: var(--paper-toggle-button-checked-ink-color, var(--primary-color));

        @apply --paper-toggle-button-checked-ink;
      }

      .toggle-container {
        display: inline-block;
        position: relative;
        width: 36px;
        height: 14px;
        /* The toggle button has an absolute position of -3px; The extra 1px
        /* accounts for the toggle button shadow box. */
        margin: 4px 1px;
      }

      .toggle-label {
        position: relative;
        display: inline-block;
        vertical-align: middle;
        padding-left: var(--paper-toggle-button-label-spacing, 8px);
        pointer-events: none;
        color: var(--paper-toggle-button-label-color, var(--primary-text-color));
      }

      /* invalid state */
      :host([invalid]) .toggle-bar {
        background-color: var(--paper-toggle-button-invalid-bar-color, var(--error-color));
      }

      :host([invalid]) .toggle-button {
        background-color: var(--paper-toggle-button-invalid-button-color, var(--error-color));
      }

      :host([invalid]) .toggle-ink {
        color: var(--paper-toggle-button-invalid-ink-color, var(--error-color));
      }
    </style>

    <div class="toggle-container">
      <div id="toggleBar" class="toggle-bar"></div>
      <div id="toggleButton" class="toggle-button"></div>
    </div>

    <div class="toggle-label"><slot></slot></div>

  `;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__.a)({_template:template,is:"paper-toggle-button",behaviors:[_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],hostAttributes:{role:"button","aria-pressed":"false",tabindex:0},properties:{},listeners:{track:"_ontrack"},attached:function(){Object(_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__.a)(this,function(){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__.f)(this,"pan-y")})},_ontrack:function(event){var track=event.detail;if("start"===track.state){this._trackStart(track)}else if("track"===track.state){this._trackMove(track)}else if("end"===track.state){this._trackEnd(track)}},_trackStart:function(track){this._width=this.$.toggleBar.offsetWidth/2;this._trackChecked=this.checked;this.$.toggleButton.classList.add("dragging")},_trackMove:function(track){var dx=track.dx;this._x=Math.min(this._width,Math.max(0,this._trackChecked?this._width+dx:dx));this.translate3d(this._x+"px",0,0,this.$.toggleButton);this._userActivate(this._x>this._width/2)},_trackEnd:function(track){this.$.toggleButton.classList.remove("dragging");this.transform("",this.$.toggleButton)},_createRipple:function(){this._rippleContainer=this.$.toggleButton;var ripple=_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a._createRipple();ripple.id="ink";ripple.setAttribute("recenters","");ripple.classList.add("circle","toggle-ink");return ripple}})},198:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return isComponentLoaded});function isComponentLoaded(hass,component){return hass&&-1!==hass.config.components.indexOf(component)}},201:function(module,__webpack_exports__,__webpack_require__){"use strict";var _compute_state_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(162),_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(189),_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(220),_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(195);__webpack_exports__.a=(localize,stateObj,language)=>{let display;const domain=Object(_compute_state_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj);if("binary_sensor"===domain){if(stateObj.attributes.device_class){display=localize(`state.${domain}.${stateObj.attributes.device_class}.${stateObj.state}`)}if(!display){display=localize(`state.${domain}.default.${stateObj.state}`)}}else if(stateObj.attributes.unit_of_measurement&&!["unknown","unavailable"].includes(stateObj.state)){display=stateObj.state+" "+stateObj.attributes.unit_of_measurement}else if("input_datetime"===domain){let date;if(!stateObj.attributes.has_time){date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day);display=Object(_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__.a)(date,language)}else if(!stateObj.attributes.has_date){const now=new Date;date=new Date(now.getFullYear(),now.getMonth(),now.getDay(),stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__.a)(date,language)}else{date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day,stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__.a)(date,language)}}else if("zwave"===domain){if(["initializing","dead"].includes(stateObj.state)){display=localize(`state.zwave.query_stage.${stateObj.state}`,"query_stage",stateObj.attributes.query_stage)}else{display=localize(`state.zwave.default.${stateObj.state}`)}}else{display=localize(`state.${domain}.${stateObj.state}`)}if(!display){display=localize(`state.default.${stateObj.state}`)||localize(`component.${domain}.state.${stateObj.state}`)||stateObj.state}return display}},202:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_common_navigate__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(117);__webpack_exports__.a=Object(_polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__.a)(superClass=>class extends superClass{navigate(...args){Object(_common_navigate__WEBPACK_IMPORTED_MODULE_1__.a)(this,...args)}})},204:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return supportsFeature});const supportsFeature=(stateObj,feature)=>{return 0!==(stateObj.attributes.supported_features&feature)}},212:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return CoverEntity});__webpack_require__.d(__webpack_exports__,"b",function(){return isTiltOnly});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(204);class CoverEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isFullyOpen(){if(this._attr.current_position!==void 0){return 100===this._attr.current_position}return"open"===this.stateObj.state}get isFullyClosed(){if(this._attr.current_position!==void 0){return 0===this._attr.current_position}return"closed"===this.stateObj.state}get isFullyOpenTilt(){return 100===this._attr.current_tilt_position}get isFullyClosedTilt(){return 0===this._attr.current_tilt_position}get isOpening(){return"opening"===this.stateObj.state}get isClosing(){return"closing"===this.stateObj.state}get supportsOpen(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsClose(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2)}get supportsSetPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsStop(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsOpenTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsCloseTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsStopTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,64)}get supportsSetTiltPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get isTiltOnly(){const supportsCover=this.supportsOpen||this.supportsClose||this.supportsStop,supportsTilt=this.supportsOpenTilt||this.supportsCloseTilt||this.supportsStopTilt;return supportsTilt&&!supportsCover}openCover(){this.callService("open_cover")}closeCover(){this.callService("close_cover")}stopCover(){this.callService("stop_cover")}openCoverTilt(){this.callService("open_cover_tilt")}closeCoverTilt(){this.callService("close_cover_tilt")}stopCoverTilt(){this.callService("stop_cover_tilt")}setCoverPosition(position){this.callService("set_cover_position",{position})}setCoverTiltPosition(tiltPosition){this.callService("set_cover_tilt_position",{tilt_position:tiltPosition})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("cover",service,data)}}const supportsOpen=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,1),supportsClose=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,2),supportsSetPosition=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,4),supportsStop=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,8),supportsOpenTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,16),supportsCloseTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,32),supportsStopTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,64),supportsSetTiltPosition=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,128);function isTiltOnly(stateObj){const supportsCover=supportsOpen(stateObj)||supportsClose(stateObj)||supportsStop(stateObj),supportsTilt=supportsOpenTilt(stateObj)||supportsCloseTilt(stateObj)||supportsStopTilt(stateObj);return supportsTilt&&!supportsCover}},213:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_app_layout_app_header_layout_app_header_layout__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(135),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(20);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class HaAppLayout extends customElements.get("app-header-layout"){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        :host {
          display: block;
          /**
         * Force app-header-layout to have its own stacking context so that its parent can
         * control the stacking of it relative to other elements (e.g. app-drawer-layout).
         * This could be done using \`isolation: isolate\`, but that's not well supported
         * across browsers.
         */
          position: relative;
          z-index: 0;
        }

        #wrapper ::slotted([slot="header"]) {
          @apply --layout-fixed-top;
          z-index: 1;
        }

        #wrapper.initializing ::slotted([slot="header"]) {
          position: relative;
        }

        :host([has-scrolling-region]) {
          height: 100%;
        }

        :host([has-scrolling-region]) #wrapper ::slotted([slot="header"]) {
          position: absolute;
        }

        :host([has-scrolling-region])
          #wrapper.initializing
          ::slotted([slot="header"]) {
          position: relative;
        }

        :host([has-scrolling-region]) #wrapper #contentContainer {
          @apply --layout-fit;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;
        }

        :host([has-scrolling-region]) #wrapper.initializing #contentContainer {
          position: relative;
        }

        #contentContainer {
          /* Create a stacking context here so that all children appear below the header. */
          position: relative;
          z-index: 0;
          /* Using 'transform' will cause 'position: fixed' elements to behave like
           'position: absolute' relative to this element. */
          transform: translate(0);
        }

        @media print {
          :host([has-scrolling-region]) #wrapper #contentContainer {
            overflow-y: visible;
          }
        }
      </style>

      <div id="wrapper" class="initializing">
        <slot id="headerSlot" name="header"></slot>

        <div id="contentContainer"><slot></slot></div>
        <slot id="fab" name="fab"></slot>
      </div>
    `}}customElements.define("ha-app-layout",HaAppLayout)},215:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(96),_polymer_paper_toggle_button_paper_toggle_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(197),_common_const__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(109),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(162),lit_element__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(5);function _decorate(decorators,factory,superClass,mixins){var api=_getDecoratorsApi();if(mixins){for(var i=0;i<mixins.length;i++){api=mixins[i](api)}}var r=factory(function initialize(O){api.initializeInstanceElements(O,decorated.elements)},superClass),decorated=api.decorateClass(_coalesceClassElements(r.d.map(_createElementDescriptor)),decorators);api.initializeClassElements(r.F,decorated.elements);return api.runClassFinishers(r.F,decorated.finishers)}function _getDecoratorsApi(){_getDecoratorsApi=function(){return api};var api={elementsDefinitionOrder:[["method"],["field"]],initializeInstanceElements:function(O,elements){["method","field"].forEach(function(kind){elements.forEach(function(element){if(element.kind===kind&&"own"===element.placement){this.defineClassElement(O,element)}},this)},this)},initializeClassElements:function(F,elements){var proto=F.prototype;["method","field"].forEach(function(kind){elements.forEach(function(element){var placement=element.placement;if(element.kind===kind&&("static"===placement||"prototype"===placement)){var receiver="static"===placement?F:proto;this.defineClassElement(receiver,element)}},this)},this)},defineClassElement:function(receiver,element){var descriptor=element.descriptor;if("field"===element.kind){var initializer=element.initializer;descriptor={enumerable:descriptor.enumerable,writable:descriptor.writable,configurable:descriptor.configurable,value:void 0===initializer?void 0:initializer.call(receiver)}}Object.defineProperty(receiver,element.key,descriptor)},decorateClass:function(elements,decorators){var newElements=[],finishers=[],placements={static:[],prototype:[],own:[]};elements.forEach(function(element){this.addElementPlacement(element,placements)},this);elements.forEach(function(element){if(!_hasDecorators(element))return newElements.push(element);var elementFinishersExtras=this.decorateElement(element,placements);newElements.push(elementFinishersExtras.element);newElements.push.apply(newElements,elementFinishersExtras.extras);finishers.push.apply(finishers,elementFinishersExtras.finishers)},this);if(!decorators){return{elements:newElements,finishers:finishers}}var result=this.decorateConstructor(newElements,decorators);finishers.push.apply(finishers,result.finishers);result.finishers=finishers;return result},addElementPlacement:function(element,placements,silent){var keys=placements[element.placement];if(!silent&&-1!==keys.indexOf(element.key)){throw new TypeError("Duplicated element ("+element.key+")")}keys.push(element.key)},decorateElement:function(element,placements){for(var extras=[],finishers=[],decorators=element.decorators,i=decorators.length-1,keys;0<=i;i--){keys=placements[element.placement];keys.splice(keys.indexOf(element.key),1);var elementObject=this.fromElementDescriptor(element),elementFinisherExtras=this.toElementFinisherExtras((0,decorators[i])(elementObject)||elementObject);element=elementFinisherExtras.element;this.addElementPlacement(element,placements);if(elementFinisherExtras.finisher){finishers.push(elementFinisherExtras.finisher)}var newExtras=elementFinisherExtras.extras;if(newExtras){for(var j=0;j<newExtras.length;j++){this.addElementPlacement(newExtras[j],placements)}extras.push.apply(extras,newExtras)}}return{element:element,finishers:finishers,extras:extras}},decorateConstructor:function(elements,decorators){for(var finishers=[],i=decorators.length-1;0<=i;i--){var obj=this.fromClassDescriptor(elements),elementsAndFinisher=this.toClassDescriptor((0,decorators[i])(obj)||obj);if(elementsAndFinisher.finisher!==void 0){finishers.push(elementsAndFinisher.finisher)}if(elementsAndFinisher.elements!==void 0){elements=elementsAndFinisher.elements;for(var j=0;j<elements.length-1;j++){for(var k=j+1;k<elements.length;k++){if(elements[j].key===elements[k].key&&elements[j].placement===elements[k].placement){throw new TypeError("Duplicated element ("+elements[j].key+")")}}}}}return{elements:elements,finishers:finishers}},fromElementDescriptor:function(element){var obj={kind:element.kind,key:element.key,placement:element.placement,descriptor:element.descriptor},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);if("field"===element.kind)obj.initializer=element.initializer;return obj},toElementDescriptors:function(elementObjects){if(elementObjects===void 0)return;return _toArray(elementObjects).map(function(elementObject){var element=this.toElementDescriptor(elementObject);this.disallowProperty(elementObject,"finisher","An element descriptor");this.disallowProperty(elementObject,"extras","An element descriptor");return element},this)},toElementDescriptor:function(elementObject){var kind=elementObject.kind+"";if("method"!==kind&&"field"!==kind){throw new TypeError("An element descriptor's .kind property must be either \"method\" or"+" \"field\", but a decorator created an element descriptor with"+" .kind \""+kind+"\"")}var key=_toPropertyKey(elementObject.key),placement=elementObject.placement+"";if("static"!==placement&&"prototype"!==placement&&"own"!==placement){throw new TypeError("An element descriptor's .placement property must be one of \"static\","+" \"prototype\" or \"own\", but a decorator created an element descriptor"+" with .placement \""+placement+"\"")}var descriptor=elementObject.descriptor;this.disallowProperty(elementObject,"elements","An element descriptor");var element={kind:kind,key:key,placement:placement,descriptor:Object.assign({},descriptor)};if("field"!==kind){this.disallowProperty(elementObject,"initializer","A method descriptor")}else{this.disallowProperty(descriptor,"get","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"set","The property descriptor of a field descriptor");this.disallowProperty(descriptor,"value","The property descriptor of a field descriptor");element.initializer=elementObject.initializer}return element},toElementFinisherExtras:function(elementObject){var element=this.toElementDescriptor(elementObject),finisher=_optionalCallableProperty(elementObject,"finisher"),extras=this.toElementDescriptors(elementObject.extras);return{element:element,finisher:finisher,extras:extras}},fromClassDescriptor:function(elements){var obj={kind:"class",elements:elements.map(this.fromElementDescriptor,this)},desc={value:"Descriptor",configurable:!0};Object.defineProperty(obj,Symbol.toStringTag,desc);return obj},toClassDescriptor:function(obj){var kind=obj.kind+"";if("class"!==kind){throw new TypeError("A class descriptor's .kind property must be \"class\", but a decorator"+" created a class descriptor with .kind \""+kind+"\"")}this.disallowProperty(obj,"key","A class descriptor");this.disallowProperty(obj,"placement","A class descriptor");this.disallowProperty(obj,"descriptor","A class descriptor");this.disallowProperty(obj,"initializer","A class descriptor");this.disallowProperty(obj,"extras","A class descriptor");var finisher=_optionalCallableProperty(obj,"finisher"),elements=this.toElementDescriptors(obj.elements);return{elements:elements,finisher:finisher}},runClassFinishers:function(constructor,finishers){for(var i=0,newConstructor;i<finishers.length;i++){newConstructor=(0,finishers[i])(constructor);if(newConstructor!==void 0){if("function"!==typeof newConstructor){throw new TypeError("Finishers must return a constructor.")}constructor=newConstructor}}return constructor},disallowProperty:function(obj,name,objectType){if(obj[name]!==void 0){throw new TypeError(objectType+" can't have a ."+name+" property.")}}};return api}function _createElementDescriptor(def){var key=_toPropertyKey(def.key),descriptor;if("method"===def.kind){descriptor={value:def.value,writable:!0,configurable:!0,enumerable:!1}}else if("get"===def.kind){descriptor={get:def.value,configurable:!0,enumerable:!1}}else if("set"===def.kind){descriptor={set:def.value,configurable:!0,enumerable:!1}}else if("field"===def.kind){descriptor={configurable:!0,writable:!0,enumerable:!0}}var element={kind:"field"===def.kind?"field":"method",key:key,placement:def.static?"static":"field"===def.kind?"own":"prototype",descriptor:descriptor};if(def.decorators)element.decorators=def.decorators;if("field"===def.kind)element.initializer=def.value;return element}function _coalesceGetterSetter(element,other){if(element.descriptor.get!==void 0){other.descriptor.get=element.descriptor.get}else{other.descriptor.set=element.descriptor.set}}function _coalesceClassElements(elements){for(var newElements=[],isSameElement=function(other){return"method"===other.kind&&other.key===element.key&&other.placement===element.placement},i=0;i<elements.length;i++){var element=elements[i],other;if("method"===element.kind&&(other=newElements.find(isSameElement))){if(_isDataDescriptor(element.descriptor)||_isDataDescriptor(other.descriptor)){if(_hasDecorators(element)||_hasDecorators(other)){throw new ReferenceError("Duplicated methods ("+element.key+") can't be decorated.")}other.descriptor=element.descriptor}else{if(_hasDecorators(element)){if(_hasDecorators(other)){throw new ReferenceError("Decorators can't be placed on different accessors with for "+"the same property ("+element.key+").")}other.decorators=element.decorators}_coalesceGetterSetter(element,other)}}else{newElements.push(element)}}return newElements}function _hasDecorators(element){return element.decorators&&element.decorators.length}function _isDataDescriptor(desc){return desc!==void 0&&!(desc.value===void 0&&desc.writable===void 0)}function _optionalCallableProperty(obj,name){var value=obj[name];if(value!==void 0&&"function"!==typeof value){throw new TypeError("Expected '"+name+"' to be a function")}return value}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return"symbol"===typeof key?key:key+""}function _toPrimitive(input,hint){if("object"!==typeof input||null===input)return input;var prim=input[Symbol.toPrimitive];if(prim!==void 0){var res=prim.call(input,hint||"default");if("object"!==typeof res)return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===hint?String:Number)(input)}function _toArray(arr){return _arrayWithHoles(arr)||_iterableToArray(arr)||_nonIterableRest()}function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance")}function _iterableToArray(iter){if(Symbol.iterator in Object(iter)||"[object Arguments]"===Object.prototype.toString.call(iter))return Array.from(iter)}function _arrayWithHoles(arr){if(Array.isArray(arr))return arr}function _get(target,property,receiver){if("undefined"!==typeof Reflect&&Reflect.get){_get=Reflect.get}else{_get=function _get(target,property,receiver){var base=_superPropBase(target,property);if(!base)return;var desc=Object.getOwnPropertyDescriptor(base,property);if(desc.get){return desc.get.call(receiver)}return desc.value}}return _get(target,property,receiver||target)}function _superPropBase(object,property){while(!Object.prototype.hasOwnProperty.call(object,property)){object=_getPrototypeOf(object);if(null===object)break}return object}function _getPrototypeOf(o){_getPrototypeOf=Object.setPrototypeOf?Object.getPrototypeOf:function _getPrototypeOf(o){return o.__proto__||Object.getPrototypeOf(o)};return _getPrototypeOf(o)}const isOn=stateObj=>stateObj!==void 0&&!_common_const__WEBPACK_IMPORTED_MODULE_2__.i.includes(stateObj.state);let HaEntityToggle=_decorate(null,function(_initialize,_LitElement){class HaEntityToggle extends _LitElement{constructor(...args){super(...args);_initialize(this)}}return{F:HaEntityToggle,d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_4__.f)()],key:"stateObj",value:void 0},{kind:"field",decorators:[Object(lit_element__WEBPACK_IMPORTED_MODULE_4__.f)()],key:"_isOn",value(){return!1}},{kind:"method",key:"render",value:function render(){if(!this.stateObj){return lit_element__WEBPACK_IMPORTED_MODULE_4__.e`
        <paper-toggle-button disabled></paper-toggle-button>
      `}if(this.stateObj.attributes.assumed_state){return lit_element__WEBPACK_IMPORTED_MODULE_4__.e`
        <paper-icon-button
          icon="hass:flash-off"
          @click=${this._turnOff}
          ?state-active=${!this._isOn}
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:flash"
          @click=${this._turnOn}
          ?state-active=${this._isOn}
        ></paper-icon-button>
      `}return lit_element__WEBPACK_IMPORTED_MODULE_4__.e`
      <paper-toggle-button
        .checked=${this._isOn}
        @change=${this._toggleChanged}
      ></paper-toggle-button>
    `}},{kind:"method",key:"firstUpdated",value:function firstUpdated(changedProps){_get(_getPrototypeOf(HaEntityToggle.prototype),"firstUpdated",this).call(this,changedProps);this.addEventListener("click",ev=>ev.stopPropagation())}},{kind:"method",key:"updated",value:function updated(changedProps){if(changedProps.has("stateObj")){this._isOn=isOn(this.stateObj)}}},{kind:"method",key:"_toggleChanged",value:function _toggleChanged(ev){const newVal=ev.target.checked;if(newVal!==this._isOn){this._callService(newVal)}}},{kind:"method",key:"_turnOn",value:function _turnOn(){this._callService(!0)}},{kind:"method",key:"_turnOff",value:function _turnOff(){this._callService(!1)}},{kind:"method",key:"_callService",value:async function _callService(turnOn){if(!this.hass||!this.stateObj){return}const stateDomain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__.a)(this.stateObj);let serviceDomain,service;if("lock"===stateDomain){serviceDomain="lock";service=turnOn?"unlock":"lock"}else if("cover"===stateDomain){serviceDomain="cover";service=turnOn?"open_cover":"close_cover"}else if("group"===stateDomain){serviceDomain="homeassistant";service=turnOn?"turn_on":"turn_off"}else{serviceDomain=stateDomain;service=turnOn?"turn_on":"turn_off"}const currentState=this.stateObj;this._isOn=turnOn;await this.hass.callService(serviceDomain,service,{entity_id:this.stateObj.entity_id});setTimeout(async()=>{if(this.stateObj===currentState){this._isOn=isOn(this.stateObj)}},2e3)}},{kind:"get",static:!0,key:"styles",value:function styles(){return lit_element__WEBPACK_IMPORTED_MODULE_4__.c`
      :host {
        white-space: nowrap;
        min-width: 38px;
      }
      paper-icon-button {
        color: var(
          --paper-icon-button-inactive-color,
          var(--primary-text-color)
        );
        transition: color 0.5s;
      }
      paper-icon-button[state-active] {
        color: var(--paper-icon-button-active-color, var(--primary-color));
      }
      paper-toggle-button {
        cursor: pointer;
        --paper-toggle-button-label-spacing: 0;
        padding: 13px 5px;
        margin: -4px -5px;
      }
    `}}]}},lit_element__WEBPACK_IMPORTED_MODULE_4__.a);customElements.define("ha-entity-toggle",HaEntityToggle)},216:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"c",function(){return fetchRecent});__webpack_require__.d(__webpack_exports__,"b",function(){return fetchDate});__webpack_require__.d(__webpack_exports__,"a",function(){return computeHistory});var _common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(159),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(162),_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(201);const DOMAINS_USE_LAST_UPDATED=["climate","water_heater"],LINE_ATTRIBUTES_TO_KEEP=["temperature","current_temperature","target_temp_low","target_temp_high"],fetchRecent=(hass,entityId,startTime,endTime,skipInitialState=!1)=>{let url="history/period";if(startTime){url+="/"+startTime.toISOString()}url+="?filter_entity_id="+entityId;if(endTime){url+="&end_time="+endTime.toISOString()}if(skipInitialState){url+="&skip_initial_state"}return hass.callApi("GET",url)},fetchDate=(hass,startTime,endTime)=>{return hass.callApi("GET",`history/period/${startTime.toISOString()}?end_time=${endTime.toISOString()}`)},equalState=(obj1,obj2)=>obj1.state===obj2.state&&(!obj1.attributes||LINE_ATTRIBUTES_TO_KEEP.every(attr=>obj1.attributes[attr]===obj2.attributes[attr])),processTimelineEntity=(localize,language,states)=>{const data=[];for(const state of states){if(0<data.length&&state.state===data[data.length-1].state){continue}data.push({state_localize:Object(_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__.a)(localize,state,language),state:state.state,last_changed:state.last_changed})}return{name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(states[0]),entity_id:states[0].entity_id,data}},processLineChartEntities=(unit,entities)=>{const data=[];for(const states of entities){const last=states[states.length-1],domain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(last),processedStates=[];for(const state of states){let processedState;if(DOMAINS_USE_LAST_UPDATED.includes(domain)){processedState={state:state.state,last_changed:state.last_updated,attributes:{}};for(const attr of LINE_ATTRIBUTES_TO_KEEP){if(attr in state.attributes){processedState.attributes[attr]=state.attributes[attr]}}}else{processedState=state}if(1<processedStates.length&&equalState(processedState,processedStates[processedStates.length-1])&&equalState(processedState,processedStates[processedStates.length-2])){continue}processedStates.push(processedState)}data.push({domain,name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(last),entity_id:last.entity_id,states:processedStates})}return{unit,identifier:entities.map(states=>states[0].entity_id).join(""),data}},computeHistory=(hass,stateHistory,localize,language)=>{const lineChartDevices={},timelineDevices=[];if(!stateHistory){return{line:[],timeline:[]}}stateHistory.forEach(stateInfo=>{if(0===stateInfo.length){return}const stateWithUnit=stateInfo.find(state=>"unit_of_measurement"in state.attributes);let unit;if(stateWithUnit){unit=stateWithUnit.attributes.unit_of_measurement}else if("climate"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}else if("water_heater"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}if(!unit){timelineDevices.push(processTimelineEntity(localize,language,stateInfo))}else if(unit in lineChartDevices){lineChartDevices[unit].push(stateInfo)}else{lineChartDevices[unit]=[stateInfo]}});const unitStates=Object.keys(lineChartDevices).map(unit=>processLineChartEntities(unit,lineChartDevices[unit]));return{line:unitStates,timeline:timelineDevices}}},220:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(182);function toLocaleDateStringSupportsOptions(){try{new Date().toLocaleDateString("i")}catch(e){return"RangeError"===e.name}return!1}__webpack_exports__.a=toLocaleDateStringSupportsOptions()?(dateObj,locales)=>dateObj.toLocaleDateString(locales,{year:"numeric",month:"long",day:"numeric"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"mediumDate")},224:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(40),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(50),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(32),_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(61),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__.a`
    <style>
      :host {
        @apply --layout-inline;
        @apply --layout-center;
        @apply --layout-center-justified;
        @apply --layout-flex-auto;

        position: relative;
        padding: 0 12px;
        overflow: hidden;
        cursor: pointer;
        vertical-align: middle;

        @apply --paper-font-common-base;
        @apply --paper-tab;
      }

      :host(:focus) {
        outline: none;
      }

      :host([link]) {
        padding: 0;
      }

      .tab-content {
        height: 100%;
        transform: translateZ(0);
          -webkit-transform: translateZ(0);
        transition: opacity 0.1s cubic-bezier(0.4, 0.0, 1, 1);
        @apply --layout-horizontal;
        @apply --layout-center-center;
        @apply --layout-flex-auto;
        @apply --paper-tab-content;
      }

      :host(:not(.iron-selected)) > .tab-content {
        opacity: 0.8;

        @apply --paper-tab-content-unselected;
      }

      :host(:focus) .tab-content {
        opacity: 1;
        font-weight: 700;
      }

      paper-ripple {
        color: var(--paper-tab-ink, var(--paper-yellow-a100));
      }

      .tab-content > ::slotted(a) {
        @apply --layout-flex-auto;

        height: 100%;
      }
    </style>

    <div class="tab-content">
      <slot></slot>
    </div>
`,is:"paper-tab",behaviors:[_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_3__.a,_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__.a,_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],properties:{link:{type:Boolean,value:!1,reflectToAttribute:!0}},hostAttributes:{role:"tab"},listeners:{down:"_updateNoink",tap:"_onTap"},attached:function(){this._updateNoink()},get _parentNoink(){var parent=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_6__.b)(this).parentNode;return!!parent&&!!parent.noink},_updateNoink:function(){this.noink=!!this.noink||!!this._parentNoink},_onTap:function(event){if(this.link){var anchor=this.queryEffectiveChildren("a");if(!anchor){return}if(event.target===anchor){return}anchor.click()}}})},225:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(20),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(81);let loaded=null;const svgWhiteList=["svg","path"];class HaMarkdown extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__.a){static get properties(){return{content:{type:String,observer:"_render"},allowSvg:{type:Boolean,value:!1}}}connectedCallback(){super.connectedCallback();this._scriptLoaded=0;this._renderScheduled=!1;this._resize=()=>this.fire("iron-resize");if(!loaded){loaded=Promise.all([__webpack_require__.e(118),__webpack_require__.e(56)]).then(__webpack_require__.bind(null,279))}loaded.then(({marked,filterXSS})=>{this.marked=marked;this.filterXSS=filterXSS;this._scriptLoaded=1},()=>{this._scriptLoaded=2}).then(()=>this._render())}_render(){if(0===this._scriptLoaded||this._renderScheduled)return;this._renderScheduled=!0;Promise.resolve().then(()=>{this._renderScheduled=!1;if(1===this._scriptLoaded){this.innerHTML=this.filterXSS(this.marked(this.content,{gfm:!0,tables:!0,breaks:!0}),{onIgnoreTag:this.allowSvg?(tag,html)=>0<=svgWhiteList.indexOf(tag)?html:null:null});this._resize();const walker=document.createTreeWalker(this,1,null,!1);while(walker.nextNode()){const node=walker.currentNode;if("A"===node.tagName&&node.host!==document.location.host){node.target="_blank"}else if("IMG"===node.tagName){node.addEventListener("load",this._resize)}}}else if(2===this._scriptLoaded){this.innerText=this.content}})}}customElements.define("ha-markdown",HaMarkdown)},228:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"b",function(){return IronMenubarBehaviorImpl});__webpack_require__.d(__webpack_exports__,"a",function(){return IronMenubarBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2),_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(113);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronMenubarBehaviorImpl={hostAttributes:{role:"menubar"},keyBindings:{left:"_onLeftKey",right:"_onRightKey"},_onUpKey:function(event){this.focusedItem.click();event.detail.keyboardEvent.preventDefault()},_onDownKey:function(event){this.focusedItem.click();event.detail.keyboardEvent.preventDefault()},get _isRTL(){return"rtl"===window.getComputedStyle(this).direction},_onLeftKey:function(event){if(this._isRTL){this._focusNext()}else{this._focusPrevious()}event.detail.keyboardEvent.preventDefault()},_onRightKey:function(event){if(this._isRTL){this._focusPrevious()}else{this._focusNext()}event.detail.keyboardEvent.preventDefault()},_onKeydown:function(event){if(this.keyboardEventMatchesKeys(event,"up down left right esc")){return}this._focusWithKeyboardEvent(event)}},IronMenubarBehavior=[_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_1__.a,IronMenubarBehaviorImpl]},229:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(0),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(20),_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(247),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(107);class HaRelativeTime extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get properties(){return{hass:Object,datetime:{type:String,observer:"datetimeChanged"},datetimeObj:{type:Object,observer:"datetimeObjChanged"},parsedDateTime:Object}}constructor(){super();this.updateRelative=this.updateRelative.bind(this)}connectedCallback(){super.connectedCallback();this.updateInterval=setInterval(this.updateRelative,6e4)}disconnectedCallback(){super.disconnectedCallback();clearInterval(this.updateInterval)}datetimeChanged(newVal){this.parsedDateTime=newVal?new Date(newVal):null;this.updateRelative()}datetimeObjChanged(newVal){this.parsedDateTime=newVal;this.updateRelative()}updateRelative(){const root=Object(_polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__.b)(this);if(!this.parsedDateTime){root.innerHTML=this.localize("ui.components.relative_time.never")}else{root.innerHTML=Object(_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__.a)(this.parsedDateTime,this.localize)}}}customElements.define("ha-relative-time",HaRelativeTime)},232:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return secondsToDuration});const leftPad=num=>10>num?`0${num}`:num;function secondsToDuration(d){const h=_Mathfloor(d/3600),m=_Mathfloor(d%3600/60),s=_Mathfloor(d%3600%60);if(0<h){return`${h}:${leftPad(m)}:${leftPad(s)}`}if(0<m){return`${m}:${leftPad(s)}`}if(0<s){return""+s}return null}},233:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return MediaPlayerEntity});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(204);class MediaPlayerEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isOff(){return"off"===this.stateObj.state}get isIdle(){return"idle"===this.stateObj.state}get isMuted(){return this._attr.is_volume_muted}get isPaused(){return"paused"===this.stateObj.state}get isPlaying(){return"playing"===this.stateObj.state}get isMusic(){return"music"===this._attr.media_content_type}get isTVShow(){return"tvshow"===this._attr.media_content_type}get hasMediaControl(){return-1!==["playing","paused","unknown"].indexOf(this.stateObj.state)}get volumeSliderValue(){return 100*this._attr.volume_level}get showProgress(){return(this.isPlaying||this.isPaused)&&"media_duration"in this.stateObj.attributes&&"media_position"in this.stateObj.attributes&&"media_position_updated_at"in this.stateObj.attributes}get currentProgress(){var progress=this._attr.media_position;if(this.isPlaying){progress+=(Date.now()-new Date(this._attr.media_position_updated_at).getTime())/1e3}return progress}get supportsPause(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsVolumeSet(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsVolumeMute(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsPreviousTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsNextTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsTurnOn(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get supportsTurnOff(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,256)}get supportsPlayMedia(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,512)}get supportsVolumeButtons(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1024)}get supportsSelectSource(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2048)}get supportsSelectSoundMode(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,65536)}get supportsPlay(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16384)}get primaryTitle(){return this._attr.media_title}get secondaryTitle(){if(this.isMusic){return this._attr.media_artist}if(this.isTVShow){var text=this._attr.media_series_title;if(this._attr.media_season){text+=" S"+this._attr.media_season;if(this._attr.media_episode){text+="E"+this._attr.media_episode}}return text}if(this._attr.app_name){return this._attr.app_name}return""}get source(){return this._attr.source}get sourceList(){return this._attr.source_list}get soundMode(){return this._attr.sound_mode}get soundModeList(){return this._attr.sound_mode_list}mediaPlayPause(){this.callService("media_play_pause")}nextTrack(){this.callService("media_next_track")}playbackControl(){this.callService("media_play_pause")}previousTrack(){this.callService("media_previous_track")}setVolume(volume){this.callService("volume_set",{volume_level:volume})}togglePower(){if(this.isOff){this.turnOn()}else{this.turnOff()}}turnOff(){this.callService("turn_off")}turnOn(){this.callService("turn_on")}volumeDown(){this.callService("volume_down")}volumeMute(mute){if(!this.supportsVolumeMute){throw new Error("Muting volume not supported")}this.callService("volume_mute",{is_volume_muted:mute})}volumeUp(){this.callService("volume_up")}selectSource(source){this.callService("select_source",{source})}selectSoundMode(soundMode){this.callService("select_sound_mode",{sound_mode:soundMode})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("media_player",service,data)}}},234:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return attributeClassNames});function attributeClassNames(stateObj,attributes){if(!stateObj){return""}return attributes.map(attribute=>attribute in stateObj.attributes?"has-"+attribute:"").filter(attr=>""!==attr).join(" ")}},239:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathmax=Math.max,paper_spinner=__webpack_require__(173),html_tag=__webpack_require__(3),polymer_element=__webpack_require__(20),debounce=__webpack_require__(19),iron_resizable_behavior=__webpack_require__(85),paper_icon_button=__webpack_require__(96),utils_async=__webpack_require__(11),legacy_class=__webpack_require__(64),format_time=__webpack_require__(195);let scriptsLoaded=null;class ha_chart_base_HaChartBase extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }
        .chartHeader {
          padding: 6px 0 0 0;
          width: 100%;
          display: flex;
          flex-direction: row;
        }
        .chartHeader > div {
          vertical-align: top;
          padding: 0 8px;
        }
        .chartHeader > div.chartTitle {
          padding-top: 8px;
          flex: 0 0 0;
          max-width: 30%;
        }
        .chartHeader > div.chartLegend {
          flex: 1 1;
          min-width: 70%;
        }
        :root {
          user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -ms-user-select: none;
        }
        .chartTooltip {
          font-size: 90%;
          opacity: 1;
          position: absolute;
          background: rgba(80, 80, 80, 0.9);
          color: white;
          border-radius: 3px;
          pointer-events: none;
          transform: translate(-50%, 12px);
          z-index: 1000;
          width: 200px;
          transition: opacity 0.15s ease-in-out;
        }
        :host([rtl]) .chartTooltip {
          direction: rtl;
        }
        .chartLegend ul,
        .chartTooltip ul {
          display: inline-block;
          padding: 0 0px;
          margin: 5px 0 0 0;
          width: 100%;
        }
        .chartTooltip li {
          display: block;
          white-space: pre-line;
        }
        .chartTooltip .title {
          text-align: center;
          font-weight: 500;
        }
        .chartLegend li {
          display: inline-block;
          padding: 0 6px;
          max-width: 49%;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          box-sizing: border-box;
        }
        .chartLegend li:nth-child(odd):last-of-type {
          /* Make last item take full width if it is odd-numbered. */
          max-width: 100%;
        }
        .chartLegend li[data-hidden] {
          text-decoration: line-through;
        }
        .chartLegend em,
        .chartTooltip em {
          border-radius: 5px;
          display: inline-block;
          height: 10px;
          margin-right: 4px;
          width: 10px;
        }
        :host([rtl]) .chartTooltip em {
          margin-right: inherit;
          margin-left: 4px;
        }
        paper-icon-button {
          color: var(--secondary-text-color);
        }
      </style>
      <template is="dom-if" if="[[unit]]">
        <div class="chartHeader">
          <div class="chartTitle">[[unit]]</div>
          <div class="chartLegend">
            <ul>
              <template is="dom-repeat" items="[[metas]]">
                <li on-click="_legendClick" data-hidden$="[[item.hidden]]">
                  <em style$="background-color:[[item.bgColor]]"></em>
                  [[item.label]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </template>
      <div id="chartTarget" style="height:40px; width:100%">
        <canvas id="chartCanvas"></canvas>
        <div
          class$="chartTooltip [[tooltip.yAlign]]"
          style$="opacity:[[tooltip.opacity]]; top:[[tooltip.top]]; left:[[tooltip.left]]; padding:[[tooltip.yPadding]]px [[tooltip.xPadding]]px"
        >
          <div class="title">[[tooltip.title]]</div>
          <div>
            <ul>
              <template is="dom-repeat" items="[[tooltip.lines]]">
                <li>
                  <em style$="background-color:[[item.bgColor]]"></em
                  >[[item.text]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    `}get chart(){return this._chart}static get properties(){return{data:Object,identifier:String,rendered:{type:Boolean,notify:!0,value:!1,readOnly:!0},metas:{type:Array,value:()=>[]},tooltip:{type:Object,value:()=>({opacity:"0",left:"0",top:"0",xPadding:"5",yPadding:"3"})},unit:Object,rtl:{type:Boolean,reflectToAttribute:!0}}}static get observers(){return["onPropsChange(data)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.onPropsChange();this._resizeListener=()=>{this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(10),()=>{if(this._isAttached){this.resizeChart()}})};if("function"===typeof ResizeObserver){this.resizeObserver=new ResizeObserver(entries=>{entries.forEach(()=>{this._resizeListener()})});this.resizeObserver.observe(this.$.chartTarget)}else{this.addEventListener("iron-resize",this._resizeListener)}if(null===scriptsLoaded){scriptsLoaded=Promise.all([__webpack_require__.e(117),__webpack_require__.e(55)]).then(__webpack_require__.bind(null,755))}scriptsLoaded.then(ChartModule=>{this.ChartClass=ChartModule.default;this.onPropsChange()})}disconnectedCallback(){super.disconnectedCallback();this._isAttached=!1;if(this.resizeObserver){this.resizeObserver.unobserve(this.$.chartTarget)}this.removeEventListener("iron-resize",this._resizeListener);if(this._resizeTimer!==void 0){clearInterval(this._resizeTimer);this._resizeTimer=void 0}}onPropsChange(){if(!this._isAttached||!this.ChartClass||!this.data){return}this.drawChart()}_customTooltips(tooltip){if(0===tooltip.opacity){this.set(["tooltip","opacity"],0);return}if(tooltip.yAlign){this.set(["tooltip","yAlign"],tooltip.yAlign)}else{this.set(["tooltip","yAlign"],"no-transform")}const title=tooltip.title?tooltip.title[0]||"":"";this.set(["tooltip","title"],title);const bodyLines=tooltip.body.map(n=>n.lines);if(tooltip.body){this.set(["tooltip","lines"],bodyLines.map((body,i)=>{const colors=tooltip.labelColors[i];return{color:colors.borderColor,bgColor:colors.backgroundColor,text:body.join("\n")}}))}const parentWidth=this.$.chartTarget.clientWidth;let positionX=tooltip.caretX;const positionY=this._chart.canvas.offsetTop+tooltip.caretY;if(tooltip.caretX+100>parentWidth){positionX=parentWidth-100}else if(100>tooltip.caretX){positionX=100}positionX+=this._chart.canvas.offsetLeft;this.tooltip=Object.assign({},this.tooltip,{opacity:1,left:`${positionX}px`,top:`${positionY}px`})}_legendClick(event){event=event||window.event;event.stopPropagation();let target=event.target||event.srcElement;while("LI"!==target.nodeName){target=target.parentElement}const index=event.model.itemsIndex,meta=this._chart.getDatasetMeta(index);meta.hidden=null===meta.hidden?!this._chart.data.datasets[index].hidden:null;this.set(["metas",index,"hidden"],this._chart.isDatasetVisible(index)?null:"hidden");this._chart.update()}_drawLegend(){const chart=this._chart,preserveVisibility=this._oldIdentifier&&this.identifier===this._oldIdentifier;this._oldIdentifier=this.identifier;this.set("metas",this._chart.data.datasets.map((x,i)=>({label:x.label,color:x.color,bgColor:x.backgroundColor,hidden:preserveVisibility&&i<this.metas.length?this.metas[i].hidden:!chart.isDatasetVisible(i)})));let updateNeeded=!1;if(preserveVisibility){for(let i=0;i<this.metas.length;i++){const meta=chart.getDatasetMeta(i);if(!!meta.hidden!==!!this.metas[i].hidden)updateNeeded=!0;meta.hidden=this.metas[i].hidden?!0:null}}if(updateNeeded){chart.update()}this.unit=this.data.unit}_formatTickValue(value,index,values){if(0===values.length){return value}const date=new Date(values[index].value);return Object(format_time.a)(date)}drawChart(){const data=this.data.data,ctx=this.$.chartCanvas;if((!data.datasets||!data.datasets.length)&&!this._chart){return}if("timeline"!==this.data.type&&0<data.datasets.length){const cnt=data.datasets.length,colors=this.constructor.getColorList(cnt);for(let loopI=0;loopI<cnt;loopI++){data.datasets[loopI].borderColor=colors[loopI].rgbString();data.datasets[loopI].backgroundColor=colors[loopI].alpha(.6).rgbaString()}}if(this._chart){this._customTooltips({opacity:0});this._chart.data=data;this._chart.update({duration:0});if(this.isTimeline){this._chart.options.scales.yAxes[0].gridLines.display=1<data.length}else if(!0===this.data.legend){this._drawLegend()}this.resizeChart()}else{if(!data.datasets){return}this._customTooltips({opacity:0});const plugins=[{afterRender:()=>this._setRendered(!0)}];let options={responsive:!0,maintainAspectRatio:!1,animation:{duration:0},hover:{animationDuration:0},responsiveAnimationDuration:0,tooltips:{enabled:!1,custom:this._customTooltips.bind(this)},legend:{display:!1},line:{spanGaps:!0},elements:{font:"12px 'Roboto', 'sans-serif'"},ticks:{fontFamily:"'Roboto', 'sans-serif'"}};options=Chart.helpers.merge(options,this.data.options);options.scales.xAxes[0].ticks.callback=this._formatTickValue;if("timeline"===this.data.type){this.set("isTimeline",!0);if(this.data.colors!==void 0){this._colorFunc=this.constructor.getColorGenerator(this.data.colors.staticColors,this.data.colors.staticColorIndex)}if(this._colorFunc!==void 0){options.elements.colorFunction=this._colorFunc}if(1===data.datasets.length){if(options.scales.yAxes[0].ticks){options.scales.yAxes[0].ticks.display=!1}else{options.scales.yAxes[0].ticks={display:!1}}if(options.scales.yAxes[0].gridLines){options.scales.yAxes[0].gridLines.display=!1}else{options.scales.yAxes[0].gridLines={display:!1}}}this.$.chartTarget.style.height="50px"}else{this.$.chartTarget.style.height="160px"}const chartData={type:this.data.type,data:this.data.data,options:options,plugins:plugins};this._chart=new this.ChartClass(ctx,chartData);if(!0!==this.isTimeline&&!0===this.data.legend){this._drawLegend()}this.resizeChart()}}resizeChart(){if(!this._chart)return;if(this._resizeTimer===void 0){this._resizeTimer=setInterval(this.resizeChart.bind(this),10);return}clearInterval(this._resizeTimer);this._resizeTimer=void 0;this._resizeChart()}_resizeChart(){const chartTarget=this.$.chartTarget,options=this.data,data=options.data;if(0===data.datasets.length){return}if(!this.isTimeline){this._chart.resize();return}const areaTop=this._chart.chartArea.top,areaBot=this._chart.chartArea.bottom,height1=this._chart.canvas.clientHeight;if(0<areaBot){this._axisHeight=height1-areaBot+areaTop}if(!this._axisHeight){chartTarget.style.height="50px";this._chart.resize();this.resizeChart();return}if(this._axisHeight){const cnt=data.datasets.length,targetHeight=30*cnt+this._axisHeight+"px";if(chartTarget.style.height!==targetHeight){chartTarget.style.height=targetHeight}this._chart.resize()}}static getColorList(count){let processL=!1;if(10<count){processL=!0;count=Math.ceil(count/2)}const h1=360/count,result=[];for(let loopI=0;loopI<count;loopI++){result[loopI]=Color().hsl(h1*loopI,80,38);if(processL){result[loopI+count]=Color().hsl(h1*loopI,80,62)}}return result}static getColorGenerator(staticColors,startIndex){const palette=["ff0029","66a61e","377eb8","984ea3","00d2d5","ff7f00","af8d00","7f80cd","b3e900","c42e60","a65628","f781bf","8dd3c7","bebada","fb8072","80b1d3","fdb462","fccde5","bc80bd","ffed6f","c4eaff","cf8c00","1b9e77","d95f02","e7298a","e6ab02","a6761d","0097ff","00d067","f43600","4ba93b","5779bb","927acc","97ee3f","bf3947","9f5b00","f48758","8caed6","f2b94f","eff26e","e43872","d9b100","9d7a00","698cff","d9d9d9","00d27e","d06800","009f82","c49200","cbe8ff","fecddf","c27eb6","8cd2ce","c4b8d9","f883b0","a49100","f48800","27d0df","a04a9b"];function getColorIndex(idx){return Color("#"+palette[idx%palette.length])}const colorDict={};let colorIndex=0;if(0<startIndex)colorIndex=startIndex;if(staticColors){Object.keys(staticColors).forEach(c=>{const c1=staticColors[c];if(isFinite(c1)){colorDict[c.toLowerCase()]=getColorIndex(c1)}else{colorDict[c.toLowerCase()]=Color(staticColors[c])}})}function getColor(__,data){let ret;const name=data[3];if(null===name)return Color().hsl(0,40,38);if(name===void 0)return Color().hsl(120,40,38);const name1=name.toLowerCase();if(ret===void 0){ret=colorDict[name1]}if(ret===void 0){ret=getColorIndex(colorIndex);colorIndex++;colorDict[name1]=ret}return ret}return getColor}}customElements.define("ha-chart-base",ha_chart_base_HaChartBase);var localize_mixin=__webpack_require__(107),format_date_time=__webpack_require__(189);class state_history_chart_line_StateHistoryChartLine extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          overflow: hidden;
          height: 0;
          transition: height 0.3s ease-in-out;
        }
      </style>
      <ha-chart-base
        id="chart"
        data="[[chartData]]"
        identifier="[[identifier]]"
        rendered="{{rendered}}"
      ></ha-chart-base>
    `}static get properties(){return{chartData:Object,data:Object,names:Object,unit:String,identifier:String,isSingleDevice:{type:Boolean,value:!1},endTime:Object,rendered:{type:Boolean,value:!1,observer:"_onRenderedChanged"}}}static get observers(){return["dataChanged(data, endTime, isSingleDevice)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}_onRenderedChanged(rendered){if(rendered)this.animateHeight()}animateHeight(){requestAnimationFrame(()=>requestAnimationFrame(()=>{this.style.height=this.$.chart.scrollHeight+"px"}))}drawChart(){const unit=this.unit,deviceStates=this.data,datasets=[];let endTime;if(!this._isAttached){return}if(0===deviceStates.length){return}function safeParseFloat(value){const parsed=parseFloat(value);return isFinite(parsed)?parsed:null}endTime=this.endTime||new Date(_Mathmax.apply(null,deviceStates.map(devSts=>new Date(devSts.states[devSts.states.length-1].last_changed))));if(endTime>new Date){endTime=new Date}const names=this.names||{};deviceStates.forEach(states=>{const domain=states.domain,name=names[states.entity_id]||states.name;let prevValues;const data=[];function pushData(timestamp,datavalues){if(!datavalues)return;if(timestamp>endTime){return}data.forEach((d,i)=>{d.data.push({x:timestamp,y:datavalues[i]})});prevValues=datavalues}function addColumn(nameY,step,fill){let dataFill=!1,dataStep=!1;if(fill){dataFill="origin"}if(step){dataStep="before"}data.push({label:nameY,fill:dataFill,steppedLine:dataStep,pointRadius:0,data:[],unitText:unit})}if("thermostat"===domain||"climate"===domain||"water_heater"===domain){const hasTargetRange=states.states.some(state=>state.attributes&&state.attributes.target_temp_high!==state.attributes.target_temp_low),hasHeat=states.states.some(state=>"heat"===state.state),hasCool=states.states.some(state=>"cool"===state.state);addColumn(name+" current temperature",!0);if(hasHeat){addColumn(name+" heating",!0,!0)}if(hasCool){addColumn(name+" cooling",!0,!0)}if(hasTargetRange){addColumn(name+" target temperature high",!0);addColumn(name+" target temperature low",!0)}else{addColumn(name+" target temperature",!0)}states.states.forEach(state=>{if(!state.attributes)return;const curTemp=safeParseFloat(state.attributes.current_temperature),series=[curTemp];if(hasHeat){series.push("heat"===state.state?curTemp:null)}if(hasCool){series.push("cool"===state.state?curTemp:null)}if(hasTargetRange){const targetHigh=safeParseFloat(state.attributes.target_temp_high),targetLow=safeParseFloat(state.attributes.target_temp_low);series.push(targetHigh,targetLow);pushData(new Date(state.last_changed),series)}else{const target=safeParseFloat(state.attributes.temperature);series.push(target);pushData(new Date(state.last_changed),series)}})}else{const isStep="sensor"===domain;addColumn(name,isStep);let lastValue=null,lastDate=null,lastNullDate=null;states.states.forEach(state=>{const value=safeParseFloat(state.state),date=new Date(state.last_changed);if(null!==value&&null!==lastNullDate){const dateTime=date.getTime(),lastNullDateTime=lastNullDate.getTime(),lastDateTime=lastDate.getTime(),tmpValue=(value-lastValue)*((lastNullDateTime-lastDateTime)/(dateTime-lastDateTime))+lastValue;pushData(lastNullDate,[tmpValue]);pushData(new Date(lastNullDateTime+1),[null]);pushData(date,[value]);lastDate=date;lastValue=value;lastNullDate=null}else if(null!==value&&null===lastNullDate){pushData(date,[value]);lastDate=date;lastValue=value}else if(null===value&&null===lastNullDate&&null!==lastValue){lastNullDate=date}})}pushData(endTime,prevValues,!1);Array.prototype.push.apply(datasets,data)});const formatTooltipTitle=(items,data)=>{const item=items[0],date=data.datasets[item.datasetIndex].data[item.index].x;return Object(format_date_time.a)(date,this.hass.language)},chartOptions={type:"line",unit:unit,legend:!this.isSingleDevice,options:{scales:{xAxes:[{type:"time",ticks:{major:{fontStyle:"bold"}}}],yAxes:[{ticks:{maxTicksLimit:7}}]},tooltips:{mode:"neareach",callbacks:{title:formatTooltipTitle}},hover:{mode:"neareach"},layout:{padding:{top:5}},elements:{line:{tension:.1,pointRadius:0,borderWidth:1.5},point:{hitRadius:5}},plugins:{filler:{propagate:!0}}},data:{labels:[],datasets:datasets}};this.chartData=chartOptions}}customElements.define("state-history-chart-line",state_history_chart_line_StateHistoryChartLine);var compute_rtl=__webpack_require__(83);class state_history_chart_timeline_StateHistoryChartTimeline extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          opacity: 0;
          transition: opacity 0.3s ease-in-out;
        }
        :host([rendered]) {
          opacity: 1;
        }

        ha-chart-base {
          direction: ltr;
        }
      </style>
      <ha-chart-base
        data="[[chartData]]"
        rendered="{{rendered}}"
        rtl="{{rtl}}"
      ></ha-chart-base>
    `}static get properties(){return{hass:{type:Object},chartData:Object,data:{type:Object,observer:"dataChanged"},names:Object,noSingle:Boolean,endTime:Date,rendered:{type:Boolean,value:!1,reflectToAttribute:!0},rtl:{reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}static get observers(){return["dataChanged(data, endTime, localize, language)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}drawChart(){const staticColors={on:1,off:0,unavailable:"#a0a0a0",unknown:"#606060",idle:2};let stateHistory=this.data;if(!this._isAttached){return}if(!stateHistory){stateHistory=[]}const startTime=new Date(stateHistory.reduce((minTime,stateInfo)=>Math.min(minTime,new Date(stateInfo.data[0].last_changed)),new Date));let endTime=this.endTime||new Date(stateHistory.reduce((maxTime,stateInfo)=>_Mathmax(maxTime,new Date(stateInfo.data[stateInfo.data.length-1].last_changed)),startTime));if(endTime>new Date){endTime=new Date}const labels=[],datasets=[],names=this.names||{};stateHistory.forEach(stateInfo=>{let newLastChanged,prevState=null,locState=null,prevLastChanged=startTime;const entityDisplay=names[stateInfo.entity_id]||stateInfo.name,dataRow=[];stateInfo.data.forEach(state=>{let newState=state.state;const timeStamp=new Date(state.last_changed);if(newState===void 0||""===newState){newState=null}if(timeStamp>endTime){return}if(null!==prevState&&newState!==prevState){newLastChanged=new Date(state.last_changed);dataRow.push([prevLastChanged,newLastChanged,locState,prevState]);prevState=newState;locState=state.state_localize;prevLastChanged=newLastChanged}else if(null===prevState){prevState=newState;locState=state.state_localize;prevLastChanged=new Date(state.last_changed)}});if(null!==prevState){dataRow.push([prevLastChanged,endTime,locState,prevState])}datasets.push({data:dataRow});labels.push(entityDisplay)});const formatTooltipLabel=(item,data)=>{const values=data.datasets[item.datasetIndex].data[item.index],start=Object(format_date_time.a)(values[0],this.hass.language),end=Object(format_date_time.a)(values[1],this.hass.language),state=values[2];return[state,start,end]},chartOptions={type:"timeline",options:{tooltips:{callbacks:{label:formatTooltipLabel}},scales:{xAxes:[{ticks:{major:{fontStyle:"bold"}}}],yAxes:[{afterSetDimensions:yaxe=>{yaxe.maxWidth=.18*yaxe.chart.width},position:this._computeRTL?"right":"left"}]}},data:{labels:labels,datasets:datasets},colors:{staticColors:staticColors,staticColorIndex:3}};this.chartData=chartOptions}_computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("state-history-chart-timeline",state_history_chart_timeline_StateHistoryChartTimeline);class state_history_charts_StateHistoryCharts extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          /* height of single timeline chart = 58px */
          min-height: 58px;
        }
        .info {
          text-align: center;
          line-height: 58px;
          color: var(--secondary-text-color);
        }
      </style>
      <template
        is="dom-if"
        class="info"
        if="[[_computeIsLoading(isLoadingData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.loading_history')]]
        </div>
      </template>

      <template
        is="dom-if"
        class="info"
        if="[[_computeIsEmpty(isLoadingData, historyData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.no_history_found')]]
        </div>
      </template>

      <template is="dom-if" if="[[historyData.timeline.length]]">
        <state-history-chart-timeline
          hass="[[hass]]"
          data="[[historyData.timeline]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          no-single="[[noSingle]]"
          names="[[names]]"
        ></state-history-chart-timeline>
      </template>

      <template is="dom-repeat" items="[[historyData.line]]">
        <state-history-chart-line
          hass="[[hass]]"
          unit="[[item.unit]]"
          data="[[item.data]]"
          identifier="[[item.identifier]]"
          is-single-device="[[_computeIsSingleLineChart(item.data, noSingle)]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          names="[[names]]"
        ></state-history-chart-line>
      </template>
    `}static get properties(){return{hass:Object,historyData:{type:Object,value:null},names:Object,isLoadingData:Boolean,endTime:{type:Object},upToNow:Boolean,noSingle:Boolean}}_computeIsSingleLineChart(data,noSingle){return!noSingle&&data&&1===data.length}_computeIsEmpty(isLoadingData,historyData){const historyDataEmpty=!historyData||!historyData.timeline||!historyData.line||0===historyData.timeline.length&&0===historyData.line.length;return!isLoadingData&&historyDataEmpty}_computeIsLoading(isLoading){return isLoading&&!this.historyData}_computeEndTime(endTime,upToNow){return upToNow?new Date:endTime}}customElements.define("state-history-charts",state_history_charts_StateHistoryCharts)},240:function(module,__webpack_exports__,__webpack_require__){"use strict";function durationToSeconds(duration){const parts=duration.split(":").map(Number);return 3600*parts[0]+60*parts[1]+parts[2]}__webpack_require__.d(__webpack_exports__,"a",function(){return timerTimeRemaining});function timerTimeRemaining(stateObj){let timeRemaining=durationToSeconds(stateObj.attributes.remaining);if("active"===stateObj.state){const now=new Date().getTime(),madeActive=new Date(stateObj.last_changed).getTime();timeRemaining=Math.max(timeRemaining-(now-madeActive)/1e3,0)}return timeRemaining}},241:function(module,__webpack_exports__,__webpack_require__){"use strict";var utils_async=__webpack_require__(11),debounce=__webpack_require__(19),polymer_element=__webpack_require__(20),localize_mixin=__webpack_require__(107),data_history=__webpack_require__(216);const RECENT_THRESHOLD=6e4,RECENT_CACHE={},stateHistoryCache={},getRecent=(hass,entityId,startTime,endTime,localize,language)=>{const cacheKey=entityId,cache=RECENT_CACHE[cacheKey];if(cache&&Date.now()-cache.created<RECENT_THRESHOLD&&cache.language===language){return cache.data}const prom=Object(data_history.c)(hass,entityId,startTime,endTime).then(stateHistory=>Object(data_history.a)(hass,stateHistory,localize,language),err=>{delete RECENT_CACHE[entityId];throw err});RECENT_CACHE[cacheKey]={created:Date.now(),language,data:prom};return prom};function getEmptyCache(language,startTime,endTime){return{prom:Promise.resolve({line:[],timeline:[]}),language,startTime,endTime,data:{line:[],timeline:[]}}}const getRecentWithCache=(hass,entityId,cacheConfig,localize,language)=>{const cacheKey=cacheConfig.cacheKey,endTime=new Date,startTime=new Date(endTime);startTime.setHours(startTime.getHours()-cacheConfig.hoursToShow);let toFetchStartTime=startTime,appendingToCache=!1,cache=stateHistoryCache[cacheKey];if(cache&&toFetchStartTime>=cache.startTime&&toFetchStartTime<=cache.endTime&&cache.language===language){toFetchStartTime=cache.endTime;appendingToCache=!0;if(endTime<=cache.endTime){return cache.prom}}else{cache=stateHistoryCache[cacheKey]=getEmptyCache(language,startTime,endTime)}const curCacheProm=cache.prom,genProm=async()=>{let fetchedHistory;try{const results=await Promise.all([curCacheProm,Object(data_history.c)(hass,entityId,toFetchStartTime,endTime,appendingToCache)]);fetchedHistory=results[1]}catch(err){delete stateHistoryCache[cacheKey];throw err}const stateHistory=Object(data_history.a)(hass,fetchedHistory,localize,language);if(appendingToCache){mergeLine(stateHistory.line,cache.data.line);mergeTimeline(stateHistory.timeline,cache.data.timeline);pruneStartTime(startTime,cache.data)}else{cache.data=stateHistory}return cache.data};cache.prom=genProm();cache.startTime=startTime;cache.endTime=endTime;return cache.prom},mergeLine=(historyLines,cacheLines)=>{historyLines.forEach(line=>{const unit=line.unit,oldLine=cacheLines.find(cacheLine=>cacheLine.unit===unit);if(oldLine){line.data.forEach(entity=>{const oldEntity=oldLine.data.find(cacheEntity=>entity.entity_id===cacheEntity.entity_id);if(oldEntity){oldEntity.states=oldEntity.states.concat(entity.states)}else{oldLine.data.push(entity)}})}else{cacheLines.push(line)}})},mergeTimeline=(historyTimelines,cacheTimelines)=>{historyTimelines.forEach(timeline=>{const oldTimeline=cacheTimelines.find(cacheTimeline=>cacheTimeline.entity_id===timeline.entity_id);if(oldTimeline){oldTimeline.data=oldTimeline.data.concat(timeline.data)}else{cacheTimelines.push(timeline)}})},pruneArray=(originalStartTime,arr)=>{if(0===arr.length){return arr}const changedAfterStartTime=arr.findIndex(state=>new Date(state.last_changed)>originalStartTime);if(0===changedAfterStartTime){return arr}const updateIndex=-1===changedAfterStartTime?arr.length-1:changedAfterStartTime-1;arr[updateIndex].last_changed=originalStartTime;return arr.slice(updateIndex)},pruneStartTime=(originalStartTime,cacheData)=>{cacheData.line.forEach(line=>{line.data.forEach(entity=>{entity.states=pruneArray(originalStartTime,entity.states)})});cacheData.timeline.forEach(timeline=>{timeline.data=pruneArray(originalStartTime,timeline.data)})};class ha_state_history_data_HaStateHistoryData extends Object(localize_mixin.a)(polymer_element.a){static get properties(){return{hass:{type:Object,observer:"hassChanged"},filterType:String,cacheConfig:Object,startTime:Date,endTime:Date,entityId:String,isLoading:{type:Boolean,value:!0,readOnly:!0,notify:!0},data:{type:Object,value:null,readOnly:!0,notify:!0}}}static get observers(){return["filterChangedDebouncer(filterType, entityId, startTime, endTime, cacheConfig, localize)"]}connectedCallback(){super.connectedCallback();this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}disconnectedCallback(){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}super.disconnectedCallback()}hassChanged(newHass,oldHass){if(!oldHass&&!this._madeFirstCall){this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}}filterChangedDebouncer(...args){this._debounceFilterChanged=debounce.a.debounce(this._debounceFilterChanged,utils_async.d.after(0),()=>{this.filterChanged(...args)})}filterChanged(filterType,entityId,startTime,endTime,cacheConfig,localize){if(!this.hass){return}if(cacheConfig&&!cacheConfig.cacheKey){return}if(!localize){return}this._madeFirstCall=!0;const language=this.hass.language;let data;if("date"===filterType){if(!startTime||!endTime)return;data=Object(data_history.b)(this.hass,startTime,endTime).then(dateHistory=>Object(data_history.a)(this.hass,dateHistory,localize,language))}else if("recent-entity"===filterType){if(!entityId)return;if(cacheConfig){data=this.getRecentWithCacheRefresh(entityId,cacheConfig,localize,language)}else{data=getRecent(this.hass,entityId,startTime,endTime,localize,language)}}else{return}this._setIsLoading(!0);data.then(stateHistory=>{this._setData(stateHistory);this._setIsLoading(!1)})}getRecentWithCacheRefresh(entityId,cacheConfig,localize,language){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}if(cacheConfig.refresh){this._refreshTimeoutId=window.setInterval(()=>{getRecentWithCache(this.hass,entityId,cacheConfig,localize,language).then(stateHistory=>{this._setData(Object.assign({},stateHistory))})},1e3*cacheConfig.refresh)}return getRecentWithCache(this.hass,entityId,cacheConfig,localize,language)}}customElements.define("ha-state-history-data",ha_state_history_data_HaStateHistoryData)},242:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return dynamicContentUpdater});function dynamicContentUpdater(root,newElementTag,attributes){const rootEl=root;let customEl;if(rootEl.lastChild&&rootEl.lastChild.tagName===newElementTag){customEl=rootEl.lastChild}else{if(rootEl.lastChild){rootEl.removeChild(rootEl.lastChild)}customEl=document.createElement(newElementTag.toLowerCase())}if(customEl.setProperties){customEl.setProperties(attributes)}else{Object.keys(attributes).forEach(key=>{customEl[key]=attributes[key]})}if(null===customEl.parentNode){rootEl.appendChild(customEl)}}},247:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor2=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return relativeTime});const tests=[60,60,24,7],langKey=["second","minute","hour","day"];function relativeTime(dateObj,localize,options={}){const compareTime=options.compareTime||new Date;let delta=(compareTime.getTime()-dateObj.getTime())/1e3;const tense=0<=delta?"past":"future";delta=Math.abs(delta);let timeDesc;for(let i=0;i<tests.length;i++){if(delta<tests[i]){delta=_Mathfloor2(delta);timeDesc=localize(`ui.components.relative_time.duration.${langKey[i]}`,"count",delta);break}delta/=tests[i]}if(timeDesc===void 0){delta=_Mathfloor2(delta);timeDesc=localize("ui.components.relative_time.duration.week","count",delta)}return!1===options.includeTense?timeDesc:localize(`ui.components.relative_time.${tense}`,"time",timeDesc)}},248:function(module,__webpack_exports__,__webpack_require__){"use strict";var lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5),lit_html_directives_class_map__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(63),_ha_icon__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(164);class HaLabelBadge extends lit_element__WEBPACK_IMPORTED_MODULE_0__.a{constructor(...args){super(...args);this.value=void 0;this.icon=void 0;this.label=void 0;this.description=void 0;this.image=void 0}static get properties(){return{value:{},icon:{},label:{},description:{},image:{}}}render(){return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
      <div class="badge-container">
        <div class="label-badge" id="badge">
          <div
            class="${Object(lit_html_directives_class_map__WEBPACK_IMPORTED_MODULE_1__.a)({value:!0,big:!!(this.value&&4<this.value.length)})}"
          >
            ${this.icon&&!this.value&&!this.image?lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
                  <ha-icon .icon="${this.icon}"></ha-icon>
                `:""}
            ${this.value&&!this.image?lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
                  <span>${this.value}</span>
                `:""}
          </div>
          ${this.label?lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
                <div
                  class="${Object(lit_html_directives_class_map__WEBPACK_IMPORTED_MODULE_1__.a)({label:!0,big:5<this.label.length})}"
                >
                  <span>${this.label}</span>
                </div>
              `:""}
        </div>
        ${this.description?lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
              <div class="title">${this.description}</div>
            `:""}
      </div>
    `}static get styles(){return[lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
        .badge-container {
          display: inline-block;
          text-align: center;
          vertical-align: top;
        }
        .label-badge {
          position: relative;
          display: block;
          margin: 0 auto;
          width: var(--ha-label-badge-size, 2.5em);
          text-align: center;
          height: var(--ha-label-badge-size, 2.5em);
          line-height: var(--ha-label-badge-size, 2.5em);
          font-size: var(--ha-label-badge-font-size, 1.5em);
          border-radius: 50%;
          border: 0.1em solid var(--ha-label-badge-color, var(--primary-color));
          color: var(--label-badge-text-color, rgb(76, 76, 76));

          white-space: nowrap;
          background-color: var(--label-badge-background-color, white);
          background-size: cover;
          transition: border 0.3s ease-in-out;
        }
        .label-badge .value {
          font-size: 90%;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .label-badge .value.big {
          font-size: 70%;
        }
        .label-badge .label {
          position: absolute;
          bottom: -1em;
          /* Make the label as wide as container+border. (parent_borderwidth / font-size) */
          left: -0.2em;
          right: -0.2em;
          line-height: 1em;
          font-size: 0.5em;
        }
        .label-badge .label span {
          box-sizing: border-box;
          max-width: 100%;
          display: inline-block;
          background-color: var(--ha-label-badge-color, var(--primary-color));
          color: var(--ha-label-badge-label-color, white);
          border-radius: 1em;
          padding: 9% 16% 8% 16%; /* mostly apitalized text, not much descenders => bit more top margin */
          font-weight: 500;
          overflow: hidden;
          text-transform: uppercase;
          text-overflow: ellipsis;
          transition: background-color 0.3s ease-in-out;
          text-transform: var(--ha-label-badge-label-text-transform, uppercase);
        }
        .label-badge .label.big span {
          font-size: 90%;
          padding: 10% 12% 7% 12%; /* push smaller text a bit down to center vertically */
        }
        .badge-container .title {
          margin-top: 1em;
          font-size: var(--ha-label-badge-title-font-size, 0.9em);
          width: var(--ha-label-badge-title-width, 5em);
          font-weight: var(--ha-label-badge-title-font-weight, 400);
          overflow: hidden;
          text-overflow: ellipsis;
          line-height: normal;
        }
      `]}updated(changedProperties){super.updated(changedProperties);if(changedProperties.has("image")){this.shadowRoot.getElementById("badge").style.backgroundImage=this.image?`url(${this.image})`:""}}}customElements.define("ha-label-badge",HaLabelBadge)},249:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_classes__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(161),_polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(96),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(20),_util_cover_model__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(212);class HaCoverTiltControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style include="iron-flex"></style>
      <style>
        :host {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>
      <paper-icon-button
        icon="hass:arrow-top-right"
        on-click="onOpenTiltTap"
        title="Open tilt"
        invisible$="[[!entityObj.supportsOpenTilt]]"
        disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:stop"
        on-click="onStopTiltTap"
        invisible$="[[!entityObj.supportsStopTilt]]"
        title="Stop tilt"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:arrow-bottom-left"
        on-click="onCloseTiltTap"
        title="Close tilt"
        invisible$="[[!entityObj.supportsCloseTilt]]"
        disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_4__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyOpenTilt&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyClosedTilt&&!assumedState}onOpenTiltTap(ev){ev.stopPropagation();this.entityObj.openCoverTilt()}onCloseTiltTap(ev){ev.stopPropagation();this.entityObj.closeCoverTilt()}onStopTiltTap(ev){ev.stopPropagation();this.entityObj.stopCoverTilt()}}customElements.define("ha-cover-tilt-controls",HaCoverTiltControls)},255:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(2),iron_flex_layout=__webpack_require__(40),iron_icon=__webpack_require__(97),paper_icon_button=__webpack_require__(96),empty=__webpack_require__(60),iron_iconset_svg=__webpack_require__(75),html_tag=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=html_tag.a`<iron-iconset-svg name="paper-tabs" size="24">
<svg><defs>
<g id="chevron-left"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></g>
<g id="chevron-right"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></g>
</defs></svg>
</iron-iconset-svg>`;document.head.appendChild(template.content);var paper_tab=__webpack_require__(224),iron_menu_behavior=__webpack_require__(113),iron_menubar_behavior=__webpack_require__(228),iron_resizable_behavior=__webpack_require__(85),polymer_fn=__webpack_require__(4),polymer_dom=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        @apply --layout;
        @apply --layout-center;

        height: 48px;
        font-size: 14px;
        font-weight: 500;
        overflow: hidden;
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        user-select: none;

        /* NOTE: Both values are needed, since some phones require the value to be \`transparent\`. */
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent;

        @apply --paper-tabs;
      }

      :host(:dir(rtl)) {
        @apply --layout-horizontal-reverse;
      }

      #tabsContainer {
        position: relative;
        height: 100%;
        white-space: nowrap;
        overflow: hidden;
        @apply --layout-flex-auto;
        @apply --paper-tabs-container;
      }

      #tabsContent {
        height: 100%;
        -moz-flex-basis: auto;
        -ms-flex-basis: auto;
        flex-basis: auto;
        @apply --paper-tabs-content;
      }

      #tabsContent.scrollable {
        position: absolute;
        white-space: nowrap;
      }

      #tabsContent:not(.scrollable),
      #tabsContent.scrollable.fit-container {
        @apply --layout-horizontal;
      }

      #tabsContent.scrollable.fit-container {
        min-width: 100%;
      }

      #tabsContent.scrollable.fit-container > ::slotted(*) {
        /* IE - prevent tabs from compressing when they should scroll. */
        -ms-flex: 1 0 auto;
        -webkit-flex: 1 0 auto;
        flex: 1 0 auto;
      }

      .hidden {
        display: none;
      }

      .not-visible {
        opacity: 0;
        cursor: default;
      }

      paper-icon-button {
        width: 48px;
        height: 48px;
        padding: 12px;
        margin: 0 4px;
      }

      #selectionBar {
        position: absolute;
        height: 0;
        bottom: 0;
        left: 0;
        right: 0;
        border-bottom: 2px solid var(--paper-tabs-selection-bar-color, var(--paper-yellow-a100));
          -webkit-transform: scale(0);
        transform: scale(0);
          -webkit-transform-origin: left center;
        transform-origin: left center;
          transition: -webkit-transform;
        transition: transform;

        @apply --paper-tabs-selection-bar;
      }

      #selectionBar.align-bottom {
        top: 0;
        bottom: auto;
      }

      #selectionBar.expand {
        transition-duration: 0.15s;
        transition-timing-function: cubic-bezier(0.4, 0.0, 1, 1);
      }

      #selectionBar.contract {
        transition-duration: 0.18s;
        transition-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
      }

      #tabsContent > ::slotted(:not(#selectionBar)) {
        height: 100%;
      }
    </style>

    <paper-icon-button icon="paper-tabs:chevron-left" class\$="[[_computeScrollButtonClass(_leftHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onLeftScrollButtonDown" tabindex="-1"></paper-icon-button>

    <div id="tabsContainer" on-track="_scroll" on-down="_down">
      <div id="tabsContent" class\$="[[_computeTabsContentClass(scrollable, fitContainer)]]">
        <div id="selectionBar" class\$="[[_computeSelectionBarClass(noBar, alignBottom)]]" on-transitionend="_onBarTransitionEnd"></div>
        <slot></slot>
      </div>
    </div>

    <paper-icon-button icon="paper-tabs:chevron-right" class\$="[[_computeScrollButtonClass(_rightHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onRightScrollButtonDown" tabindex="-1"></paper-icon-button>
`,is:"paper-tabs",behaviors:[iron_resizable_behavior.a,iron_menubar_behavior.a],properties:{noink:{type:Boolean,value:!1,observer:"_noinkChanged"},noBar:{type:Boolean,value:!1},noSlide:{type:Boolean,value:!1},scrollable:{type:Boolean,value:!1},fitContainer:{type:Boolean,value:!1},disableDrag:{type:Boolean,value:!1},hideScrollButtons:{type:Boolean,value:!1},alignBottom:{type:Boolean,value:!1},selectable:{type:String,value:"paper-tab"},autoselect:{type:Boolean,value:!1},autoselectDelay:{type:Number,value:0},_step:{type:Number,value:10},_holdDelay:{type:Number,value:1},_leftHidden:{type:Boolean,value:!1},_rightHidden:{type:Boolean,value:!1},_previousTab:{type:Object}},hostAttributes:{role:"tablist"},listeners:{"iron-resize":"_onTabSizingChanged","iron-items-changed":"_onTabSizingChanged","iron-select":"_onIronSelect","iron-deselect":"_onIronDeselect"},keyBindings:{"left:keyup right:keyup":"_onArrowKeyup"},created:function(){this._holdJob=null;this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0;this._bindDelayedActivationHandler=this._delayedActivationHandler.bind(this);this.addEventListener("blur",this._onBlurCapture.bind(this),!0)},ready:function(){this.setScrollDirection("y",this.$.tabsContainer)},detached:function(){this._cancelPendingActivation()},_noinkChanged:function(noink){var childTabs=Object(polymer_dom.b)(this).querySelectorAll("paper-tab");childTabs.forEach(noink?this._setNoinkAttribute:this._removeNoinkAttribute)},_setNoinkAttribute:function(element){element.setAttribute("noink","")},_removeNoinkAttribute:function(element){element.removeAttribute("noink")},_computeScrollButtonClass:function(hideThisButton,scrollable,hideScrollButtons){if(!scrollable||hideScrollButtons){return"hidden"}if(hideThisButton){return"not-visible"}return""},_computeTabsContentClass:function(scrollable,fitContainer){return scrollable?"scrollable"+(fitContainer?" fit-container":""):" fit-container"},_computeSelectionBarClass:function(noBar,alignBottom){if(noBar){return"hidden"}else if(alignBottom){return"align-bottom"}return""},_onTabSizingChanged:function(){this.debounce("_onTabSizingChanged",function(){this._scroll();this._tabChanged(this.selectedItem)},10)},_onIronSelect:function(event){this._tabChanged(event.detail.item,this._previousTab);this._previousTab=event.detail.item;this.cancelDebouncer("tab-changed")},_onIronDeselect:function(event){this.debounce("tab-changed",function(){this._tabChanged(null,this._previousTab);this._previousTab=null},1)},_activateHandler:function(){this._cancelPendingActivation();iron_menu_behavior.b._activateHandler.apply(this,arguments)},_scheduleActivation:function(item,delay){this._pendingActivationItem=item;this._pendingActivationTimeout=this.async(this._bindDelayedActivationHandler,delay)},_delayedActivationHandler:function(){var item=this._pendingActivationItem;this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0;item.fire(this.activateEvent,null,{bubbles:!0,cancelable:!0})},_cancelPendingActivation:function(){if(this._pendingActivationTimeout!==void 0){this.cancelAsync(this._pendingActivationTimeout);this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0}},_onArrowKeyup:function(event){if(this.autoselect){this._scheduleActivation(this.focusedItem,this.autoselectDelay)}},_onBlurCapture:function(event){if(event.target===this._pendingActivationItem){this._cancelPendingActivation()}},get _tabContainerScrollSize(){return Math.max(0,this.$.tabsContainer.scrollWidth-this.$.tabsContainer.offsetWidth)},_scroll:function(e,detail){if(!this.scrollable){return}var ddx=detail&&-detail.ddx||0;this._affectScroll(ddx)},_down:function(e){this.async(function(){if(this._defaultFocusAsync){this.cancelAsync(this._defaultFocusAsync);this._defaultFocusAsync=null}},1)},_affectScroll:function(dx){this.$.tabsContainer.scrollLeft+=dx;var scrollLeft=this.$.tabsContainer.scrollLeft;this._leftHidden=0===scrollLeft;this._rightHidden=scrollLeft===this._tabContainerScrollSize},_onLeftScrollButtonDown:function(){this._scrollToLeft();this._holdJob=setInterval(this._scrollToLeft.bind(this),this._holdDelay)},_onRightScrollButtonDown:function(){this._scrollToRight();this._holdJob=setInterval(this._scrollToRight.bind(this),this._holdDelay)},_onScrollButtonUp:function(){clearInterval(this._holdJob);this._holdJob=null},_scrollToLeft:function(){this._affectScroll(-this._step)},_scrollToRight:function(){this._affectScroll(this._step)},_tabChanged:function(tab,old){if(!tab){this.$.selectionBar.classList.remove("expand");this.$.selectionBar.classList.remove("contract");this._positionBar(0,0);return}var r=this.$.tabsContent.getBoundingClientRect(),w=r.width,tabRect=tab.getBoundingClientRect(),tabOffsetLeft=tabRect.left-r.left;this._pos={width:this._calcPercent(tabRect.width,w),left:this._calcPercent(tabOffsetLeft,w)};if(this.noSlide||null==old){this.$.selectionBar.classList.remove("expand");this.$.selectionBar.classList.remove("contract");this._positionBar(this._pos.width,this._pos.left);return}var oldRect=old.getBoundingClientRect(),oldIndex=this.items.indexOf(old),index=this.items.indexOf(tab),m=5;this.$.selectionBar.classList.add("expand");var moveRight=oldIndex<index,isRTL=this._isRTL;if(isRTL){moveRight=!moveRight}if(moveRight){this._positionBar(this._calcPercent(tabRect.left+tabRect.width-oldRect.left,w)-m,this._left)}else{this._positionBar(this._calcPercent(oldRect.left+oldRect.width-tabRect.left,w)-m,this._calcPercent(tabOffsetLeft,w)+m)}if(this.scrollable){this._scrollToSelectedIfNeeded(tabRect.width,tabOffsetLeft)}},_scrollToSelectedIfNeeded:function(tabWidth,tabOffsetLeft){var l=tabOffsetLeft-this.$.tabsContainer.scrollLeft;if(0>l){this.$.tabsContainer.scrollLeft+=l}else{l+=tabWidth-this.$.tabsContainer.offsetWidth;if(0<l){this.$.tabsContainer.scrollLeft+=l}}},_calcPercent:function(w,w0){return 100*w/w0},_positionBar:function(width,left){width=width||0;left=left||0;this._width=width;this._left=left;this.transform("translateX("+left+"%) scaleX("+width/100+")",this.$.selectionBar)},_onBarTransitionEnd:function(e){var cl=this.$.selectionBar.classList;if(cl.contains("expand")){cl.remove("expand");cl.add("contract");this._positionBar(this._pos.width,this._pos.left)}else if(cl.contains("contract")){cl.remove("contract")}}})},258:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(96),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(20),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(81),_common_config_is_component_loaded__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(198),_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(44);class HaStartVoiceButton extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <paper-icon-button
        icon="hass:microphone"
        hidden$="[[!canListen]]"
        on-click="handleListenClick"
      ></paper-icon-button>
    `}static get properties(){return{hass:{type:Object,value:null},canListen:{type:Boolean,computed:"computeCanListen(hass)",notify:!0}}}computeCanListen(hass){return"webkitSpeechRecognition"in window&&Object(_common_config_is_component_loaded__WEBPACK_IMPORTED_MODULE_4__.a)(hass,"conversation")}handleListenClick(){Object(_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_5__.a)(this,"show-dialog",{dialogImport:()=>__webpack_require__.e(131).then(__webpack_require__.bind(null,336)),dialogTag:"ha-voice-command-dialog"})}}customElements.define("ha-start-voice-button",HaStartVoiceButton)},259:function(module,__webpack_exports__,__webpack_require__){"use strict";var lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5),lit_html_directives_class_map__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(63),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(162),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(159),_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(163),_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(178),_common_entity_timer_time_remaining__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(240),_common_datetime_seconds_to_duration__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(232),_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(44),_ha_label_badge__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(248);class HaStateLabelBadge extends lit_element__WEBPACK_IMPORTED_MODULE_0__.a{constructor(...args){super(...args);this.hass=void 0;this.state=void 0;this._connected=void 0;this._updateRemaining=void 0;this._timerTimeRemaining=void 0}connectedCallback(){super.connectedCallback();this._connected=!0;this.startInterval(this.state)}disconnectedCallback(){super.disconnectedCallback();this._connected=!1;this.clearInterval()}render(){const state=this.state;if(!state){return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
        ${this.renderStyle()}
        <ha-label-badge label="not found"></ha-label-badge>
      `}const domain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__.a)(state);return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
      ${this.renderStyle()}
      <ha-label-badge
        class="${Object(lit_html_directives_class_map__WEBPACK_IMPORTED_MODULE_1__.a)({[domain]:!0,"has-unit_of_measurement":"unit_of_measurement"in state.attributes})}"
        .value="${this._computeValue(domain,state)}"
        .icon="${this._computeIcon(domain,state)}"
        .image="${state.attributes.entity_picture}"
        .label="${this._computeLabel(domain,state,this._timerTimeRemaining)}"
        .description="${Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_3__.a)(state)}"
      ></ha-label-badge>
    `}static get properties(){return{hass:{},state:{},_timerTimeRemaining:{}}}firstUpdated(changedProperties){super.firstUpdated(changedProperties);this.addEventListener("click",ev=>{ev.stopPropagation();if(this.state){Object(_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_8__.a)(this,"hass-more-info",{entityId:this.state.entity_id})}})}updated(changedProperties){super.updated(changedProperties);if(this._connected&&changedProperties.has("state")){this.startInterval(this.state)}}_computeValue(domain,state){switch(domain){case"binary_sensor":case"device_tracker":case"updater":case"sun":case"alarm_control_panel":case"timer":return null;case"sensor":default:return"unknown"===state.state?"-":this.hass.localize(`component.${domain}.state.${state.state}`)||state.state;}}_computeIcon(domain,state){if("unavailable"===state.state){return null}switch(domain){case"alarm_control_panel":if("pending"===state.state){return"hass:clock-fast"}if("armed_away"===state.state){return"hass:nature"}if("armed_home"===state.state){return"hass:home-variant"}if("armed_night"===state.state){return"hass:weather-night"}if("armed_custom_bypass"===state.state){return"hass:shield-home"}if("triggered"===state.state){return"hass:alert-circle"}return Object(_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__.a)(domain,state.state);case"binary_sensor":case"device_tracker":case"updater":case"person":return Object(_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_5__.a)(state);case"sun":return"above_horizon"===state.state?Object(_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__.a)(domain):"hass:brightness-3";case"timer":return"active"===state.state?"hass:timer":"hass:timer-off";default:return null;}}_computeLabel(domain,state,_timerTimeRemaining){if("unavailable"===state.state||["device_tracker","alarm_control_panel","person"].includes(domain)){return this.hass.localize(`state_badge.${domain}.${state.state}`)||this.hass.localize(`state_badge.default.${state.state}`)||state.state}if("timer"===domain){return Object(_common_datetime_seconds_to_duration__WEBPACK_IMPORTED_MODULE_7__.a)(_timerTimeRemaining)}return state.attributes.unit_of_measurement||null}clearInterval(){if(this._updateRemaining){clearInterval(this._updateRemaining);this._updateRemaining=void 0}}startInterval(stateObj){this.clearInterval();if(stateObj&&"timer"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__.a)(stateObj)){this.calculateTimerRemaining(stateObj);if("active"===stateObj.state){this._updateRemaining=window.setInterval(()=>this.calculateTimerRemaining(this.state),1e3)}}}calculateTimerRemaining(stateObj){this._timerTimeRemaining=Object(_common_entity_timer_time_remaining__WEBPACK_IMPORTED_MODULE_6__.a)(stateObj)}renderStyle(){return lit_element__WEBPACK_IMPORTED_MODULE_0__.e`
      <style>
        :host {
          cursor: pointer;
        }

        ha-label-badge {
          --ha-label-badge-color: var(--label-badge-red, #df4c1e);
        }
        ha-label-badge.has-unit_of_measurement {
          --ha-label-badge-label-text-transform: none;
        }

        ha-label-badge.binary_sensor,
        ha-label-badge.updater {
          --ha-label-badge-color: var(--label-badge-blue, #039be5);
        }

        .red {
          --ha-label-badge-color: var(--label-badge-red, #df4c1e);
        }

        .blue {
          --ha-label-badge-color: var(--label-badge-blue, #039be5);
        }

        .green {
          --ha-label-badge-color: var(--label-badge-green, #0da035);
        }

        .yellow {
          --ha-label-badge-color: var(--label-badge-yellow, #f4b400);
        }

        .grey {
          --ha-label-badge-color: var(
            --label-badge-grey,
            var(--paper-grey-500)
          );
        }
      </style>
    `}}customElements.define("ha-state-label-badge",HaStateLabelBadge)},260:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(20),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(107);class HaClimateState extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          display: flex;
          flex-direction: column;
          justify-content: center;
          white-space: nowrap;
        }

        .target {
          color: var(--primary-text-color);
        }

        .current {
          color: var(--secondary-text-color);
        }

        .state-label {
          font-weight: bold;
          text-transform: capitalize;
        }
      </style>

      <div class="target">
        <template is="dom-if" if="[[_hasKnownState(stateObj.state)]]">
          <span class="state-label"> [[_localizeState(stateObj.state)]] </span>
        </template>
        [[computeTarget(hass, stateObj)]]
      </div>

      <template is="dom-if" if="[[currentStatus]]">
        <div class="current">
          [[localize('ui.card.climate.currently')]]: [[currentStatus]]
        </div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object,currentStatus:{type:String,computed:"computeCurrentStatus(hass, stateObj)"}}}computeCurrentStatus(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.current_temperature){return`${stateObj.attributes.current_temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.current_humidity){return`${stateObj.attributes.current_humidity} %`}return null}computeTarget(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.target_temp_low&&null!=stateObj.attributes.target_temp_high){return`${stateObj.attributes.target_temp_low} - ${stateObj.attributes.target_temp_high} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.temperature){return`${stateObj.attributes.temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.target_humidity_low&&null!=stateObj.attributes.target_humidity_high){return`${stateObj.attributes.target_humidity_low} - ${stateObj.attributes.target_humidity_high} %`}if(null!=stateObj.attributes.humidity){return`${stateObj.attributes.humidity} %`}return""}_hasKnownState(state){return"unknown"!==state}_localizeState(state){return this.localize(`state.climate.${state}`)||state}}customElements.define("ha-climate-state",HaClimateState)},261:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(96),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(20),_util_cover_model__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(212);class HaCoverControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        .state {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>

      <div class="state">
        <paper-icon-button
          icon="hass:arrow-up"
          on-click="onOpenTap"
          invisible$="[[!entityObj.supportsOpen]]"
          disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:stop"
          on-click="onStopTap"
          invisible$="[[!entityObj.supportsStop]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:arrow-down"
          on-click="onCloseTap"
          invisible$="[[!entityObj.supportsClose]]"
          disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_3__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyOpen||entityObj.isOpening)&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyClosed||entityObj.isClosing)&&!assumedState}onOpenTap(ev){ev.stopPropagation();this.entityObj.openCover()}onCloseTap(ev){ev.stopPropagation();this.entityObj.closeCover()}onStopTap(ev){ev.stopPropagation();this.entityObj.stopCover()}}customElements.define("ha-cover-controls",HaCoverControls)},262:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathround2=Math.round,_polymer_paper_slider__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(141);const PaperSliderClass=customElements.get("paper-slider");let subTemplate;class HaSlider extends PaperSliderClass{static get template(){if(!subTemplate){subTemplate=PaperSliderClass.template.cloneNode(!0);const superStyle=subTemplate.content.querySelector("style");superStyle.appendChild(document.createTextNode(`
          :host([dir="rtl"]) #sliderContainer.pin.expand > .slider-knob > .slider-knob-inner::after {
            -webkit-transform: scale(1) translate(0, -17px) scaleX(-1) !important;
            transform: scale(1) translate(0, -17px) scaleX(-1) !important;
            }
        `))}return subTemplate}_calcStep(value){if(!this.step){return parseFloat(value)}const numSteps=_Mathround2((value-this.min)/this.step),stepStr=this.step.toString(),stepPointAt=stepStr.indexOf(".");if(-1!==stepPointAt){const precision=10**(stepStr.length-stepPointAt-1);return _Mathround2((numSteps*this.step+this.min)*precision)/precision}return numSteps*this.step+this.min}}customElements.define("ha-slider",HaSlider)},263:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return getGroupEntities});function getGroupEntities(entities,group){const result={};group.attributes.entity_id.forEach(entityId=>{const entity=entities[entityId];if(entity){result[entity.entity_id]=entity}});return result}},269:function(module,__webpack_exports__,__webpack_require__){"use strict";function canToggleDomain(hass,domain){const services=hass.services[domain];if(!services){return!1}if("lock"===domain){return"lock"in services}if("cover"===domain){return"open_cover"in services}return"turn_on"in services}var compute_state_domain=__webpack_require__(162),supports_feature=__webpack_require__(204);__webpack_require__.d(__webpack_exports__,"a",function(){return canToggleState});function canToggleState(hass,stateObj){const domain=Object(compute_state_domain.a)(stateObj);if("group"===domain){return"on"===stateObj.state||"off"===stateObj.state}if("climate"===domain){return Object(supports_feature.a)(stateObj,4096)}return canToggleDomain(hass,domain)}},280:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_element=__webpack_require__(20),iron_flex_layout_classes=__webpack_require__(161),html_tag=__webpack_require__(3),ha_relative_time=__webpack_require__(229),state_badge=__webpack_require__(170),compute_state_name=__webpack_require__(159),compute_rtl=__webpack_require__(83);class state_info_StateInfo extends polymer_element.a{static get template(){return html_tag.a`
      ${this.styleTemplate} ${this.stateBadgeTemplate} ${this.infoTemplate}
    `}static get styleTemplate(){return html_tag.a`
      <style>
        :host {
          @apply --paper-font-body1;
          min-width: 120px;
          white-space: nowrap;
        }

        state-badge {
          float: left;
        }

        :host([rtl]) state-badge {
          float: right;
        }

        .info {
          margin-left: 56px;
        }

        :host([rtl]) .info {
          margin-right: 56px;
          margin-left: 0;
          text-align: right;
        }

        .name {
          @apply --paper-font-common-nowrap;
          color: var(--primary-text-color);
          line-height: 40px;
        }

        .name[in-dialog],
        :host([secondary-line]) .name {
          line-height: 20px;
        }

        .time-ago,
        .extra-info,
        .extra-info > * {
          @apply --paper-font-common-nowrap;
          color: var(--secondary-text-color);
        }
      </style>
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get infoTemplate(){return html_tag.a`
      <div class="info">
        <div class="name" in-dialog$="[[inDialog]]">
          [[computeStateName(stateObj)]]
        </div>

        <template is="dom-if" if="[[inDialog]]">
          <div class="time-ago">
            <ha-relative-time
              hass="[[hass]]"
              datetime="[[stateObj.last_changed]]"
            ></ha-relative-time>
          </div>
        </template>
        <template is="dom-if" if="[[!inDialog]]">
          <div class="extra-info"><slot> </slot></div>
        </template>
      </div>
    `}static get properties(){return{detailed:{type:Boolean,value:!1},hass:Object,stateObj:Object,inDialog:Boolean,rtl:{type:Boolean,reflectToAttribute:!0,computed:"computeRTL(hass)"}}}computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("state-info",state_info_StateInfo);var ha_climate_state=__webpack_require__(260);class state_card_climate_StateCardClimate extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          @apply --paper-font-body1;
          line-height: 1.5;
        }

        ha-climate-state {
          margin-left: 16px;
          text-align: right;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-climate-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-climate-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-climate",state_card_climate_StateCardClimate);var mwc_button=__webpack_require__(73),localize_mixin=__webpack_require__(107);class state_card_configurator_StateCardConfigurator extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        mwc-button {
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <mwc-button hidden$="[[inDialog]]"
          >[[_localizeState(stateObj.state)]]</mwc-button
        >
      </div>

      <!-- pre load the image so the dialog is rendered the proper size -->
      <template is="dom-if" if="[[stateObj.attributes.description_image]]">
        <img hidden="" src="[[stateObj.attributes.description_image]]" />
      </template>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}_localizeState(state){return this.localize(`state.configurator.${state}`)}}customElements.define("state-card-configurator",state_card_configurator_StateCardConfigurator);var ha_cover_controls=__webpack_require__(261),ha_cover_tilt_controls=__webpack_require__(249),cover_model=__webpack_require__(212);class state_card_cover_StateCardCover extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          line-height: 1.5;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="horizontal layout">
          <ha-cover-controls
            hidden$="[[entityObj.isTiltOnly]]"
            hass="[[hass]]"
            state-obj="[[stateObj]]"
          ></ha-cover-controls>
          <ha-cover-tilt-controls
            hidden$="[[!entityObj.isTiltOnly]]"
            hass="[[hass]]"
            state-obj="[[stateObj]]"
          ></ha-cover-tilt-controls>
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){var entity=new cover_model.a(hass,stateObj);return entity}}customElements.define("state-card-cover",state_card_cover_StateCardCover);var compute_state_display=__webpack_require__(201),attribute_class_names=__webpack_require__(234);class state_card_display_StateCardDisplay extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          @apply --layout-horizontal;
          @apply --layout-justified;
          @apply --layout-baseline;
        }

        :host([rtl]) {
          direction: rtl;
          text-align: right;
        }

        state-info {
          flex: 1 1 auto;
          min-width: 0;
        }
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);
          margin-left: 16px;
          text-align: right;
          max-width: 40%;
          flex: 0 0 auto;
        }
        :host([rtl]) .state {
          margin-right: 16px;
          margin-left: 0;
          text-align: left;
        }

        .state.has-unit_of_measurement {
          white-space: nowrap;
        }
      </style>

      ${this.stateInfoTemplate}
      <div class$="[[computeClassNames(stateObj)]]">
        [[computeStateDisplay(localize, stateObj, language)]]
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},rtl:{type:Boolean,reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}computeStateDisplay(localize,stateObj,language){return Object(compute_state_display.a)(localize,stateObj,language)}computeClassNames(stateObj){const classes=["state",Object(attribute_class_names.a)(stateObj,["unit_of_measurement"])];return classes.join(" ")}_computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("state-card-display",state_card_display_StateCardDisplay);var iron_resizable_behavior=__webpack_require__(85),paper_input=__webpack_require__(80),legacy_class=__webpack_require__(64),ha_slider=__webpack_require__(262);class state_card_input_number_StateCardInputNumber extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        ha-slider {
          margin-left: auto;
        }
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);

          text-align: right;
          line-height: 40px;
        }
        .sliderstate {
          min-width: 45px;
        }
        ha-slider[hidden] {
          display: none !important;
        }
        paper-input {
          text-align: right;
          margin-left: auto;
        }
      </style>

      <div class="horizontal justified layout" id="input_number_card">
        ${this.stateInfoTemplate}
        <ha-slider
          min="[[min]]"
          max="[[max]]"
          value="{{value}}"
          step="[[step]]"
          hidden="[[hiddenslider]]"
          pin=""
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          id="slider"
          ignore-bar-touch=""
        >
        </ha-slider>
        <paper-input
          no-label-float=""
          auto-validate=""
          pattern="[0-9]+([\\.][0-9]+)?"
          step="[[step]]"
          min="[[min]]"
          max="[[max]]"
          value="{{value}}"
          type="number"
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          hidden="[[hiddenbox]]"
        >
        </paper-input>
        <div class="state" hidden="[[hiddenbox]]">
          [[stateObj.attributes.unit_of_measurement]]
        </div>
        <div
          id="sliderstate"
          class="state sliderstate"
          hidden="[[hiddenslider]]"
        >
          [[value]] [[stateObj.attributes.unit_of_measurement]]
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}ready(){super.ready();if("function"===typeof ResizeObserver){const ro=new ResizeObserver(entries=>{entries.forEach(()=>{this.hiddenState()})});ro.observe(this.$.input_number_card)}else{this.addEventListener("iron-resize",this.hiddenState)}}static get properties(){return{hass:Object,hiddenbox:{type:Boolean,value:!0},hiddenslider:{type:Boolean,value:!0},inDialog:{type:Boolean,value:!1},stateObj:{type:Object,observer:"stateObjectChanged"},min:{type:Number,value:0},max:{type:Number,value:100},maxlength:{type:Number,value:3},step:Number,value:Number,mode:String}}hiddenState(){if("slider"!==this.mode)return;const sliderwidth=this.$.slider.offsetWidth;if(100>sliderwidth){this.$.sliderstate.hidden=!0}else if(145<=sliderwidth){this.$.sliderstate.hidden=!1}}stateObjectChanged(newVal){const prevMode=this.mode;this.setProperties({min:+newVal.attributes.min,max:+newVal.attributes.max,step:+newVal.attributes.step,value:+newVal.state,mode:newVal.attributes.mode+"",maxlength:(newVal.attributes.max+"").length,hiddenbox:"box"!==newVal.attributes.mode,hiddenslider:"slider"!==newVal.attributes.mode});if("slider"===this.mode&&"slider"!==prevMode){this.hiddenState()}}selectedValueChanged(){if(this.value===+this.stateObj.state){return}this.hass.callService("input_number","set_value",{value:this.value,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_number",state_card_input_number_StateCardInputNumber);var paper_dropdown_menu=__webpack_require__(130),paper_item=__webpack_require__(127),paper_listbox=__webpack_require__(129);class state_card_input_select_StateCardInputSelect extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }

        state-badge {
          float: left;
          margin-top: 10px;
        }

        paper-dropdown-menu {
          display: block;
          margin-left: 53px;
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      ${this.stateBadgeTemplate}
      <paper-dropdown-menu
        on-click="stopPropagation"
        selected-item-label="{{selectedOption}}"
        label="[[_computeStateName(stateObj)]]"
      >
        <paper-listbox
          slot="dropdown-content"
          selected="[[computeSelected(stateObj)]]"
        >
          <template is="dom-repeat" items="[[stateObj.attributes.options]]">
            <paper-item>[[item]]</paper-item>
          </template>
        </paper-listbox>
      </paper-dropdown-menu>
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},selectedOption:{type:String,observer:"selectedOptionChanged"}}}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}computeSelected(stateObj){return stateObj.attributes.options.indexOf(stateObj.state)}selectedOptionChanged(option){if(""===option||option===this.stateObj.state){return}this.hass.callService("input_select","select_option",{option:option,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_select",state_card_input_select_StateCardInputSelect);class state_card_input_text_StateCardInputText extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-input {
          margin-left: 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <paper-input
          no-label-float=""
          minlength="[[stateObj.attributes.min]]"
          maxlength="[[stateObj.attributes.max]]"
          value="{{value}}"
          auto-validate="[[stateObj.attributes.pattern]]"
          pattern="[[stateObj.attributes.pattern]]"
          type="[[stateObj.attributes.mode]]"
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          placeholder="(empty value)"
        >
        </paper-input>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,inDialog:{type:Boolean,value:!1},stateObj:{type:Object,observer:"stateObjectChanged"},pattern:String,value:String}}stateObjectChanged(newVal){this.value=newVal.state}selectedValueChanged(){if(this.value===this.stateObj.state){return}this.hass.callService("input_text","set_value",{value:this.value,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_text",state_card_input_text_StateCardInputText);class state_card_lock_StateCardLock extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        mwc-button {
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <mwc-button
          on-click="_callService"
          data-service="unlock"
          hidden$="[[!isLocked]]"
          >[[localize('ui.card.lock.unlock')]]</mwc-button
        >
        <mwc-button
          on-click="_callService"
          data-service="lock"
          hidden$="[[isLocked]]"
          >[[localize('ui.card.lock.lock')]]</mwc-button
        >
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"_stateObjChanged"},inDialog:{type:Boolean,value:!1},isLocked:Boolean}}_stateObjChanged(newVal){if(newVal){this.isLocked="locked"===newVal.state}}_callService(ev){ev.stopPropagation();const service=ev.target.dataset.service,data={entity_id:this.stateObj.entity_id};this.hass.callService("lock",service,data)}}customElements.define("state-card-lock",state_card_lock_StateCardLock);var hass_media_player_model=__webpack_require__(233);class state_card_media_player_StateCardMediaPlayer extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          line-height: 1.5;
        }

        .state {
          @apply --paper-font-common-nowrap;
          @apply --paper-font-body1;
          margin-left: 16px;
          text-align: right;
        }

        .main-text {
          @apply --paper-font-common-nowrap;
          color: var(--primary-text-color);
          text-transform: capitalize;
        }

        .main-text[take-height] {
          line-height: 40px;
        }

        .secondary-text {
          @apply --paper-font-common-nowrap;
          color: var(--secondary-text-color);
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="state">
          <div class="main-text" take-height$="[[!playerObj.secondaryTitle]]">
            [[computePrimaryText(localize, playerObj)]]
          </div>
          <div class="secondary-text">[[playerObj.secondaryTitle]]</div>
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},playerObj:{type:Object,computed:"computePlayerObj(hass, stateObj)"}}}computePlayerObj(hass,stateObj){return new hass_media_player_model.a(hass,stateObj)}computePrimaryText(localize,playerObj){return playerObj.primaryTitle||localize(`state.media_player.${playerObj.stateObj.state}`)||localize(`state.default.${playerObj.stateObj.state}`)||playerObj.stateObj.state}}customElements.define("state-card-media_player",state_card_media_player_StateCardMediaPlayer);class state_card_scene_StateCardScene extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        mwc-button {
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <mwc-button on-click="activateScene"
          >[[localize('ui.card.scene.activate')]]</mwc-button
        >
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}activateScene(ev){ev.stopPropagation();this.hass.callService("scene","turn_on",{entity_id:this.stateObj.entity_id})}}customElements.define("state-card-scene",state_card_scene_StateCardScene);var ha_entity_toggle=__webpack_require__(215);class state_card_script_StateCardScript extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        mwc-button {
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }

        ha-entity-toggle {
          margin-left: 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <template is="dom-if" if="[[stateObj.attributes.can_cancel]]">
          <ha-entity-toggle
            state-obj="[[stateObj]]"
            hass="[[hass]]"
          ></ha-entity-toggle>
        </template>
        <template is="dom-if" if="[[!stateObj.attributes.can_cancel]]">
          <mwc-button on-click="fireScript"
            >[[localize('ui.card.script.execute')]]</mwc-button
          >
        </template>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}fireScript(ev){ev.stopPropagation();this.hass.callService("script","turn_on",{entity_id:this.stateObj.entity_id})}}customElements.define("state-card-script",state_card_script_StateCardScript);var timer_time_remaining=__webpack_require__(240),seconds_to_duration=__webpack_require__(232);class state_card_timer_StateCardTimer extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);

          margin-left: 16px;
          text-align: right;
          line-height: 40px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="state">[[_secondsToDuration(timeRemaining)]]</div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjChanged"},timeRemaining:Number,inDialog:{type:Boolean,value:!1}}}connectedCallback(){super.connectedCallback();this.startInterval(this.stateObj)}disconnectedCallback(){super.disconnectedCallback();this.clearInterval()}stateObjChanged(stateObj){this.startInterval(stateObj)}clearInterval(){if(this._updateRemaining){clearInterval(this._updateRemaining);this._updateRemaining=null}}startInterval(stateObj){this.clearInterval();this.calculateRemaining(stateObj);if("active"===stateObj.state){this._updateRemaining=setInterval(()=>this.calculateRemaining(this.stateObj),1e3)}}calculateRemaining(stateObj){this.timeRemaining=Object(timer_time_remaining.a)(stateObj)}_secondsToDuration(time){return Object(seconds_to_duration.a)(time)}}customElements.define("state-card-timer",state_card_timer_StateCardTimer);class state_card_toggle_StateCardToggle extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        ha-entity-toggle {
          margin: -4px -16px -4px 0;
          padding: 4px 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-entity-toggle
          state-obj="[[stateObj]]"
          hass="[[hass]]"
        ></ha-entity-toggle>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-toggle",state_card_toggle_StateCardToggle);const STATES_INTERCEPTABLE={cleaning:{action:"return_to_base",service:"return_to_base"},docked:{action:"start_cleaning",service:"start"},idle:{action:"start_cleaning",service:"start"},off:{action:"turn_on",service:"turn_on"},on:{action:"turn_off",service:"turn_off"},paused:{action:"resume_cleaning",service:"start"}};class ha_vacuum_state_HaVacuumState extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        mwc-button {
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
        mwc-button[disabled] {
          background-color: transparent;
          color: var(--secondary-text-color);
        }
      </style>

      <mwc-button on-click="_callService" disabled="[[!_interceptable]]"
        >[[_computeLabel(stateObj.state, _interceptable)]]</mwc-button
      >
    `}static get properties(){return{hass:Object,stateObj:Object,_interceptable:{type:Boolean,computed:"_computeInterceptable(stateObj.state, stateObj.attributes.supported_features)"}}}_computeInterceptable(state,supportedFeatures){return state in STATES_INTERCEPTABLE&&0!==supportedFeatures}_computeLabel(state,interceptable){return interceptable?this.localize(`ui.card.vacuum.actions.${STATES_INTERCEPTABLE[state].action}`):this.localize(`state.vacuum.${state}`)}_callService(ev){ev.stopPropagation();const stateObj=this.stateObj,service=STATES_INTERCEPTABLE[stateObj.state].service;this.hass.callService("vacuum",service,{entity_id:stateObj.entity_id})}}customElements.define("ha-vacuum-state",ha_vacuum_state_HaVacuumState);class state_card_vacuum_StateCardVacuum extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-vacuum-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-vacuum-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-vacuum",state_card_vacuum_StateCardVacuum);class ha_water_heater_state_HaWaterHeaterState extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: flex;
          flex-direction: column;
          justify-content: center;
          white-space: nowrap;
        }

        .target {
          color: var(--primary-text-color);
        }

        .current {
          color: var(--secondary-text-color);
        }

        .state-label {
          font-weight: bold;
          text-transform: capitalize;
        }
      </style>

      <div class="target">
        <span class="state-label"> [[_localizeState(stateObj.state)]] </span>
        [[computeTarget(hass, stateObj)]]
      </div>

      <template is="dom-if" if="[[currentStatus]]">
        <div class="current">
          [[localize('ui.card.water_heater.currently')]]: [[currentStatus]]
        </div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object}}computeTarget(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.target_temp_low&&null!=stateObj.attributes.target_temp_high){return`${stateObj.attributes.target_temp_low} - ${stateObj.attributes.target_temp_high} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.temperature){return`${stateObj.attributes.temperature} ${hass.config.unit_system.temperature}`}return""}_localizeState(state){return this.localize(`state.water_heater.${state}`)||state}}customElements.define("ha-water_heater-state",ha_water_heater_state_HaWaterHeaterState);class state_card_water_heater_StateCardWaterHeater extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          @apply --paper-font-body1;
          line-height: 1.5;
        }

        ha-water_heater-state {
          margin-left: 16px;
          text-align: right;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-water_heater-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-water_heater-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-water_heater",state_card_water_heater_StateCardWaterHeater);class state_card_weblink_StateCardWeblink extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }
        .name {
          @apply --paper-font-common-nowrap;
          @apply --paper-font-body1;
          color: var(--primary-color);

          text-transform: capitalize;
          line-height: 40px;
          margin-left: 16px;
        }
      </style>

      ${this.stateBadgeTemplate}
      <a href$="[[stateObj.state]]" target="_blank" class="name" id="link"
        >[[_computeStateName(stateObj)]]</a
      >
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get properties(){return{stateObj:Object,inDialog:{type:Boolean,value:!1}}}ready(){super.ready();this.addEventListener("click",ev=>this.onTap(ev))}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}onTap(ev){ev.stopPropagation();ev.preventDefault();window.open(this.stateObj.state,"_blank")}}customElements.define("state-card-weblink",state_card_weblink_StateCardWeblink);var can_toggle_state=__webpack_require__(269),compute_state_domain=__webpack_require__(162),common_const=__webpack_require__(109);function stateCardType(hass,stateObj){if("unavailable"===stateObj.state){return"display"}const domain=Object(compute_state_domain.a)(stateObj);if(common_const.g.includes(domain)){return domain}if(Object(can_toggle_state.a)(hass,stateObj)&&"hidden"!==stateObj.attributes.control){return"toggle"}return"display"}var dynamic_content_updater=__webpack_require__(242);class state_card_content_StateCardContent extends polymer_element.a{static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}static get observers(){return["inputChanged(hass, inDialog, stateObj)"]}inputChanged(hass,inDialog,stateObj){let stateCard;if(!stateObj||!hass)return;if(stateObj.attributes&&"custom_ui_state_card"in stateObj.attributes){stateCard=stateObj.attributes.custom_ui_state_card}else{stateCard="state-card-"+stateCardType(hass,stateObj)}Object(dynamic_content_updater.a)(this,stateCard.toUpperCase(),{hass:hass,stateObj:stateObj,inDialog:inDialog})}}customElements.define("state-card-content",state_card_content_StateCardContent)},281:function(module,__webpack_exports__,__webpack_require__){"use strict";var _app_scroll_effects_behavior_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(119),_helpers_helpers_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(106);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_helpers_helpers_js__WEBPACK_IMPORTED_MODULE_1__.b)("waterfall",{run:function run(){this.shadow=this.isOnScreen()&&this.isContentBelow()}})},284:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_classes__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(161),_polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(96),_polymer_paper_progress_paper_progress__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(140),_polymer_paper_styles_element_styles_paper_material_styles__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(168),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(20),_util_hass_media_player_model__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(233),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(159),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(81),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(107);class HaMediaPlayerCard extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_9__.a)(Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_8__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_5__.a)){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_4__.a`
      <style
        include="paper-material-styles iron-flex iron-flex-alignment iron-positioning"
      >
        :host {
          @apply --paper-material-elevation-1;
          display: block;
          position: relative;
          font-size: 0px;
          border-radius: 2px;
        }

        .banner {
          position: relative;
          background-color: white;
          border-top-left-radius: 2px;
          border-top-right-radius: 2px;
        }

        .banner:before {
          display: block;
          content: "";
          width: 100%;
          /* removed .25% from 16:9 ratio to fix YT black bars */
          padding-top: 56%;
          transition: padding-top 0.8s;
        }

        .banner.no-cover {
          background-position: center center;
          background-image: url(/static/images/card_media_player_bg.png);
          background-repeat: no-repeat;
          background-color: var(--primary-color);
        }

        .banner.content-type-music:before {
          padding-top: 100%;
        }

        .banner.no-cover:before {
          padding-top: 88px;
        }

        .banner > .cover {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;

          border-top-left-radius: 2px;
          border-top-right-radius: 2px;

          background-position: center center;
          background-size: cover;
          transition: opacity 0.8s;
          opacity: 1;
        }

        .banner.is-off > .cover {
          opacity: 0;
        }

        .banner > .caption {
          @apply --paper-font-caption;

          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;

          background-color: rgba(0, 0, 0, var(--dark-secondary-opacity));

          padding: 8px 16px;

          font-size: 14px;
          font-weight: 500;
          color: white;

          transition: background-color 0.5s;
        }

        .banner.is-off > .caption {
          background-color: initial;
        }

        .banner > .caption .title {
          @apply --paper-font-common-nowrap;
          font-size: 1.2em;
          margin: 8px 0 4px;
        }

        .progress {
          width: 100%;
          height: var(--paper-progress-height, 4px);
          margin-top: calc(-1 * var(--paper-progress-height, 4px));
          --paper-progress-active-color: var(--accent-color);
          --paper-progress-container-color: rgba(200, 200, 200, 0.5);
        }

        .controls {
          position: relative;
          @apply --paper-font-body1;
          padding: 8px;
          border-bottom-left-radius: 2px;
          border-bottom-right-radius: 2px;
          background-color: var(--paper-card-background-color, white);
        }

        .controls paper-icon-button {
          width: 44px;
          height: 44px;
        }

        paper-icon-button {
          opacity: var(--dark-primary-opacity);
        }

        paper-icon-button[disabled] {
          opacity: var(--dark-disabled-opacity);
        }

        paper-icon-button.primary {
          width: 56px !important;
          height: 56px !important;
          background-color: var(--primary-color);
          color: white;
          border-radius: 50%;
          padding: 8px;
          transition: background-color 0.5s;
        }

        paper-icon-button.primary[disabled] {
          background-color: rgba(0, 0, 0, var(--dark-disabled-opacity));
        }

        [invisible] {
          visibility: hidden !important;
        }
      </style>

      <div
        class$="[[computeBannerClasses(playerObj, _coverShowing, _coverLoadError)]]"
      >
        <div class="cover" id="cover"></div>

        <div class="caption">
          [[_computeStateName(stateObj)]]
          <div class="title">[[computePrimaryText(localize, playerObj)]]</div>
          [[playerObj.secondaryTitle]]<br />
        </div>
      </div>

      <paper-progress
        max="[[stateObj.attributes.media_duration]]"
        value="[[playbackPosition]]"
        hidden$="[[computeHideProgress(playerObj)]]"
        class="progress"
      ></paper-progress>

      <div class="controls layout horizontal justified">
        <paper-icon-button
          icon="hass:power"
          on-click="handleTogglePower"
          invisible$="[[computeHidePowerButton(playerObj)]]"
          class="self-center secondary"
        ></paper-icon-button>

        <div>
          <paper-icon-button
            icon="hass:skip-previous"
            invisible$="[[!playerObj.supportsPreviousTrack]]"
            disabled="[[playerObj.isOff]]"
            on-click="handlePrevious"
          ></paper-icon-button>
          <paper-icon-button
            class="primary"
            icon="[[computePlaybackControlIcon(playerObj)]]"
            invisible$="[[!computePlaybackControlIcon(playerObj)]]"
            disabled="[[playerObj.isOff]]"
            on-click="handlePlaybackControl"
          ></paper-icon-button>
          <paper-icon-button
            icon="hass:skip-next"
            invisible$="[[!playerObj.supportsNextTrack]]"
            disabled="[[playerObj.isOff]]"
            on-click="handleNext"
          ></paper-icon-button>
        </div>

        <paper-icon-button
          icon="hass:dots-vertical"
          on-click="handleOpenMoreInfo"
          class="self-center secondary"
        ></paper-icon-button>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object,playerObj:{type:Object,computed:"computePlayerObj(hass, stateObj)",observer:"playerObjChanged"},playbackControlIcon:{type:String,computed:"computePlaybackControlIcon(playerObj)"},playbackPosition:Number,_coverShowing:{type:Boolean,value:!1},_coverLoadError:{type:Boolean,value:!1}}}async playerObjChanged(playerObj,oldPlayerObj){if(playerObj.isPlaying&&playerObj.showProgress){if(!this._positionTracking){this._positionTracking=setInterval(()=>this.updatePlaybackPosition(),1e3)}}else if(this._positionTracking){clearInterval(this._positionTracking);this._positionTracking=null}if(playerObj.showProgress){this.updatePlaybackPosition()}const picture=playerObj.stateObj.attributes.entity_picture,oldPicture=oldPlayerObj&&oldPlayerObj.stateObj.attributes.entity_picture;if(picture!==oldPicture&&!picture){this.$.cover.style.backgroundImage="";return}if(picture===oldPicture){return}try{const{content_type:contentType,content}=await this.hass.callWS({type:"media_player_thumbnail",entity_id:playerObj.stateObj.entity_id});this._coverShowing=!0;this._coverLoadError=!1;this.$.cover.style.backgroundImage=`url(data:${contentType};base64,${content})`}catch(err){this._coverShowing=!1;this._coverLoadError=!0;this.$.cover.style.backgroundImage=""}}updatePlaybackPosition(){this.playbackPosition=this.playerObj.currentProgress}computeBannerClasses(playerObj,coverShowing,coverLoadError){var cls="banner";if(playerObj.isOff||playerObj.isIdle){cls+=" is-off no-cover"}else if(!playerObj.stateObj.attributes.entity_picture||coverLoadError||!coverShowing){cls+=" no-cover"}else if("music"===playerObj.stateObj.attributes.media_content_type){cls+=" content-type-music"}return cls}computeHideProgress(playerObj){return!playerObj.showProgress}computeHidePowerButton(playerObj){return playerObj.isOff?!playerObj.supportsTurnOn:!playerObj.supportsTurnOff}computePlayerObj(hass,stateObj){return new _util_hass_media_player_model__WEBPACK_IMPORTED_MODULE_6__.a(hass,stateObj)}computePrimaryText(localize,playerObj){return playerObj.primaryTitle||localize(`state.media_player.${playerObj.stateObj.state}`)||localize(`state.default.${playerObj.stateObj.state}`)||playerObj.stateObj.state}computePlaybackControlIcon(playerObj){if(playerObj.isPlaying){return playerObj.supportsPause?"hass:pause":"hass:stop"}if(playerObj.hasMediaControl||playerObj.isOff||playerObj.isIdle){if(playerObj.hasMediaControl&&playerObj.supportsPause&&!playerObj.isPaused){return"hass:play-pause"}return playerObj.supportsPlay?"hass:play":null}return""}_computeStateName(stateObj){return Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_7__.a)(stateObj)}handleNext(ev){ev.stopPropagation();this.playerObj.nextTrack()}handleOpenMoreInfo(ev){ev.stopPropagation();this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}handlePlaybackControl(ev){ev.stopPropagation();this.playerObj.mediaPlayPause()}handlePrevious(ev){ev.stopPropagation();this.playerObj.previousTrack()}handleTogglePower(ev){ev.stopPropagation();this.playerObj.togglePower()}}customElements.define("ha-media_player-card",HaMediaPlayerCard)},285:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(20),_components_ha_card__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(180),_components_ha_icon__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(164),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(159),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(81);class HaPlantCard extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        .banner {
          display: flex;
          align-items: flex-end;
          background-repeat: no-repeat;
          background-size: cover;
          background-position: center;
          padding-top: 12px;
        }
        .has-plant-image .banner {
          padding-top: 30%;
        }
        .header {
          @apply --paper-font-headline;
          line-height: 40px;
          padding: 8px 16px;
        }
        .has-plant-image .header {
          font-size: 16px;
          font-weight: 500;
          line-height: 16px;
          padding: 16px;
          color: white;
          width: 100%;
          background: rgba(0, 0, 0, var(--dark-secondary-opacity));
        }
        .content {
          display: flex;
          justify-content: space-between;
          padding: 16px 32px 24px 32px;
        }
        .has-plant-image .content {
          padding-bottom: 16px;
        }
        ha-icon {
          color: var(--paper-item-icon-color);
          margin-bottom: 8px;
        }
        .attributes {
          cursor: pointer;
        }
        .attributes div {
          text-align: center;
        }
        .problem {
          color: var(--google-red-500);
          font-weight: bold;
        }
        .uom {
          color: var(--secondary-text-color);
        }
      </style>

      <ha-card
        class$="[[computeImageClass(stateObj.attributes.entity_picture)]]"
      >
        <div
          class="banner"
          style="background-image:url([[stateObj.attributes.entity_picture]])"
        >
          <div class="header">[[computeTitle(stateObj)]]</div>
        </div>
        <div class="content">
          <template
            is="dom-repeat"
            items="[[computeAttributes(stateObj.attributes)]]"
          >
            <div class="attributes" on-click="attributeClicked">
              <div>
                <ha-icon
                  icon="[[computeIcon(item, stateObj.attributes.battery)]]"
                ></ha-icon>
              </div>
              <div
                class$="[[computeAttributeClass(stateObj.attributes.problem, item)]]"
              >
                [[computeValue(stateObj.attributes, item)]]
              </div>
              <div class="uom">
                [[computeUom(stateObj.attributes.unit_of_measurement_dict,
                item)]]
              </div>
            </div>
          </template>
        </div>
      </ha-card>
    `}static get properties(){return{hass:Object,stateObj:Object,config:Object}}constructor(){super();this.sensors={moisture:"hass:water",temperature:"hass:thermometer",brightness:"hass:white-balance-sunny",conductivity:"hass:emoticon-poop",battery:"hass:battery"}}computeTitle(stateObj){return this.config&&this.config.name||Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_4__.a)(stateObj)}computeAttributes(data){return Object.keys(this.sensors).filter(key=>key in data)}computeIcon(attr,batLvl){const icon=this.sensors[attr];if("battery"===attr){if(5>=batLvl){return`${icon}-alert`}if(95>batLvl){return`${icon}-${10*Math.round(batLvl/10-.01)}`}}return icon}computeValue(attributes,attr){return attributes[attr]}computeUom(dict,attr){return dict[attr]||""}computeAttributeClass(problem,attr){return-1===problem.indexOf(attr)?"":"problem"}computeImageClass(entityPicture){return entityPicture?"has-plant-image":""}attributeClicked(ev){this.fire("hass-more-info",{entityId:this.stateObj.attributes.sensors[ev.model.item]})}}customElements.define("ha-plant-card",HaPlantCard)},286:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(20),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(159),_components_ha_card__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(180),_components_ha_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(164),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(81),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(107),_common_util_compute_rtl__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(83);class HaWeatherCard extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_6__.a)(Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a)){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          cursor: pointer;
        }

        .content {
          padding: 0 20px 20px;
        }

        ha-icon {
          color: var(--paper-item-icon-color);
        }

        .header {
          font-family: var(--paper-font-headline_-_font-family);
          -webkit-font-smoothing: var(
            --paper-font-headline_-_-webkit-font-smoothing
          );
          font-size: var(--paper-font-headline_-_font-size);
          font-weight: var(--paper-font-headline_-_font-weight);
          letter-spacing: var(--paper-font-headline_-_letter-spacing);
          line-height: var(--paper-font-headline_-_line-height);
          text-rendering: var(
            --paper-font-common-expensive-kerning_-_text-rendering
          );
          opacity: var(--dark-primary-opacity);
          padding: 24px 16px 16px;
          display: flex;
          align-items: baseline;
        }

        .name {
          margin-left: 16px;
          font-size: 16px;
          color: var(--secondary-text-color);
        }

        :host([rtl]) .name {
          margin-left: 0px;
          margin-right: 16px;
        }

        .now {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
        }

        .main {
          display: flex;
          align-items: center;
          margin-right: 32px;
        }

        :host([rtl]) .main {
          margin-right: 0px;
        }

        .main ha-icon {
          --iron-icon-height: 72px;
          --iron-icon-width: 72px;
          margin-right: 8px;
        }

        :host([rtl]) .main ha-icon {
          margin-right: 0px;
        }

        .main .temp {
          font-size: 52px;
          line-height: 1em;
          position: relative;
        }

        :host([rtl]) .main .temp {
          direction: ltr;
          margin-right: 28px;
        }

        .main .temp span {
          font-size: 24px;
          line-height: 1em;
          position: absolute;
          top: 4px;
        }

        .measurand {
          display: inline-block;
        }

        :host([rtl]) .measurand {
          direction: ltr;
        }

        .forecast {
          margin-top: 16px;
          display: flex;
          justify-content: space-between;
        }

        .forecast div {
          flex: 0 0 auto;
          text-align: center;
        }

        .forecast .icon {
          margin: 4px 0;
          text-align: center;
        }

        :host([rtl]) .forecast .temp {
          direction: ltr;
        }

        .weekday {
          font-weight: bold;
        }

        .attributes,
        .templow,
        .precipitation {
          color: var(--secondary-text-color);
        }

        :host([rtl]) .precipitation {
          direction: ltr;
        }
      </style>
      <ha-card>
        <div class="header">
          [[computeState(stateObj.state, localize)]]
          <div class="name">[[computeName(stateObj)]]</div>
        </div>
        <div class="content">
          <div class="now">
            <div class="main">
              <template is="dom-if" if="[[showWeatherIcon(stateObj.state)]]">
                <ha-icon icon="[[getWeatherIcon(stateObj.state)]]"></ha-icon>
              </template>
              <div class="temp">
                [[stateObj.attributes.temperature]]<span
                  >[[getUnit('temperature')]]</span
                >
              </div>
            </div>
            <div class="attributes">
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.pressure)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.air_pressure')]]:
                  <span class="measurand">
                    [[stateObj.attributes.pressure]] [[getUnit('air_pressure')]]
                  </span>
                </div>
              </template>
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.humidity)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.humidity')]]:
                  <span class="measurand"
                    >[[stateObj.attributes.humidity]] %</span
                  >
                </div>
              </template>
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.wind_speed)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.wind_speed')]]:
                  <span class="measurand">
                    [[getWindSpeed(stateObj.attributes.wind_speed)]]
                  </span>
                  [[getWindBearing(stateObj.attributes.wind_bearing, localize)]]
                </div>
              </template>
            </div>
          </div>
          <template is="dom-if" if="[[forecast]]">
            <div class="forecast">
              <template is="dom-repeat" items="[[forecast]]">
                <div>
                  <div class="weekday">
                    [[computeDate(item.datetime)]]<br />
                    <template is="dom-if" if="[[!_showValue(item.templow)]]">
                      [[computeTime(item.datetime)]]
                    </template>
                  </div>
                  <template is="dom-if" if="[[_showValue(item.condition)]]">
                    <div class="icon">
                      <ha-icon
                        icon="[[getWeatherIcon(item.condition)]]"
                      ></ha-icon>
                    </div>
                  </template>
                  <div class="temp">
                    [[item.temperature]] [[getUnit('temperature')]]
                  </div>
                  <template is="dom-if" if="[[_showValue(item.templow)]]">
                    <div class="templow">
                      [[item.templow]] [[getUnit('temperature')]]
                    </div>
                  </template>
                  <template is="dom-if" if="[[_showValue(item.precipitation)]]">
                    <div class="precipitation">
                      [[item.precipitation]] [[getUnit('precipitation')]]
                    </div>
                  </template>
                </div>
              </template>
            </div>
          </template>
        </div>
      </ha-card>
    `}static get properties(){return{hass:Object,config:Object,stateObj:Object,forecast:{type:Array,computed:"computeForecast(stateObj.attributes.forecast)"},rtl:{type:Boolean,reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}constructor(){super();this.cardinalDirections=["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"];this.weatherIcons={"clear-night":"hass:weather-night",cloudy:"hass:weather-cloudy",fog:"hass:weather-fog",hail:"hass:weather-hail",lightning:"hass:weather-lightning","lightning-rainy":"hass:weather-lightning-rainy",partlycloudy:"hass:weather-partlycloudy",pouring:"hass:weather-pouring",rainy:"hass:weather-rainy",snowy:"hass:weather-snowy","snowy-rainy":"hass:weather-snowy-rainy",sunny:"hass:weather-sunny",windy:"hass:weather-windy","windy-variant":"hass:weather-windy-variant"}}ready(){this.addEventListener("click",this._onClick);super.ready()}_onClick(){this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}computeForecast(forecast){return forecast&&forecast.slice(0,5)}getUnit(measure){const lengthUnit=this.hass.config.unit_system.length||"";switch(measure){case"air_pressure":return"km"===lengthUnit?"hPa":"inHg";case"length":return lengthUnit;case"precipitation":return"km"===lengthUnit?"mm":"in";default:return this.hass.config.unit_system[measure]||"";}}computeState(state,localize){return localize(`state.weather.${state}`)||state}computeName(stateObj){return this.config&&this.config.name||Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_2__.a)(stateObj)}showWeatherIcon(condition){return condition in this.weatherIcons}getWeatherIcon(condition){return this.weatherIcons[condition]}windBearingToText(degree){const degreenum=parseInt(degree);if(isFinite(degreenum)){return this.cardinalDirections[(0|(degreenum+11.25)/22.5)%16]}return degree}getWindSpeed(speed){return`${speed} ${this.getUnit("length")}/h`}getWindBearing(bearing,localize){if(null!=bearing){const cardinalDirection=this.windBearingToText(bearing);return`(${localize(`ui.card.weather.cardinal_direction.${cardinalDirection.toLowerCase()}`)||cardinalDirection})`}return``}_showValue(item){return"undefined"!==typeof item&&null!==item}computeDate(data){const date=new Date(data);return date.toLocaleDateString(this.hass.language,{weekday:"short"})}computeTime(data){const date=new Date(data);return date.toLocaleTimeString(this.hass.language,{hour:"numeric"})}_computeRTL(hass){return Object(_common_util_compute_rtl__WEBPACK_IMPORTED_MODULE_7__.a)(hass)}}customElements.define("ha-weather-card",HaWeatherCard)},287:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return extractViews});var _const__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(109);function extractViews(entities){const views=[];Object.keys(entities).forEach(entityId=>{const entity=entities[entityId];if(entity.attributes.view){views.push(entity)}});views.sort((view1,view2)=>{if(view1.entity_id===_const__WEBPACK_IMPORTED_MODULE_0__.c){return-1}if(view2.entity_id===_const__WEBPACK_IMPORTED_MODULE_0__.c){return 1}return view1.attributes.order-view2.attributes.order});return views}},288:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return getViewEntities});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(166),_get_group_entities__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(263);function getViewEntities(entities,view){const viewEntities={};view.attributes.entity_id.forEach(entityId=>{const entity=entities[entityId];if(entity&&!entity.attributes.hidden){viewEntities[entity.entity_id]=entity;if("group"===Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(entity.entity_id)){const groupEntities=Object(_get_group_entities__WEBPACK_IMPORTED_MODULE_1__.a)(entities,entity);Object.keys(groupEntities).forEach(grEntityId=>{const grEntity=groupEntities[grEntityId];if(!grEntity.attributes.hidden){viewEntities[grEntityId]=grEntity}})}}});return viewEntities}},289:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return splitByGroups});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(166);function splitByGroups(entities){const groups=[],ungrouped={};Object.keys(entities).forEach(entityId=>{const entity=entities[entityId];if("group"===Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(entityId)){groups.push(entity)}else{ungrouped[entityId]=entity}});groups.forEach(group=>group.attributes.entity_id.forEach(entityId=>{delete ungrouped[entityId]}));return{groups,ungrouped}}},290:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return stateMoreInfoType});var _compute_state_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(162),_const__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(109);function stateMoreInfoType(stateObj){const domain=Object(_compute_state_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj);if(_const__WEBPACK_IMPORTED_MODULE_1__.h.includes(domain)){return domain}if(_const__WEBPACK_IMPORTED_MODULE_1__.d.includes(domain)){return"hidden"}return"default"}},291:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_card_paper_card__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(160),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(3),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(20),_components_state_history_charts__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(239),_data_ha_state_history_data__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(241),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(159),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(81);class HaHistoryGraphCard extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_6__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        paper-card:not([dialog]) .content {
          padding: 0 16px 16px;
        }
        paper-card[dialog] {
          padding-top: 16px;
          background-color: transparent;
        }
        paper-card {
          width: 100%;
          /* prevent new stacking context, chart tooltip needs to overflow */
          position: static;
        }
        .header {
          @apply --paper-font-headline;
          line-height: 40px;
          color: var(--primary-text-color);
          padding: 20px 16px 12px;
          @apply --paper-font-common-nowrap;
        }
        paper-card[dialog] .header {
          display: none;
        }
      </style>
      <ha-state-history-data
        hass="[[hass]]"
        filter-type="recent-entity"
        entity-id="[[computeHistoryEntities(stateObj)]]"
        data="{{stateHistory}}"
        is-loading="{{stateHistoryLoading}}"
        cache-config="[[cacheConfig]]"
      ></ha-state-history-data>
      <paper-card
        dialog$="[[inDialog]]"
        on-click="cardTapped"
        elevation="[[computeElevation(inDialog)]]"
      >
        <div class="header">[[computeTitle(stateObj)]]</div>
        <div class="content">
          <state-history-charts
            hass="[[hass]]"
            history-data="[[stateHistory]]"
            is-loading-data="[[stateHistoryLoading]]"
            up-to-now
            no-single
          >
          </state-history-charts>
        </div>
      </paper-card>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjObserver"},inDialog:{type:Boolean,value:!1},stateHistory:Object,stateHistoryLoading:Boolean,cacheConfig:{type:Object,value:{refresh:0,cacheKey:null,hoursToShow:24}}}}stateObjObserver(stateObj){if(!stateObj)return;if(this.cacheConfig.cacheKey!==stateObj.entity_id||this.cacheConfig.refresh!==(stateObj.attributes.refresh||0)||this.cacheConfig.hoursToShow!==(stateObj.attributes.hours_to_show||24)){this.cacheConfig=Object.assign({},{refresh:stateObj.attributes.refresh||0,cacheKey:stateObj.entity_id,hoursToShow:stateObj.attributes.hours_to_show||24})}}computeTitle(stateObj){return Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_5__.a)(stateObj)}computeContentClass(inDialog){return inDialog?"":"content"}computeHistoryEntities(stateObj){return stateObj.attributes.entity_id}computeElevation(inDialog){return inDialog?0:1}cardTapped(ev){const mq=window.matchMedia("(min-width: 610px) and (min-height: 550px)");if(mq.matches){ev.stopPropagation();this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}}}customElements.define("ha-history_graph-card",HaHistoryGraphCard)},460:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);var html_tag=__webpack_require__(3),polymer_element=__webpack_require__(20),app_header=__webpack_require__(134),waterfall=__webpack_require__(281),app_toolbar=__webpack_require__(111),app_route=__webpack_require__(142),iron_flex_layout_classes=__webpack_require__(161),polymer_legacy=__webpack_require__(2),iron_resizable_behavior=__webpack_require__(85),iron_selectable=__webpack_require__(76),polymer_fn=__webpack_require__(4);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        display: block;
      }

      :host > ::slotted(:not(slot):not(.iron-selected)) {
        display: none !important;
      }
    </style>

    <slot></slot>
`,is:"iron-pages",behaviors:[iron_resizable_behavior.a,iron_selectable.a],properties:{activateEvent:{type:String,value:null}},observers:["_selectedPageChanged(selected)"],_selectedPageChanged:function(selected,old){this.async(this.notifyResize)}});var paper_tab=__webpack_require__(224),paper_tabs=__webpack_require__(255),utils_async=__webpack_require__(11),debounce=__webpack_require__(19),ha_state_label_badge=__webpack_require__(259);class ha_badges_card_HaBadgesCard extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        ha-state-label-badge {
          display: inline-block;
          margin-bottom: var(--ha-state-label-badge-margin-bottom, 16px);
        }
      </style>
      <template is="dom-repeat" items="[[states]]">
        <ha-state-label-badge
          hass="[[hass]]"
          state="[[item]]"
        ></ha-state-label-badge>
      </template>
    `}static get properties(){return{hass:Object,states:Array}}}customElements.define("ha-badges-card",ha_badges_card_HaBadgesCard);var paper_material_styles=__webpack_require__(168),compute_state_name=__webpack_require__(159),events_mixin=__webpack_require__(81),localize_mixin=__webpack_require__(107);const UPDATE_INTERVAL=1e4;class ha_camera_card_HaCameraCard extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="paper-material-styles">
        :host {
          @apply --paper-material-elevation-1;
          display: block;
          position: relative;
          font-size: 0px;
          border-radius: 2px;
          cursor: pointer;
          min-height: 48px;
          line-height: 0;
        }
        .camera-feed {
          width: 100%;
          height: auto;
          border-radius: 2px;
        }
        .caption {
          @apply --paper-font-common-nowrap;
          position: absolute;
          left: 0px;
          right: 0px;
          bottom: 0px;
          border-bottom-left-radius: 2px;
          border-bottom-right-radius: 2px;

          background-color: rgba(0, 0, 0, 0.3);
          padding: 16px;

          font-size: 16px;
          font-weight: 500;
          line-height: 16px;
          color: white;
        }
      </style>

      <template is="dom-if" if="[[cameraFeedSrc]]">
        <img
          src="[[cameraFeedSrc]]"
          class="camera-feed"
          alt="[[_computeStateName(stateObj)]]"
        />
      </template>
      <div class="caption">
        [[_computeStateName(stateObj)]]
        <template is="dom-if" if="[[!imageLoaded]]">
          ([[localize('ui.card.camera.not_available')]])
        </template>
      </div>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"updateCameraFeedSrc"},cameraFeedSrc:{type:String,value:""},imageLoaded:{type:Boolean,value:!0}}}ready(){super.ready();this.addEventListener("click",()=>this.cardTapped())}connectedCallback(){super.connectedCallback();this.timer=setInterval(()=>this.updateCameraFeedSrc(),UPDATE_INTERVAL)}disconnectedCallback(){super.disconnectedCallback();clearInterval(this.timer)}cardTapped(){this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}async updateCameraFeedSrc(){try{const{content_type:contentType,content}=await this.hass.callWS({type:"camera_thumbnail",entity_id:this.stateObj.entity_id});this.setProperties({imageLoaded:!0,cameraFeedSrc:`data:${contentType};base64, ${content}`})}catch(err){this.imageLoaded=!1}}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}}customElements.define("ha-camera-card",ha_camera_card_HaCameraCard);var ha_entity_toggle=__webpack_require__(215),ha_card=__webpack_require__(180),state_card_content=__webpack_require__(280),compute_state_domain=__webpack_require__(162),state_more_info_type=__webpack_require__(290),can_toggle_state=__webpack_require__(269);class ha_entities_card_HaEntitiesCard extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        ha-card {
          padding: 16px;
        }
        .states {
          margin: -4px 0;
        }
        .state {
          padding: 4px 0;
        }
        .header {
          @apply --paper-font-headline;
          /* overwriting line-height +8 because entity-toggle can be 40px height,
           compensating this with reduced padding */
          line-height: 40px;
          color: var(--primary-text-color);
          padding: 4px 0 12px;
        }
        .header .name {
          @apply --paper-font-common-nowrap;
        }
        ha-entity-toggle {
          margin-left: 16px;
        }
        .more-info {
          cursor: pointer;
        }
      </style>

      <ha-card>
        <template is="dom-if" if="[[title]]">
          <div
            class$="[[computeTitleClass(groupEntity)]]"
            on-click="entityTapped"
          >
            <div class="flex name">[[title]]</div>
            <template is="dom-if" if="[[showGroupToggle(groupEntity, states)]]">
              <ha-entity-toggle
                hass="[[hass]]"
                state-obj="[[groupEntity]]"
              ></ha-entity-toggle>
            </template>
          </div>
        </template>
        <div class="states">
          <template
            is="dom-repeat"
            items="[[states]]"
            on-dom-change="addTapEvents"
          >
            <div class$="[[computeStateClass(item)]]">
              <state-card-content
                hass="[[hass]]"
                class="state-card"
                state-obj="[[item]]"
              ></state-card-content>
            </div>
          </template>
        </div>
      </ha-card>
    `}static get properties(){return{hass:Object,states:Array,groupEntity:Object,title:{type:String,computed:"computeTitle(states, groupEntity, localize)"}}}constructor(){super();this.entityTapped=this.entityTapped.bind(this)}computeTitle(states,groupEntity,localize){if(groupEntity){return Object(compute_state_name.a)(groupEntity).trim()}const domain=Object(compute_state_domain.a)(states[0]);return localize&&localize(`domain.${domain}`)||domain.replace(/_/g," ")}computeTitleClass(groupEntity){let classes="header horizontal layout center ";if(groupEntity){classes+="more-info"}return classes}computeStateClass(stateObj){return"hidden"!==Object(state_more_info_type.a)(stateObj)?"state more-info":"state"}addTapEvents(){const cards=this.root.querySelectorAll(".state");cards.forEach(card=>{if(card.classList.contains("more-info")){card.addEventListener("click",this.entityTapped)}else{card.removeEventListener("click",this.entityTapped)}})}entityTapped(ev){const item=this.root.querySelector("dom-repeat").itemForElement(ev.target);let entityId;if(!item&&!this.groupEntity){return}ev.stopPropagation();if(item){entityId=item.entity_id}else{entityId=this.groupEntity.entity_id}this.fire("hass-more-info",{entityId:entityId})}showGroupToggle(groupEntity,states){if(!groupEntity||!states||"hidden"===groupEntity.attributes.control||"on"!==groupEntity.state&&"off"!==groupEntity.state){return!1}let canToggleCount=0;for(let i=0;i<states.length;i++){if(!Object(can_toggle_state.a)(this.hass,states[i])){continue}canToggleCount++;if(1<canToggleCount){break}}return 1<canToggleCount}}customElements.define("ha-entities-card",ha_entities_card_HaEntitiesCard);var ha_history_graph_card=__webpack_require__(291),ha_media_player_card=__webpack_require__(284),mwc_button=__webpack_require__(73),ha_markdown=__webpack_require__(225),compute_object_id=__webpack_require__(177);class ha_persistent_notification_card_HaPersistentNotificationCard extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          @apply --paper-font-body1;
        }
        ha-markdown {
          display: block;
          padding: 0 16px;
          -ms-user-select: initial;
          -webkit-user-select: initial;
          -moz-user-select: initial;
        }
        ha-markdown p:first-child {
          margin-top: 0;
        }
        ha-markdown p:last-child {
          margin-bottom: 0;
        }
        ha-markdown a {
          color: var(--primary-color);
        }
        ha-markdown img {
          max-width: 100%;
        }
        mwc-button {
          margin: 8px;
        }
      </style>

      <ha-card header="[[computeTitle(stateObj)]]">
        <ha-markdown content="[[stateObj.attributes.message]]"></ha-markdown>
        <mwc-button on-click="dismissTap"
          >[[localize('ui.card.persistent_notification.dismiss')]]</mwc-button
        >
      </ha-card>
    `}static get properties(){return{hass:Object,stateObj:Object}}computeTitle(stateObj){return stateObj.attributes.title||Object(compute_state_name.a)(stateObj)}dismissTap(ev){ev.preventDefault();this.hass.callService("persistent_notification","dismiss",{notification_id:Object(compute_object_id.a)(this.stateObj.entity_id)})}}customElements.define("ha-persistent_notification-card",ha_persistent_notification_card_HaPersistentNotificationCard);var ha_plant_card=__webpack_require__(285),ha_weather_card=__webpack_require__(286),dynamic_content_updater=__webpack_require__(242);class ha_card_chooser_HaCardChooser extends polymer_element.a{static get properties(){return{cardData:{type:Object,observer:"cardDataChanged"}}}_updateCard(newData){Object(dynamic_content_updater.a)(this,"HA-"+newData.cardType.toUpperCase()+"-CARD",newData)}createObserver(){this._updatesAllowed=!1;this.observer=new IntersectionObserver(entries=>{if(!entries.length)return;if(entries[0].isIntersecting){this.style.height="";if(this._detachedChild){this.appendChild(this._detachedChild);this._detachedChild=null}this._updateCard(this.cardData);this._updatesAllowed=!0}else{const offsetHeight=this.offsetHeight;this.style.height=`${offsetHeight||48}px`;if(this.lastChild){this._detachedChild=this.lastChild;this.removeChild(this.lastChild)}this._updatesAllowed=!1}});this.observer.observe(this)}cardDataChanged(newData){if(!newData)return;const eligibleToObserver=window.IntersectionObserver&&"entities"!==newData.cardType;if(!eligibleToObserver){if(this.observer){this.observer.unobserve(this);this.observer=null}this.style.height="";this._updateCard(newData);return}if(!this.observer){this.createObserver()}if(this._updatesAllowed){this._updateCard(newData)}}}customElements.define("ha-card-chooser",ha_card_chooser_HaCardChooser);var ha_label_badge=__webpack_require__(248);class ha_demo_badge_HaDemoBadge extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          --ha-label-badge-color: #dac90d;
        }
      </style>

      <ha-label-badge
        icon="hass:emoticon"
        label="Demo"
        description=""
      ></ha-label-badge>
    `}}customElements.define("ha-demo-badge",ha_demo_badge_HaDemoBadge);var split_by_groups=__webpack_require__(289),get_group_entities=__webpack_require__(263);const DOMAINS_WITH_CARD={camera:4,history_graph:4,media_player:3,persistent_notification:0,plant:3,weather:4},PRIORITY={configurator:-20,persistent_notification:-15,updater:0,sun:1,person:2,device_tracker:3,alarm_control_panel:4,timer:5,sensor:6,binary_sensor:7,mailbox:8},getPriority=domain=>domain in PRIORITY?PRIORITY[domain]:100,sortPriority=(domainA,domainB)=>domainA.priority-domainB.priority,entitySortBy=(entityA,entityB)=>{const nameA=(entityA.attributes.friendly_name||entityA.entity_id).toLowerCase(),nameB=(entityB.attributes.friendly_name||entityB.entity_id).toLowerCase();if(nameA<nameB){return-1}if(nameA>nameB){return 1}return 0},iterateDomainSorted=(collection,func)=>{Object.keys(collection).map(key=>collection[key]).sort(sortPriority).forEach(domain=>{domain.states.sort(entitySortBy);func(domain)})};class ha_cards_HaCards extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-factors"></style>
      <style>
        :host {
          display: block;
          padding: 4px 4px 0;
          transform: translateZ(0);
          position: relative;
        }

        .badges {
          font-size: 85%;
          text-align: center;
          padding-top: 16px;
        }

        .column {
          max-width: 500px;
          overflow-x: hidden;
        }

        ha-card-chooser {
          display: block;
          margin: 4px 4px 8px;
        }

        @media (max-width: 500px) {
          :host {
            padding-left: 0;
            padding-right: 0;
          }

          ha-card-chooser {
            margin-left: 0;
            margin-right: 0;
          }
        }

        @media (max-width: 599px) {
          .column {
            max-width: 600px;
          }
        }
      </style>

      <div id="main">
        <template is="dom-if" if="[[cards.badges.length]]">
          <div class="badges">
            <template is="dom-if" if="[[cards.demo]]">
              <ha-demo-badge></ha-demo-badge>
            </template>

            <ha-badges-card
              states="[[cards.badges]]"
              hass="[[hass]]"
            ></ha-badges-card>
          </div>
        </template>

        <div class="horizontal layout center-justified">
          <template is="dom-repeat" items="[[cards.columns]]" as="column">
            <div class="column flex-1">
              <template is="dom-repeat" items="[[column]]" as="card">
                <ha-card-chooser card-data="[[card]]"></ha-card-chooser>
              </template>
            </div>
          </template>
        </div>
      </div>
    `}static get properties(){return{hass:Object,columns:{type:Number,value:2},states:Object,viewVisible:{type:Boolean,value:!1},orderedGroupEntities:Array,cards:Object}}static get observers(){return["updateCards(columns, states, viewVisible, orderedGroupEntities)"]}updateCards(columns,states,viewVisible,orderedGroupEntities){if(!viewVisible){if(this.$.main.parentNode){this.$.main._parentNode=this.$.main.parentNode;this.$.main.parentNode.removeChild(this.$.main)}return}if(!this.$.main.parentNode&&this.$.main._parentNode){this.$.main._parentNode.appendChild(this.$.main)}this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(10),()=>{if(this.viewVisible){this.cards=this.computeCards(columns,states,orderedGroupEntities)}})}emptyCards(){return{demo:!1,badges:[],columns:[]}}computeCards(columns,states,orderedGroupEntities){const hass=this.hass,cards=this.emptyCards(),entityCount=[];for(let i=0;i<columns;i++){cards.columns.push([]);entityCount.push(0)}function getIndex(size){let minIndex=0;for(let i=0;i<entityCount.length;i++){if(5>entityCount[i]){minIndex=i;break}if(entityCount[i]<entityCount[minIndex]){minIndex=i}}entityCount[minIndex]+=size;return minIndex}function addEntitiesCard(name,entities,groupEntity){if(0===entities.length)return;const owncard=[],other=[];let size=0;entities.forEach(entity=>{const domain=Object(compute_state_domain.a)(entity);if(domain in DOMAINS_WITH_CARD&&!entity.attributes.custom_ui_state_card){owncard.push(entity);size+=DOMAINS_WITH_CARD[domain]}else{other.push(entity);size++}});size+=0<other.length;const curIndex=getIndex(size);if(0<other.length){cards.columns[curIndex].push({hass:hass,cardType:"entities",states:other,groupEntity:groupEntity||!1})}owncard.forEach(entity=>{cards.columns[curIndex].push({hass:hass,cardType:Object(compute_state_domain.a)(entity),stateObj:entity})})}const splitted=Object(split_by_groups.a)(states);if(orderedGroupEntities){splitted.groups.sort((gr1,gr2)=>orderedGroupEntities[gr1.entity_id]-orderedGroupEntities[gr2.entity_id])}else{splitted.groups.sort((gr1,gr2)=>gr1.attributes.order-gr2.attributes.order)}const badgesColl={},beforeGroupColl={},afterGroupedColl={};Object.keys(splitted.ungrouped).forEach(key=>{const state=splitted.ungrouped[key],domain=Object(compute_state_domain.a)(state);if("a"===domain){cards.demo=!0;return}const priority=getPriority(domain);let coll;if(0>priority){coll=beforeGroupColl}else if(10>priority){coll=badgesColl}else{coll=afterGroupedColl}if(!(domain in coll)){coll[domain]={domain:domain,priority:priority,states:[]}}coll[domain].states.push(state)});if(orderedGroupEntities){Object.keys(badgesColl).map(key=>badgesColl[key]).forEach(domain=>{cards.badges.push.apply(cards.badges,domain.states)});cards.badges.sort((e1,e2)=>orderedGroupEntities[e1.entity_id]-orderedGroupEntities[e2.entity_id])}else{iterateDomainSorted(badgesColl,domain=>{cards.badges.push.apply(cards.badges,domain.states)})}iterateDomainSorted(beforeGroupColl,domain=>{addEntitiesCard(domain.domain,domain.states)});splitted.groups.forEach(groupState=>{const entities=Object(get_group_entities.a)(states,groupState);addEntitiesCard(groupState.entity_id,Object.keys(entities).map(key=>entities[key]),groupState)});iterateDomainSorted(afterGroupedColl,domain=>{addEntitiesCard(domain.domain,domain.states)});cards.columns=cards.columns.filter(val=>0<val.length);return cards}}customElements.define("ha-cards",ha_cards_HaCards);var ha_icon=__webpack_require__(164),ha_menu_button=__webpack_require__(136),ha_start_voice_button=__webpack_require__(258),ha_app_layout=__webpack_require__(213),extract_views=__webpack_require__(287),get_view_entities=__webpack_require__(288);function computeLocationName(hass){return hass&&hass.config.location_name}var navigate_mixin=__webpack_require__(202);const DEFAULT_VIEW_ENTITY_ID="group.default_view",ALWAYS_SHOW_DOMAIN=["persistent_notification","configurator"];class ha_panel_states_PartialCards extends Object(events_mixin.a)(Object(navigate_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex iron-positioning ha-style">
        :host {
          -ms-user-select: none;
          -webkit-user-select: none;
          -moz-user-select: none;
        }

        ha-app-layout {
          min-height: 100%;
          background-color: var(--secondary-background-color, #e5e5e5);
        }

        iron-pages {
          height: 100%;
        }

        paper-tabs {
          margin-left: 12px;
          --paper-tabs-selection-bar-color: var(--text-primary-color, #fff);
          text-transform: uppercase;
        }
      </style>
      <app-route
        route="{{route}}"
        pattern="/:view"
        data="{{routeData}}"
        active="{{routeMatch}}"
      ></app-route>
      <ha-app-layout id="layout">
        <app-header effects="waterfall" condenses="" fixed="" slot="header">
          <app-toolbar>
            <ha-menu-button
              narrow="[[narrow]]"
              show-menu="[[showMenu]]"
            ></ha-menu-button>
            <div main-title="">
              [[computeTitle(views, defaultView, locationName)]]
            </div>
            <ha-start-voice-button hass="[[hass]]"></ha-start-voice-button>
          </app-toolbar>

          <div sticky="" hidden$="[[areTabsHidden(views, showTabs)]]">
            <paper-tabs
              scrollable=""
              selected="[[currentView]]"
              attr-for-selected="data-entity"
              on-iron-activate="handleViewSelected"
            >
              <paper-tab data-entity="" on-click="scrollToTop">
                <template is="dom-if" if="[[!defaultView]]">
                  Home
                </template>
                <template is="dom-if" if="[[defaultView]]">
                  <template is="dom-if" if="[[defaultView.attributes.icon]]">
                    <ha-icon
                      title$="[[_computeStateName(defaultView)]]"
                      icon="[[defaultView.attributes.icon]]"
                    ></ha-icon>
                  </template>
                  <template is="dom-if" if="[[!defaultView.attributes.icon]]">
                    [[_computeStateName(defaultView)]]
                  </template>
                </template>
              </paper-tab>
              <template is="dom-repeat" items="[[views]]">
                <paper-tab
                  data-entity$="[[item.entity_id]]"
                  on-click="scrollToTop"
                >
                  <template is="dom-if" if="[[item.attributes.icon]]">
                    <ha-icon
                      title$="[[_computeStateName(item)]]"
                      icon="[[item.attributes.icon]]"
                    ></ha-icon>
                  </template>
                  <template is="dom-if" if="[[!item.attributes.icon]]">
                    [[_computeStateName(item)]]
                  </template>
                </paper-tab>
              </template>
            </paper-tabs>
          </div>
        </app-header>

        <iron-pages
          attr-for-selected="data-view"
          selected="[[currentView]]"
          selected-attribute="view-visible"
        >
          <ha-cards
            data-view=""
            states="[[viewStates]]"
            columns="[[_columns]]"
            hass="[[hass]]"
            panel-visible="[[panelVisible]]"
            ordered-group-entities="[[orderedGroupEntities]]"
          ></ha-cards>

          <template is="dom-repeat" items="[[views]]">
            <ha-cards
              data-view$="[[item.entity_id]]"
              states="[[viewStates]]"
              columns="[[_columns]]"
              hass="[[hass]]"
              panel-visible="[[panelVisible]]"
              ordered-group-entities="[[orderedGroupEntities]]"
            ></ha-cards>
          </template>
        </iron-pages>
      </ha-app-layout>
    `}static get properties(){return{hass:{type:Object,value:null,observer:"hassChanged"},narrow:{type:Boolean,value:!1},showMenu:{type:Boolean},panelVisible:{type:Boolean,value:!1},route:Object,routeData:Object,routeMatch:Boolean,_columns:{type:Number,value:1},locationName:{type:String,value:"",computed:"_computeLocationName(hass)"},currentView:{type:String,computed:"_computeCurrentView(hass, routeMatch, routeData)"},views:{type:Array},defaultView:{type:Object},viewStates:{type:Object,computed:"computeViewStates(currentView, hass, defaultView)"},orderedGroupEntities:{type:Array,computed:"computeOrderedGroupEntities(currentView, hass, defaultView)"},showTabs:{type:Boolean,value:!0}}}static get observers(){return["_updateColumns(narrow, showMenu)"]}ready(){this._updateColumns=this._updateColumns.bind(this);this.mqls=[300,600,900,1200].map(width=>matchMedia(`(min-width: ${width}px)`));super.ready()}connectedCallback(){super.connectedCallback();this.mqls.forEach(mql=>mql.addListener(this._updateColumns))}disconnectedCallback(){super.disconnectedCallback();this.mqls.forEach(mql=>mql.removeListener(this._updateColumns))}_updateColumns(){const matchColumns=this.mqls.reduce((cols,mql)=>cols+mql.matches,0);this._columns=Math.max(1,matchColumns-(!this.narrow&&this.showMenu))}areTabsHidden(views,showTabs){return!views||!views.length||!showTabs}scrollToTop(){var top=0,scroller=this.$.layout.header.scrollTarget,easingFn=function easeOutQuad(t,b,c,d){t/=d;return-c*t*(t-2)+b},animationId=Math.random(),duration=200,startTime=Date.now(),currentScrollTop=scroller.scrollTop,deltaScrollTop=top-currentScrollTop;this._currentAnimationId=animationId;(function updateFrame(){var now=Date.now(),elapsedTime=now-startTime;if(elapsedTime>duration){scroller.scrollTop=top}else if(this._currentAnimationId===animationId){scroller.scrollTop=easingFn(elapsedTime,currentScrollTop,deltaScrollTop,duration);requestAnimationFrame(updateFrame.bind(this))}}).call(this)}handleViewSelected(ev){const view=ev.detail.item.getAttribute("data-entity")||null;if(view!==this.currentView){let path="/states";if(view){path+="/"+view}this.navigate(path)}}_computeCurrentView(hass,routeMatch,routeData){if(!routeMatch)return"";if(!hass.states[routeData.view]||!hass.states[routeData.view].attributes.view){return""}return routeData.view}computeTitle(views,defaultView,locationName){return views&&0<views.length&&!defaultView&&"Home"===locationName||!locationName?"Home Assistant":locationName}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}_computeLocationName(hass){return computeLocationName(hass)}hassChanged(hass){if(!hass)return;const views=Object(extract_views.a)(hass.states);let defaultView=null;if(0<views.length&&views[0].entity_id===DEFAULT_VIEW_ENTITY_ID){defaultView=views.shift()}this.setProperties({views,defaultView})}isView(currentView,defaultView){return(currentView||defaultView)&&this.hass.states[currentView||DEFAULT_VIEW_ENTITY_ID]}_defaultViewFilter(hass,entityId){return!hass.states[entityId].attributes.hidden}_computeDefaultViewStates(hass,entityIds){const states={};entityIds.filter(this._defaultViewFilter.bind(null,hass)).forEach(entityId=>{states[entityId]=hass.states[entityId]});return states}computeViewStates(currentView,hass,defaultView){const entityIds=Object.keys(hass.states);if(!this.isView(currentView,defaultView)){return this._computeDefaultViewStates(hass,entityIds)}let states;if(currentView){states=Object(get_view_entities.a)(hass.states,hass.states[currentView])}else{states=Object(get_view_entities.a)(hass.states,hass.states[DEFAULT_VIEW_ENTITY_ID])}entityIds.forEach(entityId=>{const state=hass.states[entityId];if(ALWAYS_SHOW_DOMAIN.includes(Object(compute_state_domain.a)(state))){states[entityId]=state}});return states}computeOrderedGroupEntities(currentView,hass,defaultView){if(!this.isView(currentView,defaultView)){return null}for(var orderedGroupEntities={},entitiesList=hass.states[currentView||DEFAULT_VIEW_ENTITY_ID].attributes.entity_id,i=0;i<entitiesList.length;i++){orderedGroupEntities[entitiesList[i]]=i}return orderedGroupEntities}}customElements.define("ha-panel-states",ha_panel_states_PartialCards)},99:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return IronRangeBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(2);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronRangeBehavior={properties:{value:{type:Number,value:0,notify:!0,reflectToAttribute:!0},min:{type:Number,value:0,notify:!0},max:{type:Number,value:100,notify:!0},step:{type:Number,value:1,notify:!0},ratio:{type:Number,value:0,readOnly:!0,notify:!0}},observers:["_update(value, min, max, step)"],_calcRatio:function(value){return(this._clampValue(value)-this.min)/(this.max-this.min)},_clampValue:function(value){return Math.min(this.max,Math.max(this.min,this._calcStep(value)))},_calcStep:function(value){value=parseFloat(value);if(!this.step){return value}var numSteps=Math.round((value-this.min)/this.step);if(1>this.step){return numSteps/(1/this.step)+this.min}else{return numSteps*this.step+this.min}},_validateValue:function(){var v=this._clampValue(this.value);this.value=this.oldValue=isNaN(v)?this.oldValue:v;return this.value!==v},_update:function(){this._validateValue();this._setRatio(100*this._calcRatio(this.value))}}}}]);
//# sourceMappingURL=06742890303170e3a3b1.chunk.js.map